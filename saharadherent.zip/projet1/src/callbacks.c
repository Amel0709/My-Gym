#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "greeting.h"


void
on_button1a_clicked    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
int x;
GtkWidget *a,*b,*c,*d,*window1a,*window2a;
char login[20];char password[20];
FILE* f;
window1a=lookup_widget(objet_graphique,"window1a");
a=lookup_widget(objet_graphique,"entry1a");
b=lookup_widget(objet_graphique,"entry2a");
c=lookup_widget(objet_graphique,"label3a");
d=lookup_widget(objet_graphique,"label5a");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(a)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(b)));
x=a_verifier(login,password);
if (x==1)
{ window2a=create_window2a();
gtk_widget_show(window2a);
gtk_widget_hide(window1a);
}

else {gtk_label_set_text(GTK_LABEL(d),"authentification non validée");
}
}

void
on_button2a_clicked                     (GtkWidget       *objet_graphique,    gpointer      user_data)
{
GtkWidget *window2a,*window3a,*List_View;



window3a=create_window3a();
gtk_widget_show(window3a);

gtk_widget_hide(window2a);
List_View=lookup_widget(window3a,"treeview1a");
a_afficher_tableau_event(List_View);
}


void
on_button4a_clicked                     (GtkWidget       *objet_graphique,  gpointer   user_data)
{
GtkWidget *window1a,*window2a;
window1a=create_window1a();
gtk_widget_show(window1a);
window2a=lookup_widget(objet_graphique,"window2a");

gtk_widget_hide(window2a);
}


void
on_button5a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2a,*window3a;
window3a=lookup_widget(objet_graphique,"window3a");
gtk_widget_hide(window3a);
}


void
on_button6a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3a,*window4a;
window3a= lookup_widget(objet_graphique,"window3a");
window4a= lookup_widget(objet_graphique,"window4a");
window4a=create_window4a();
gtk_widget_show(window4a);
gtk_widget_hide(window3a);
}

void
on_button17a_clicked                    (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window8a,*window12a;
window8a= lookup_widget(objet_graphique,"window8a");
window12a= lookup_widget(objet_graphique,"window12a");
window12a=create_window12a();
gtk_widget_show(window12a);
gtk_widget_hide(window8a);
}
 
void
on_button7a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *a;
GtkWidget *b;
GtkWidget *c;
GtkWidget *d;
GtkWidget *e;
GtkWidget *f;
GtkWidget *g;
GtkWidget *h;
GtkWidget *window2a,*window5a;
window5a=create_window5a();
gtk_widget_show(window5a);
gtk_widget_hide(window2a);
FILE *fic;
a=lookup_widget(window5a, "entry3a");
b=lookup_widget(window5a, "entry4a");
c=lookup_widget(window5a, "entry10a");
d=lookup_widget(window5a, "entry5a");
e=lookup_widget(window5a, "entry6a");
f=lookup_widget(window5a, "entry7a");
g=lookup_widget(window5a, "entry8a");
h=lookup_widget(window5a, "entry9a");
char nom1[50];
char prenom1[50];
char date1[50];
char email1[50];
char cin1[50];
char adresse1[50];
char poids1[50];
char objectif1[50];
char nom[50];
char prenom[50];
char date[50];
char email[50];
char cin[50];
char adresse[50];
char poids[50];
char objectif[50];
fic=fopen("src/profila.txt","r");

if (fic==NULL) printf("erreur\n");
else {
while (fscanf(fic,"%s %s %s %s %s %s %s %s",nom1,prenom1,date1,email1,cin1,adresse1,poids1,objectif1)!=EOF)
{ 
break;
}
fclose(fic);}
gtk_entry_set_text(GTK_ENTRY(a),nom1);
gtk_entry_set_text(GTK_ENTRY(b),prenom1);
gtk_entry_set_text(GTK_ENTRY(c),date1);
gtk_entry_set_text(GTK_ENTRY(d),email1);
gtk_entry_set_text(GTK_ENTRY(e),cin1);
gtk_entry_set_text(GTK_ENTRY(f),adresse1);
gtk_entry_set_text(GTK_ENTRY(g),poids1);
gtk_entry_set_text(GTK_ENTRY(h),objectif1);
}




void
on_button9a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2a,*window5a;
window5a=lookup_widget(objet_graphique,"window5a");
gtk_widget_hide(window5a);
}


void
on_button13a_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *heure;
GtkWidget *type;
GtkWidget *window4a;
GtkWidget *window3a;
GtkWidget *List_View;

seance s;


jour=lookup_widget(objet_graphique, "spinbutton4a");
mois=lookup_widget(objet_graphique, "spinbutton5a");
annee=lookup_widget(objet_graphique, "spinbutton6a");

heure=lookup_widget(objet_graphique, "combobox5a");
nom=lookup_widget(objet_graphique, "combobox2a");
type=lookup_widget(objet_graphique, "combobox12a");

s.dt_seance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
s.dt_seance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
s.dt_seance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));


strcpy(s.hr_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)));

strcpy(s.nom_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nom)));

strcpy(s.type_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));

a_ajout_seance( s);

window4a= lookup_widget(objet_graphique,"window4a");
window3a=create_window3a();
gtk_widget_hide(window4a);
List_View=lookup_widget(window3a,"treeview1a");
a_afficher_tableau_event(List_View);
gtk_widget_show(window3a);
}

void
on_button11a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3a,*window4a,*List_View;
window4a= lookup_widget(objet_graphique,"window4a");
window3a=create_window3a();
gtk_widget_hide(window4a);
List_View=lookup_widget(window3a,"treeview1a");
a_afficher_tableau_event(List_View);
gtk_widget_show(window3a);
}






void
on_button18a_clicked                    (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window8a,*window2a;
window8a=lookup_widget(objet_graphique,"window8a");
gtk_widget_hide(window8a);
}



void
on_button3a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
GtkWidget *window2a,*window8a,*List_View1;
window8a=create_window8a();
gtk_widget_show(window8a);
gtk_widget_hide(window2a);
List_View1=lookup_widget(window8a,"treeview2a");
a_afficher_tableau_event2(List_View1);

}


void
on_button21a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window8a,*window12a,*List_View;
window12a=lookup_widget(objet_graphique,"window12a");
window8a=create_window8a();
gtk_widget_hide(window12a);
List_View=lookup_widget(window8a,"treeview2a");
a_afficher_tableau_event2(List_View);
gtk_widget_show(window8a);
}


void
on_button20a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
GtkWidget *staff;
GtkWidget *type;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *heure;
GtkWidget *window8a;
GtkWidget *window12a;
GtkWidget *List_View;

seance1 s;


jour=lookup_widget(objet_graphique, "spinbutton9a");
mois=lookup_widget(objet_graphique, "spinbutton10a");
annee=lookup_widget(objet_graphique, "spinbutton11a");

heure=lookup_widget(objet_graphique, "combobox3a");
type=lookup_widget(objet_graphique, "combobox16a");
staff=lookup_widget(objet_graphique, "combobox4a");

s.dt_seance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
s.dt_seance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
s.dt_seance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));


strcpy(s.hr_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)));
strcpy(s.type_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));

strcpy(s.staff_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(staff)));

a_ajout_seance1( s);

window12a=lookup_widget(objet_graphique,"window12a");
window8a=create_window8a();
gtk_widget_hide(window12a);
List_View=lookup_widget(window8a,"treeview2a");
a_afficher_tableau_event2(List_View);
gtk_widget_show(window8a);
}
void
on_treeview1a_row_activated             (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,  
                                        gpointer         user_data)
{
GtkWidget *coach1,*type1,*heure1,*jour1,*mois1,*annee1,*window13a,*window3a,*treeview;
    gchar *coach,*heure,*type;
    gint *jour,*mois,*annee;
    window13a=create_window13a();
	treeview=lookup_widget(objet_graphique,"treeview1a");
window3a=lookup_widget(objet_graphique,"window3a");
    coach1=lookup_widget(window13a,"combobox7a");
    type1=lookup_widget(window13a,"combobox12a");
    heure1=lookup_widget(window13a,"combobox6a");
    jour1=lookup_widget(window13a,"spinbutton12a");
    mois1=lookup_widget(window13a,"spinbutton13a");
    annee1=lookup_widget(window13a,"spinbutton14a");
    GtkTreeIter iter;
    GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview));
    gtk_tree_model_get_iter(model,&iter,path);
    gtk_tree_model_get (model,&iter,0,&coach,1,&type,2,&heure,3,&jour,4,&mois,5,&annee,-1);
    printf("%s %s %s %s %s %s",coach,type,heure,jour,mois,annee);
    gtk_entry_set_text(GTK_ENTRY (coach1),_(coach));
    gtk_entry_set_text(GTK_ENTRY (type1),_(type));
    gtk_entry_set_text(GTK_ENTRY (heure1),_(heure));
    gtk_entry_set_text(GTK_ENTRY (jour1),_(jour));
    gtk_entry_set_text(GTK_ENTRY (mois1),_(mois));
    gtk_entry_set_text(GTK_ENTRY (annee1),_(annee));
    gtk_widget_hide(window3a);
    gtk_widget_show(window13a);
}


void
on_treeview2a_row_activated             (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,  
                                        gpointer         user_data)
{
GtkWidget *staff1,*type1,*heure1,*jour1,*mois1,*annee1,*window14a,*window8a,*treeview;
    gchar *staff,*heure,*type;
    gint *jour,*mois,*annee;
    window14a=create_window14a();
	treeview=lookup_widget(objet_graphique,"treeview2a");
window8a=lookup_widget(objet_graphique,"window8a");
    staff1=lookup_widget(window14a,"combobox9a");
    type1=lookup_widget(window14a,"combobox15a");
    heure1=lookup_widget(window14a,"combobox8a");
    jour1=lookup_widget(window14a,"spinbutton15a");
    mois1=lookup_widget(window14a,"spinbutton17a");
    annee1=lookup_widget(window14a,"spinbutton18a");
    GtkTreeIter iter;
    GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview));
    gtk_tree_model_get_iter(model,&iter,path);
    gtk_tree_model_get (model,&iter,0,&staff,1,&type,2,&heure,3,&jour,4,&mois,5,&annee,-1);
    printf("%s %s %s %s %s %s",staff,type,heure,jour,mois,annee);
    gtk_entry_set_text(GTK_ENTRY (staff1),_(staff));
    gtk_entry_set_text(GTK_ENTRY (type1),_(type));
    gtk_entry_set_text(GTK_ENTRY (heure1),_(heure));
    gtk_entry_set_text(GTK_ENTRY (jour1),_(jour));
    gtk_entry_set_text(GTK_ENTRY (mois1),_(mois));
    gtk_entry_set_text(GTK_ENTRY (annee1),_(annee));
    gtk_widget_hide(window8a);
    gtk_widget_show(window14a);
}
void
on_button26a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom1,*type1,*heure1,*jour1,*mois1,*annee1,*window13a,*window3a,*List_View;
seance s;
char nom[20],heure[20],type[20];
int jour,mois,annee;
    nom1=lookup_widget(objet_graphique,"combobox7a");
    type1=lookup_widget(objet_graphique,"combobox14a");
    heure1=lookup_widget(objet_graphique,"combobox6a");
    jour1=lookup_widget(objet_graphique,"spinbutton12a");
    mois1=lookup_widget(objet_graphique,"spinbutton13a");
    annee1=lookup_widget(objet_graphique,"spinbutton14a");
    strcpy(s.hr_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure1)));
    strcpy(s.type_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type1)));
    strcpy(s.nom_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nom1)));
s.dt_seance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour1));
s.dt_seance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois1));
s.dt_seance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee1));

a_modifier(s.nom_seance,s.type_seance,s.hr_seance,s.dt_seance.jour,s.dt_seance.mois,s.dt_seance.annee);
window13a= lookup_widget(objet_graphique,"window13a");
window3a= lookup_widget(objet_graphique,"window3a");
window3a=create_window3a();
gtk_widget_hide(window13a);
List_View=lookup_widget(window3a,"treeview1a");
a_afficher_tableau_event(List_View);
gtk_widget_show(window3a);
}


void
on_button27a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom1,*type1,*heure1,*jour1,*mois1,*annee1,*window13a,*List_View,*window3a;
seance s;
char nom[20],type[20],heure[20],jour[20],mois[20],annee[20];
    nom1=lookup_widget(objet_graphique,"combobox7a");
    type1=lookup_widget(objet_graphique,"combobox14a");
    heure1=lookup_widget(objet_graphique,"combobox6a");
    jour1=lookup_widget(objet_graphique,"spinbutton12a");
    mois1=lookup_widget(objet_graphique,"spinbutton13a");
    annee1=lookup_widget(objet_graphique,"spinbutton14a");
    strcpy(s.hr_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure1)));
    strcpy(s.nom_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nom1)));
    strcpy(s.type_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type1)));
s.dt_seance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour1));
s.dt_seance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois1));
s.dt_seance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee1));

a_supprimer(s.nom_seance,s.type_seance,s.hr_seance,s.dt_seance.jour,s.dt_seance.mois,s.dt_seance.annee);
window13a= lookup_widget(objet_graphique,"window13a");
window3a= lookup_widget(objet_graphique,"window3a");
window3a=create_window3a();
gtk_widget_hide(window13a);
List_View=lookup_widget(window3a,"treeview1a");
a_afficher_tableau_event(List_View);
gtk_widget_show(window3a);    
}





void
on_button28a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *staff1,*type1,*heure1,*jour1,*mois1,*annee1,*window14a,*window8a,*List_View;
seance1 s;
char staff[20],type[20],heure[20];
int jour,mois,annee;
    staff1=lookup_widget(objet_graphique,"combobox9a");
    heure1=lookup_widget(objet_graphique,"combobox8a");
    type1=lookup_widget(objet_graphique,"combobox15a");
    jour1=lookup_widget(objet_graphique,"spinbutton15a");
    mois1=lookup_widget(objet_graphique,"spinbutton17a");
    annee1=lookup_widget(objet_graphique,"spinbutton18a");
    strcpy(s.hr_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure1)));
    strcpy(s.staff_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(staff1)));
    strcpy(s.type_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type1)));
s.dt_seance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour1));
s.dt_seance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois1));
s.dt_seance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee1));

a_modifier1(s.staff_seance,s.type_seance,s.hr_seance,s.dt_seance.jour,s.dt_seance.mois,s.dt_seance.annee);
    window14a= lookup_widget(objet_graphique,"window14a");
window8a=create_window8a();
gtk_widget_hide(window14a);
List_View=lookup_widget(window8a,"treeview2a");
a_afficher_tableau_event2(List_View);
gtk_widget_show(window8a);

}


void
on_button29a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *staff1,*type1,*heure1,*jour1,*mois1,*annee1,*window14a,*List_View,*window8a;
seance1 s;
char staff[20],type[20],heure[20],jour[20],mois[20],annee[20];
    staff1=lookup_widget(objet_graphique,"combobox9a");
    type1=lookup_widget(objet_graphique,"combobox15a");
    heure1=lookup_widget(objet_graphique,"combobox8a");
    jour1=lookup_widget(objet_graphique,"spinbutton15a");
    mois1=lookup_widget(objet_graphique,"spinbutton17a");
    annee1=lookup_widget(objet_graphique,"spinbutton18a");
    strcpy(s.hr_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure1)));
    strcpy(s.staff_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(staff1)));
    strcpy(s.type_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type1)));
s.dt_seance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour1));
s.dt_seance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois1));
s.dt_seance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee1));

a_supprimer1(s.staff_seance,s.type_seance,s.hr_seance,s.dt_seance.jour,s.dt_seance.mois,s.dt_seance.annee);
      window14a= lookup_widget(objet_graphique,"window14a");
window8a=create_window8a();
gtk_widget_hide(window14a);
List_View=lookup_widget(window8a,"treeview2a");
a_afficher_tableau_event2(List_View);
gtk_widget_show(window8a);

}


void
on_button30a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3a,*window13a,*List_View;
window13a= lookup_widget(objet_graphique,"window13a");
window3a=create_window3a();
gtk_widget_hide(window13a);
List_View=lookup_widget(window3a,"treeview1a");
a_afficher_tableau_event(List_View);
gtk_widget_show(window3a);
}


void
on_button31a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window8a,*window14a,*List_View;
window14a= lookup_widget(objet_graphique,"window14a");
window8a=create_window8a();
gtk_widget_hide(window14a);
List_View=lookup_widget(window8a,"treeview2a");
a_afficher_tableau_event2(List_View);
gtk_widget_show(window8a);
}





void
on_button32a_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom,*prenom,*date,*email,*cin,*adresse,*poids,*objectif,*window5a,*window2a;
    char nom1[50],prenom1[50],date1[50],email1[50],cin1[50],adresse1[50],poids1[50],objectif1[50];
   
    nom=lookup_widget(objet_graphique,"entry3a");
    prenom=lookup_widget(objet_graphique,"entry4a");
    date=lookup_widget(objet_graphique,"entry10a");
    email=lookup_widget(objet_graphique,"entry5a");
    cin=lookup_widget(objet_graphique,"entry6a");
    adresse=lookup_widget(objet_graphique,"entry7a");
    poids=lookup_widget(objet_graphique,"entry8a");
    objectif=lookup_widget(objet_graphique,"entry9a");
   
    strcpy(nom1,gtk_entry_get_text(GTK_ENTRY(nom)));
    strcpy(prenom1,gtk_entry_get_text(GTK_ENTRY(prenom)));
    strcpy(date1,gtk_entry_get_text(GTK_ENTRY(date)));
    strcpy(email1,gtk_entry_get_text(GTK_ENTRY(email)));
    strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(cin)));
    strcpy(adresse1,gtk_entry_get_text(GTK_ENTRY(adresse)));
    strcpy(poids1,gtk_entry_get_text(GTK_ENTRY(poids)));
    strcpy(objectif1,gtk_entry_get_text(GTK_ENTRY(objectif)));
   
    a_modifier2(nom1,prenom1,date1,email1,cin1,adresse1,poids1,objectif1);
    //window2a=create_window2a();
    //gtk_widget_show (window2a);
    window5a=lookup_widget(objet_graphique,"window5a");
    gtk_widget_hide(window5a);
   
}

