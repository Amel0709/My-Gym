#include <gtk/gtk.h>


void
on_button1a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button2a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button5a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button9a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button11a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button17a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button18a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button21a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button20a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1a_row_activated             (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,  
                                        gpointer         user_data);

void
on_button26a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button27a_clicked                    (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_treeview2a_row_activated             (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,  
                                        gpointer         user_data);

void
on_button28a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button29a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button30a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button31a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button32a_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
