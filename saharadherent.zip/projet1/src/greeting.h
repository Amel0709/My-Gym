#ifndef reservation_H_INCLUDED	
#define reservation_H_INCLUDED
#include "greeting.h"
#include <gtk/gtk.h>

typedef struct
{
int jour;
int mois;
int annee;
}Date;
typedef struct
{
char hr_seance[50];
char nom_seance[50];
char type_seance[50];
Date dt_seance;

}seance;

typedef struct
{
char hr_seance[50];
char staff_seance[50];
char type_seance[50];
Date dt_seance;

}seance1;
void a_ajouter(char login[],char password[],int role);


int a_verification(char log[],char password[], char hello[]);


void a_affiche();

/*void afficher2(char nom[],char prenom[],char date[],char email[],char cin[],char adresse[],char poids[],char objectif[]);*/

void a_ajout_seance(seance s);

void a_ajout_seance1(seance1 s);

void a_afficher_tableau_event(GtkWidget *plistview);

void a_afficher_tableau_event2(GtkWidget *plistview1);


void a_modifier(char nom[],char type[],char heure[],int jour,int mois,int annee);

void a_modifier1(char staff[],char type[],char heure[],int jour,int mois,int annee);

void a_modifier2(char nom[],char prenom[],char date[],char email[],char cin[],char adresse[],char poids[], char objectif[]);

 void a_supprimer(char nom[],char type[],char heure[],char jour[],char mois[],char annee[]);

void a_supprimer1(char staff[],char type[],char heure[],char jour[],char mois[],char annee[]);

#endif

