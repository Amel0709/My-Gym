#include <gtk/gtk.h>
typedef struct
{


char heure[30];
char date[30];



}dispo;

void ajouter_dispo(dispo d);
typedef struct
{


char heure[30];
char date[30];
char salle[30];
char type[30];


}seance;
void ajouter_seance(seance s);
void ajouter(char login[],char password[],int role);
void afficher();
int verifier(char login[],char password[]);
void afficher3c(GtkWidget *plistview);
void afficher1c(GtkWidget *plistview);
void afficher2c(GtkWidget *plistview);
void afficher4c(GtkWidget *plistview);
void modifierc(char date[], char heure[]);
void modifier2c(char nom[],char prenom[],char date[],char email[],char cin[],char adresse[]);
void supprimerc(char date[],char heure[]);
void modifier1c(char date[],char heure[],char salle[],char type[]);
void supprimer1c(char date[],char heure[],char salle[],char type[]);
	


