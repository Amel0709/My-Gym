#include<stdio.h>
#include<string.h>
#include "greeting.h"


void ajouter(char login[],char password[],int role)
{
	FILE *f;
	f = fopen("/home/oumemajedidi/Projets/projet9/src/users.txt","a+");
	if(f!=NULL){
		fprintf(f,"%s %s %d\n", login, password, role);	
	}
	fclose(f);

}

void afficher()
{
	FILE *f;
	f=fopen("/home/oumemajedidi/Projets/projet9/src/users.txt","r");
	char login[20],password[20];
	int role;
	while(fscanf(f,"%s %s %d", login, password, &role)!=EOF){
		printf("%s %s %d\n", login, password, role);
	}
	fclose(f);
}

int verifier(char login[],char password[])
{
	FILE *f;
	f=fopen("/home/oumemajedidi/Projets/projet9/src/users.txt","r");
	int role;
	char login1[20],password1[20];
	while(fscanf(f,"%s %s %d\n", login1, password1, &role)!=EOF){
		if (strcmp(login1,login)==0 && strcmp(password1,password)==0)
		{
			fclose(f);
			return role;
		}
	}
	fclose(f);
	return(-1);
}
void afficher3c(GtkWidget *plistview)
{ 
enum { COL_IDENTIFIANT,
       COL_NOM,
       COL_PRENOM,
       COL_AGE,
       COL_POIDS,
       COL_ETAT_DE_LA_TENSION,
       COL_MALADIES,
       COL_OBSERVATIONS,
       NUM_COLS
      };
char identifiant[20],nom[20],prenom[30],etat_de_la_tension[20],maladies[20],observations[30];
int age,poids;
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("src/fiches.txt","r");
if(f!=NULL){
       while(fscanf(f,"%s %s %s %d %d %s %s %s",identifiant,nom,prenom,&age,&poids,etat_de_la_tension,maladies,observations)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          COL_IDENTIFIANT, identifiant,
      			  COL_NOM, nom,
       			  COL_PRENOM, prenom,
       			  COL_AGE, age,
       			  COL_POIDS, poids,
       			  COL_ETAT_DE_LA_TENSION, etat_de_la_tension,
      			  COL_MALADIES, maladies,
      			  COL_OBSERVATIONS, observations,
                       -1);}

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("identifiant",celrender,"text",COL_IDENTIFIANT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("nom",celrender,"text",COL_NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("prenom",celrender,"text",COL_PRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("age",celrender,"text",COL_AGE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
        
      
        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("poids",celrender,"text",COL_POIDS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("etat_de_la_tension",celrender,"text",COL_ETAT_DE_LA_TENSION,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("maladies",celrender,"text",COL_MALADIES,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
        
        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("observations",celrender,"text",COL_OBSERVATIONS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}

void afficher4c(GtkWidget *plistview)
{ 
enum { COL_COACH,
       COL_TYPE,
       COL_HEURE,
       COL_JOUR,
       COL_MOIS,
       COL_ANNEE,
       NUM_COLS
      };
char coach[20],type[20],heure[20],jour[20],mois[20],annee[20];

GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("src/rdvc.txt","r");
if(f!=NULL){
       while(fscanf(f,"%s %s %s %s %s %s",coach,type,heure,jour,mois,annee)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          
      			  COL_COACH, coach,
       			  COL_TYPE, type,
       			  COL_HEURE, heure,
       			  COL_JOUR, jour,
       			  COL_MOIS, mois,
      			  COL_ANNEE, annee,
      			 
                       -1);}

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("coach",celrender,"text",COL_COACH,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("type",celrender,"text",COL_TYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("heure",celrender,"text",COL_HEURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("jour",celrender,"text",COL_JOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
        
      
        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("mois",celrender,"text",COL_MOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("annee",celrender,"text",COL_ANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
        
        gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}


void afficher1c(GtkWidget *plistview)
{ 
enum { COL_DATE,
       COL_HEURE,
       NUM_COLS
      };
char date[20],heure[20];
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("/home/oumemajedidi/Projets/projet9/src/dispo.txt","r");
if(f!=NULL){
       while(fscanf(f,"%s %s ",date,heure)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          COL_DATE, date,
		          COL_HEURE, heure,
		         
                       -1);}
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("date",celrender,"text",COL_DATE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("heure",celrender,"text",COL_HEURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	

	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}
void afficher2c(GtkWidget *plistview)
{ 
enum { COL_DATE,
       COL_HEURE,
       COL_SALLE,
       COL_TYPE,
       NUM_COLS
      };
char date[20],heure[20],salle[30],type[20];
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("/home/oumemajedidi/Projets/projet9/src/seance.txt","r");
if(f!=NULL){
       while(fscanf(f,"%s %s %s %s ",date,heure,salle,type)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          COL_DATE, date,
		          COL_HEURE, heure,
                          COL_SALLE, salle,
                          COL_TYPE, type,
		         
                       -1);}
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("date",celrender,"text",COL_DATE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("heure",celrender,"text",COL_HEURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("salle",celrender,"text",COL_SALLE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
        
        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("type",celrender,"text",COL_TYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}
void ajouter_dispo(dispo d)
{
enum   
{       DATE,
        HEURE,
        COLUMNS
};

{

 FILE *f;
  f=fopen("/home/oumemajedidi/Projets/projet9/src/dispo.txt","a+");
  if(f!=NULL) 
  {
  fprintf(f,"%s %s \n",d.date,d.heure);
  fclose(f);

  }

}}
void modifierc(char date[], char heure[])
{
	char datec[20],heurec[20];
	FILE *F; 
	FILE *Ftempp;
        dispo d;
        
        F=fopen("/home/oumemajedidi/Projets/projet9/src/dispo.txt","r");
	Ftempp=fopen ("/home/oumemajedidi/Projets/projet9/src/tempp.txt","a+");
        
               while(fscanf(F,"%s %s ",datec,heurec)!=EOF){
		if( !strcmp(heure,heurec) ){
			fprintf(Ftempp,"%s %s \n",date,heure);	
		}else
		fprintf(Ftempp,"%s %s \n",datec,heurec);
	}
	fclose(F);
	fclose(Ftempp);
       
	rename ("/home/oumemajedidi/Projets/projet9/src/tempp.txt","/home/oumemajedidi/Projets/projet9/src/dispo.txt");
}
void supprimerc(char date[40],char heure[40])
	{


        FILE *F; 
	FILE *Ftempp;
        char datek[40];char heurek[40];
	F=fopen("/home/oumemajedidi/Projets/projet9/src/dispo.txt","r");
	Ftempp=fopen ("/home/oumemajedidi/Projets/projet9/src/tempp.txt","a+");
	if (F!=NULL){
	
		while (fscanf(F,"%s %s\n",datek,heurek
                                                    )!=EOF)
			{
			if(!strcmp(date,datek) && !strcmp(heure,heurek) ) 
				{ continue;}
else fprintf(Ftempp,"%s %s\n",datek,heurek);
			}
	
fclose(Ftempp);
fclose(F);
		    }


rename ("/home/oumemajedidi/Projets/projet9/src/tempp.txt","/home/oumemajedidi/Projets/projet9/src/dispo.txt");
}
void ajouter_seance(seance s)
{
enum   
{       DATE,
        HEURE,
        SALLE,
        TYPE,
        COLUMNS
};


{

 FILE *f;
  f=fopen("/home/oumemajedidi/Projets/projet9/src/seance.txt","a+");
  if(f!=NULL) 
  {
  fprintf(f,"%s %s %s %s \n",s.date,s.heure,s.salle,s.type);
  fclose(f);

  }

}}
void modifier1c(char date[],char heure[],char salle[],char type[]){
	char datec[20],heurec[20],sallec[30],typec[30];
	FILE *F1; 
	FILE *Ftemp;
        F1=fopen("/home/oumemajedidi/Projets/projet9/src/seance.txt","r");
	Ftemp=fopen ("/home/oumemajedidi/Projets/projet9/src/temp.txt","a+");
	while(fscanf(F1,"%s %s %s %s",datec,heurec,sallec,typec)!=EOF){
		if( !strcmp(heure,heurec) ){
			fprintf(Ftemp,"%s %s %s %s\n",date,heure,salle,type);	
		}else
		fprintf(Ftemp,"%s %s %s %s\n",datec,heurec,sallec,typec);
	}
	fclose(F1);
	fclose(Ftemp);
        
	rename ("/home/oumemajedidi/Projets/projet9/src/temp.txt","/home/oumemajedidi/Projets/projet9/src/seance.txt");
}
void supprimer1c(char date[],char heure[],char salle[],char type[])
	{


        FILE *F; 
	FILE *Ftemp;
        char datec[40];char heurec[40]; char sallec[40]; char typec[40];
	F=fopen("/home/oumemajedidi/Projets/projet9/src/seance.txt","r");
	Ftemp=fopen ("/home/oumemajedidi/Projets/projet9/src/temp.txt","a+");
	if (F!=NULL){
	
		while (fscanf(F,"%s %s %s %s\n",datec,heurec,sallec,
                                                    typec)!=EOF)
			{
			if(!strcmp(date,datec) && !strcmp(heure,heurec) )
				{
				continue;
				}
else fprintf(Ftemp,"%s %s %s %s\n",datec,heurec,sallec,typec);
			}
	
fclose(Ftemp);
fclose(F);
		    }

rename ("/home/oumemajedidi/Projets/projet9/src/temp.txt","/home/oumemajedidi/Projets/projet9/src/seance.txt");
}


void modifier2c(char nom[],char prenom[],char date[],char email[],char cin[],char adresse[])
{     
    char nomc[20],prenomc[20],datec[20],emailc[20],cinc[8],adressec[20];
    
    
    FILE *f , *tmp;
    f=fopen("src/profilc.txt","r");
    tmp=fopen("src/profilc.tmp","a+");
    while(fscanf(f,"%s %s %s %s %s %s\n",nomc,prenomc,datec,emailc,cinc,adressec)!=EOF){
        if(!strcmp(nom,nomc) && !strcmp(prenom,prenomc) && !strcmp(date,datec) && !strcmp(cin,cinc) ){fprintf(tmp,"%s %s %s %s %s %s\n",nom,prenom,date,email,cin,adresse);}
else fprintf(tmp,"%s %s %s %s %s %s\n",nomc,prenomc,datec,emailc,cinc,adressec);
}
fclose(f);
fclose(tmp);
rename("src/profilc.tmp","src/profilc.txt");
}                  


