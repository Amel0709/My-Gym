#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "greeting.h"
#include <string.h>




void
on_button1c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
int x;
GtkWidget *a,*b,*d,*window1c,*window2c;
char login[20];char password[20];
window1c=lookup_widget(objet_graphique,"window1c");
a=lookup_widget(objet_graphique,"entry1c");
b=lookup_widget(objet_graphique,"entry2c");
d=lookup_widget(objet_graphique,"label5c");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(a)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(b)));
x=verifier(login,password);
if (x==1)
{ window2c=create_window2c();
gtk_widget_show(window2c);
gtk_widget_hide(window1c);
}

else {gtk_label_set_text(GTK_LABEL(d),"authentification non validée");
}

}



void
on_button5c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window3c,*List_View;
window3c=create_window3c();
window2c=lookup_widget(objet_graphique,"window2c");
gtk_widget_hide(window2c);
List_View=lookup_widget(window3c,"treeview1c");
afficher3c(List_View);
gtk_widget_show(window3c);
}




void
on_button6c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window3c;
window3c=lookup_widget(objet_graphique,"window3c");
gtk_widget_destroy(window3c);
window2c=create_window2c();
gtk_widget_show(window2c);

}




void
on_button3c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window4c,*List_View;
window4c=create_window4c();
window2c=lookup_widget(objet_graphique,"window2c");
gtk_widget_hide(window2c);
List_View=lookup_widget(window4c,"treeview2c");
afficher1c(List_View);
gtk_widget_show(window4c);
}


void
on_button7c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window4c,*List_View;
window4c=lookup_widget(objet_graphique,"window4c");
List_View=lookup_widget(window4c,"treeview2c");
afficher1c(List_View);
gtk_widget_destroy(window4c);
window2c=create_window2c();


gtk_widget_show(window2c);
}


void
on_button8c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window5c;
window5c=lookup_widget(objet_graphique,"window5c");
gtk_widget_destroy(window5c);
window2c=create_window2c();
gtk_widget_show(window2c);
}


void
on_button4c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window5c,*List_View;
window5c=create_window5c();
window2c=lookup_widget(objet_graphique,"window2c");
gtk_widget_hide(window2c);
List_View=lookup_widget(window5c,"treeview3c");
afficher2c(List_View);
gtk_widget_show(window5c);
}

void
on_button9c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window4c,*window6c;
window6c=create_window6c();
gtk_widget_show (window6c);
window4c=lookup_widget(objet_graphique,"window4c");
gtk_widget_hide(window4c);

}


void
on_button10c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window6c,*window4c,*List_View;
window6c=lookup_widget(objet_graphique,"window6c");
gtk_widget_destroy(window6c);

window4c=create_window4c();
gtk_widget_show(window4c);
List_View=lookup_widget(window4c,"treeview2c");
afficher1c(List_View);

}


void
on_button11c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{

dispo d;

GtkWidget *ee, *gg;
GtkWidget *window6c;

window6c=lookup_widget(objet_graphique,"window6c");

ee=lookup_widget(objet_graphique,"entry3c");
gg=lookup_widget(objet_graphique,"entry4c");
strcpy(d.date,gtk_entry_get_text(GTK_ENTRY(ee)));
strcpy(d.heure,gtk_entry_get_text(GTK_ENTRY(gg)));




ajouter_dispo(d);


}



void
on_treeview3c_row_activated            (
                                        GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{ 
GtkWidget *dateco, *heureco, *salleco, *typeco, *window5c, *window9c, *List_View;
    
    char *date,*heure,*salle,*type;
    List_View=lookup_widget(objet_graphique,"treeview3c");
    window5c=lookup_widget(objet_graphique,"window5c");
    window9c=create_window9c();
    
    
    
    dateco=lookup_widget(window9c,"entry11c");
    heureco=lookup_widget(window9c,"entry12c");
    salleco=lookup_widget(window9c,"entry13c");
    typeco=lookup_widget(window9c,"entry14c");
    GtkTreeIter iter;
    GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(List_View));
    gtk_tree_model_get_iter(model,&iter,path);
    gtk_tree_model_get (model,&iter,0,&date,1,&heure,2,&salle,3,&type,-1);
    printf("%s %s %s %s ",date,heure,salle,type);
    gtk_entry_set_text(GTK_ENTRY (dateco),_(date));
    gtk_entry_set_text(GTK_ENTRY (heureco),_(heure));
    gtk_entry_set_text(GTK_ENTRY (salleco),_(salle));
    gtk_entry_set_text(GTK_ENTRY (typeco),_(type));
    
    gtk_widget_show(window9c);
    gtk_widget_destroy(window5c);
    
    


}

void
on_treeview2c_row_activated            (
                                        GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{   
    GtkWidget *datec, *heurec, *window4c, *window7c, *List_View;
    
    char *date,*heure;
    List_View=lookup_widget(objet_graphique,"treeview2c");
    window4c=lookup_widget(objet_graphique,"window4c");
    window7c=create_window7c();
    
    
    
    datec=lookup_widget(window7c,"entry5c");
    heurec=lookup_widget(window7c,"entry6c");
    GtkTreeIter iter;
    GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(List_View));
    gtk_tree_model_get_iter(model,&iter,path);
    gtk_tree_model_get (model,&iter,0,&date,1,&heure,-1);
    printf("%s %s  ",date,heure);
    gtk_entry_set_text(GTK_ENTRY (datec),_(date));
    gtk_entry_set_text(GTK_ENTRY (heurec),_(heure));
    
    gtk_widget_show(window7c);
    gtk_widget_destroy(window4c);
    
    


}


void
on_button12c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget  *datec, *heurec, *window4c, *window7c, *List_View , *current;
char date[20],heure[20];
    datec=lookup_widget(objet_graphique,"entry5c");
    heurec=lookup_widget(objet_graphique,"entry6c");
    strcpy(date,gtk_entry_get_text(GTK_ENTRY(datec)));
    strcpy(heure,gtk_entry_get_text(GTK_ENTRY(heurec)));
    modifierc(date,heure);
    current=lookup_widget(objet_graphique,"window7c");
    gtk_widget_hide(current);
window4c=create_window4c();
List_View=lookup_widget(window4c,"treeview2c");

window7c=lookup_widget(objet_graphique,"window7c");
gtk_widget_hide(window7c);
gtk_widget_show (window4c);
afficher1c(List_View);

    

}


void
on_button13c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window7c,*window4c,*List_View;
window7c=lookup_widget(objet_graphique,"window7c");
gtk_widget_destroy(window7c);

window4c=create_window4c();
gtk_widget_show(window4c);
List_View=lookup_widget(window4c,"treeview2c");
afficher1c(List_View);

}


void
on_button14c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget  *datec, *heurec, *window4c, *window7c, *List_View , *current;
char date[20],heure[20];
    datec=lookup_widget(objet_graphique,"entry5c");
    heurec=lookup_widget(objet_graphique,"entry6c");
    strcpy(date,gtk_entry_get_text(GTK_ENTRY(datec)));
    strcpy(heure,gtk_entry_get_text(GTK_ENTRY(heurec)));
    supprimerc(date,heure);
    current=lookup_widget(objet_graphique,"window7c");
    gtk_widget_hide(current);
window4c=create_window4c();
List_View=lookup_widget(window4c,"treeview2c");

window7c=lookup_widget(objet_graphique,"window7c");
gtk_widget_hide(window7c);
gtk_widget_show (window4c);
afficher1c(List_View);

}


void
on_button15c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window5c,*window8c;
window8c=create_window8c();
gtk_widget_show (window8c);
window5c=lookup_widget(objet_graphique,"window5c");
gtk_widget_hide(window5c);
}


void
on_button16c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{

seance s;

GtkWidget *e, *f, *g, *h;
GtkWidget *window6;

window6=lookup_widget(objet_graphique,"window6");

e=lookup_widget(objet_graphique,"entry7c");
f=lookup_widget(objet_graphique,"entry8c");
g=lookup_widget(objet_graphique,"entry9c");
h=lookup_widget(objet_graphique,"entry10c");
strcpy(s.date,gtk_entry_get_text(GTK_ENTRY(e)));
strcpy(s.heure,gtk_entry_get_text(GTK_ENTRY(f)));
strcpy(s.salle,gtk_entry_get_text(GTK_ENTRY(g)));
strcpy(s.type,gtk_entry_get_text(GTK_ENTRY(h)));
ajouter_seance(s);


}

void
on_button17c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window8c,*window5c,*List_View;
window8c=lookup_widget(objet_graphique,"window8c");
gtk_widget_destroy(window8c);

window5c=create_window5c();
gtk_widget_show(window5c);
List_View=lookup_widget(window5c,"treeview3c");
afficher2c(List_View);

}



void
on_button18c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window9c,*window5c,*List_View;
window9c=lookup_widget(objet_graphique,"window9c");
gtk_widget_destroy(window9c);

window5c=create_window5c();
gtk_widget_show(window5c);
List_View=lookup_widget(window5c,"treeview3c");
afficher2c(List_View);

}


void
on_button19c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget  *dateco, *heureco, *salleco, *typeco, *window5c, *window9c, *List_View , *current;
char date[20],heure[20],salle[20],type[20];
    
    dateco=lookup_widget(objet_graphique,"entry11c");
    heureco=lookup_widget(objet_graphique,"entry12c");
    salleco=lookup_widget(objet_graphique,"entry13c");
    typeco=lookup_widget(objet_graphique,"entry14c");
   
    strcpy(date,gtk_entry_get_text(GTK_ENTRY(dateco)));
    strcpy(heure,gtk_entry_get_text(GTK_ENTRY(heureco)));
    strcpy(salle,gtk_entry_get_text(GTK_ENTRY(salleco)));
    strcpy(type,gtk_entry_get_text(GTK_ENTRY(typeco)));

    modifier1c(date,heure,salle,type);
    current=lookup_widget(objet_graphique,"window9c");
    gtk_widget_hide(current);
window5c=create_window5c();
List_View=lookup_widget(window5c,"treeview3c");

window9c=lookup_widget(objet_graphique,"window9c");
gtk_widget_hide(window9c);
gtk_widget_show (window5c);
afficher2c(List_View);

    

}


void
on_button20c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget  *datec, *heurec, *sallec, *typec, *window5c, *window9c, *List_View , *current;
char date[20],heure[20],salle[20],type[20];
    
    datec=lookup_widget(objet_graphique,"entry11c");
    heurec=lookup_widget(objet_graphique,"entry12c");
    sallec=lookup_widget(objet_graphique,"entry13c");
    typec=lookup_widget(objet_graphique,"entry14c");
   
    strcpy(date,gtk_entry_get_text(GTK_ENTRY(datec)));
    strcpy(heure,gtk_entry_get_text(GTK_ENTRY(heurec)));
    strcpy(salle,gtk_entry_get_text(GTK_ENTRY(sallec)));
    strcpy(type,gtk_entry_get_text(GTK_ENTRY(typec)));

    supprimer1c(date,heure,salle,type);
    current=lookup_widget(objet_graphique,"window9c");
    gtk_widget_hide(current);
window5c=create_window5c();
List_View=lookup_widget(window5c,"treeview3c");

window9c=lookup_widget(objet_graphique,"window9c");
gtk_widget_hide(window9c);
gtk_widget_show (window5c);
afficher2c(List_View);
}


void
on_button2c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
     
GtkWidget *co1,*co2,*co3,*co4,*co5,*co6,*window2c,*window10c;
window10c=create_window10c();
gtk_widget_show (window10c);
window2c=lookup_widget(objet_graphique,"window2c");
gtk_widget_hide(window2c);
FILE *fic;
co1=lookup_widget(window10c,"entry15c");
co2=lookup_widget(window10c,"entry16c");
co3=lookup_widget(window10c,"entry17c");
co4=lookup_widget(window10c,"entry18c");
co5=lookup_widget(window10c,"entry19c");
co6=lookup_widget(window10c,"entry20c");
char nom1c[20],prenom1c[20],date1c[20],email1c[20],cin1c[20],adresse1c[20],nom[20],prenom[20],date[20],email[20],cin[20],adresse[20];
fic=fopen("src/profilc.txt","r");

if (fic==NULL) printf("erreur\n");
else {
while (fscanf(fic,"%s %s %s %s %s %s",nom1c,prenom1c,date1c,email1c,cin1c,adresse1c)!=EOF)
{break;}
fclose(fic);}

gtk_entry_set_text(GTK_ENTRY(co1),nom1c);
gtk_entry_set_text(GTK_ENTRY(co2),prenom1c);
gtk_entry_set_text(GTK_ENTRY(co3),date1c);
gtk_entry_set_text(GTK_ENTRY(co4),email1c);
gtk_entry_set_text(GTK_ENTRY(co5),cin1c);
gtk_entry_set_text(GTK_ENTRY(co6),adresse1c);
}



void
on_button22c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *nom,*prenom,*date,*email,*cin,*adresse,*current,*window2c,*window10c;
    char nomc[50],prenomc[50],datec[50],emailc[50],cinc[50],adressec[50];
   
    nom=lookup_widget(objet_graphique,"entry15c");
    prenom=lookup_widget(objet_graphique,"entry16c");
    date=lookup_widget(objet_graphique,"entry17c");
    email=lookup_widget(objet_graphique,"entry18c");
    cin=lookup_widget(objet_graphique,"entry19c");
    adresse=lookup_widget(objet_graphique,"entry20c");
   
    strcpy(nomc,gtk_entry_get_text(GTK_ENTRY(nom)));
    strcpy(prenomc,gtk_entry_get_text(GTK_ENTRY(prenom)));
    strcpy(datec,gtk_entry_get_text(GTK_ENTRY(date)));
    strcpy(emailc,gtk_entry_get_text(GTK_ENTRY(email)));
    strcpy(cinc,gtk_entry_get_text(GTK_ENTRY(cin)));
    strcpy(adressec,gtk_entry_get_text(GTK_ENTRY(adresse)));
   
    modifier2c(nomc,prenomc,datec,emailc,cinc,adressec);
}


void
on_button23c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window10c;
window10c=lookup_widget(objet_graphique,"window10c");
gtk_widget_destroy(window10c);
window2c=create_window2c();
gtk_widget_show(window2c);
}


void
on_button24c_clicked                   

(GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window11c,*List_View;
window11c=create_window11c();
window2c=lookup_widget(objet_graphique,"window2c");
gtk_widget_hide(window2c);
List_View=lookup_widget(window11c,"treeview4c");
afficher4c(List_View);
gtk_widget_show(window11c);
}


void
on_button25c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window11c;
window11c=lookup_widget(objet_graphique,"window11c");
gtk_widget_destroy(window11c);
window2c=create_window2c();
gtk_widget_show(window2c);
}


void
on_button30c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window1c;
window2c=lookup_widget(objet_graphique,"window2c");
gtk_widget_destroy(window2c);
window1c=create_window1c();
gtk_widget_show(window1c);
}

