#include <gtk/gtk.h>


void
on_button1c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button5c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);



void
on_button6c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button3c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button7c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button8c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button4c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button9c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);


void
on_button10c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);


void
on_button11c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_treeview3c_row_activated            (
                                        GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview2c_row_activated            (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
void
on_button12c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button13c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button14c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button15c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button16c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button17c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);


void
on_button18c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);


void
on_button19c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button20c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button2c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);


void
on_button22c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button23c_clicked                  (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button24c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);
void
on_button25c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button30c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

