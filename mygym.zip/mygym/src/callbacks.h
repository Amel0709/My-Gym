#include <gtk/gtk.h>


void
on_button1a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button2a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button5a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button9a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button11a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button17a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button18a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button21a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button20a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1a_row_activated             (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,  
                                        gpointer         user_data);

void
on_button26a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button27a_clicked                    (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_treeview2a_row_activated             (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,  
                                        gpointer         user_data);

void
on_button28a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button29a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button30a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button31a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button32a_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

///////////////////////////////////callbacks.h nutritionniste //////////////////////////////


void
on_button2n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button5n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button8n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button50n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button67n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button68n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button69n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button99n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button98n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button97n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button101n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button102n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button103n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button201n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button202n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button203n_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_treeview100n_row_activated          (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button5000n_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6000n_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6001n_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


///////////////callbacks.h kine//////////////////////


void
on_button16k_clicked                    (GtkWidget       *objet_graphique16,
                                        gpointer         user_data);

void
on_button3k_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4k_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8k_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2k_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5k_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);



void
on_button14k_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15k_clicked                    (GtkWidget       *objet_graphique15,
                                        gpointer         user_data);

void
on_button19k_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18k_clicked                    (GtkWidget      *objet_graphique18,
                                        gpointer         user_data);

void
on_button20k_clicked                    (GtkWidget      *objet_graphique20,
                                        gpointer         user_data);

void
on_button22k_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button23k_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24k_clicked                    (GtkWidget      *objet_graphique24,
                                        gpointer         user_data);

void
on_button25k_clicked                    (GtkWidget      *objet_graphique25,
                                        gpointer         user_data);

void
on_button26k_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button27k_clicked                    (GtkWidget      *objet_graphique27,
                                        gpointer         user_data);



void
on_button28k_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button29k_clicked                    (GtkWidget   *objet_graphique,
                                        gpointer         user_data);







void
on_button13k_clicked                   (GtkWidget *objet_graphique,
                                        gpointer         user_data);


void
on_buttok18_enter                      (GtkButton       *button,
                                        gpointer         user_data);



void
on_buttonkmod_clicked                  (GtkWidget    *objet_graphique,
                                        gpointer         user_data);

void
on_buttonksupp_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonajk_clicked                   (GtkWidget         *objet_graphique,
                                        gpointer         user_data);

void
on_treeviewk2_row_activated            (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonkkaj_clicked                  (GtkWidget    *objet_graphique,
                                        gpointer         user_data);

void
on_buttonpro_clicked                   (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonret_clicked                   (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonret1_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonret4_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonret5_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonprom_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonprore_clicked                 (      GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourkk_clicked              (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonaffrdv_clicked                (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_retourrdv_clicked                   (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttoncclosek_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6k_clicked                    (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonRETK_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonFM_clicked                    (GtkWidget   *objet_graphique,
                                        gpointer         user_data);



void
on_treeviewk11_row_activated           (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


///////////////callbacks.h coach ////////////


void
on_button5c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);



void
on_button6c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button3c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button7c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button8c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button4c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button9c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);


void
on_button10c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);


void
on_button11c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_treeview3c_row_activated            (
                                        GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview2c_row_activated            (GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
void
on_button12c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button13c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button14c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button15c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button16c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button17c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);


void
on_button18c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);


void
on_button19c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button20c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button2c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);


void
on_button22c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button23c_clicked                  (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button24c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);
void
on_button25c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data);

void
on_button30c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data);

