#include<stdio.h>
#include<string.h>
#include "greeting.h"


void a_ajouter(char login[],char password[],int role)
{
	FILE *f;
	f = fopen("users.txt","a+");
	if(f!=NULL){
		fprintf(f,"%s %s %d\n", login, password, role);	
	}
	fclose(f);

}

void a_afficher()
{
	FILE *f;
	f=fopen("src/users.txt","r");
	char login[20],password[20];
	int role;
	while(fscanf(f,"%s %s %d", login, password, &role)!=EOF){
		printf("%s %s %d\n", login, password, role);
	}
	fclose(f);
}

int a_verifier(char login[],char password[])
{
	FILE *f;
	f=fopen("src/users.txt","r");
	int role;
	char login1[20],password1[20];
	while(fscanf(f,"%s %s %d\n", login1, password1, &role)!=EOF){
		if (strcmp(login1,login)==0 && strcmp(password1,password)==0)
		{
			fclose(f);
			return role;
		}
	}
	fclose(f);
	return(-1);
}



void a_ajout_seance(seance s)
{
FILE *f;

f=fopen("src/seance.txt","a");

		
	
	
	fprintf(f,"%s %s %s %d %d %d \n",s.nom_seance,s.type_seance,s.hr_seance,s.dt_seance.jour,s.dt_seance.mois,s.dt_seance.annee);
	
fclose(f);
}

void a_ajout_seance1(seance1 s)
{
FILE *f;

f=fopen("src/seance1.txt","a");

		
	
	
	fprintf(f,"%s %s %s %d %d %d \n",s.staff_seance,s.type_seance,s.hr_seance,s.dt_seance.jour,s.dt_seance.mois,s.dt_seance.annee);
	
fclose(f);
}

void a_afficher_tableau_event(GtkWidget *plistview)
{ 
enum { COL_COACH,
       COL_TYPE,
       COL_HEURE,
       COL_JOUR,
       COL_MOIS,
       COL_ANNEE,
       NUM_COLS
      };
char coach[20],type[20],heure[20],jour[20],mois[20],annee[20];
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("src/seance.txt","r");
if(f!=NULL){
       while(fscanf(f,"%s %s %s %s %s %s",coach,type,heure,jour,mois,annee)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          COL_COACH, coach,
                          COL_TYPE, type,
			  COL_HEURE, heure,
		          COL_JOUR, jour,
		          COL_MOIS, mois,
		          COL_ANNEE, annee,
		          		         
                       -1);}
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("coach",celrender,"text",COL_COACH,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("type",celrender,"text",COL_TYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);


	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("heure",celrender,"text",COL_HEURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("jour",celrender,"text",COL_JOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("mois",celrender,"text",COL_MOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("annee",celrender,"text",COL_ANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);


	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}

void a_afficher_tableau_event2(GtkWidget *plistview1)
{ 
enum { COL_STAFF,
       COL_TYPE,
       COL_HEURE,
       COL_JOUR,
       COL_MOIS,
       COL_ANNEE,
       NUM_COLS
      };
char staff[20],type[20],heure[20],jour[20],mois[20],annee[20];
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("src/seance1.txt","r");
if(f!=NULL){
       while(fscanf(f,"%s %s %s %s %s %s",staff,type,heure,jour,mois,annee)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          COL_STAFF, staff,
			  COL_TYPE, type,
		          COL_HEURE, heure,
		          COL_JOUR, jour,
		          COL_MOIS, mois,
		          COL_ANNEE, annee,
                       -1);}
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("staff",celrender,"text",COL_STAFF,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview1),col);


	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("type",celrender,"text",COL_TYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview1),col);


	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("heure",celrender,"text",COL_HEURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview1),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("jour",celrender,"text",COL_JOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview1),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("mois",celrender,"text",COL_MOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview1),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("annee",celrender,"text",COL_ANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview1),col);



	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview1), GTK_TREE_MODEL (liststore));

}
fclose(f);
}


void a_modifier(char nom[],char type[],char heure[],int jour,int mois,int annee)
{    
char nom1[30]; char heure1[30];char type1[30];
int jour1, mois1,annee1;
    FILE *f , *tmp;
    f=fopen("src/seance.txt","r");
    tmp=fopen("src/tmp.txt","a+");
    while(fscanf(f,"%s %s %s %d %d %d ",nom1,type1,heure1,&jour1,&mois1,&annee1)!=EOF){
        if(!strcmp(nom,nom1)){fprintf(tmp,"%s %s %s %d %d %d\n",nom,type,heure,jour,mois,annee);}
else fprintf(tmp,"%s %s %s %d %d %d \n",nom1,type1,heure1,jour1,mois1,annee1);
}
fclose(f);
fclose(tmp);
rename("src/tmp.txt","src/seance.txt");
}                 

void a_modifier1(char staff[],char type[],char heure[],int jour,int mois,int annee)
{    
char staff1[30]; char heure1[30];char type1[30];
int jour1, mois1,annee1;
    FILE *f , *tmp1;
    f=fopen("src/seance1.txt","r");
    tmp1=fopen("src/tmp1.txt","a+");
    while(fscanf(f,"%s %s %s %d %d %d ",staff1,type1,heure1,&jour1,&mois1,&annee1)!=EOF){
        if(!strcmp(staff,staff1)){fprintf(tmp1,"%s %s %s %d %d %d\n",staff,type,heure,jour,mois,annee);}
else fprintf(tmp1,"%s %s %s %d %d %d \n",staff1,type1,heure1,jour1,mois1,annee1);
}
fclose(f);
fclose(tmp1);
rename("src/tmp1.txt","src/seance1.txt");
}             

void a_modifier2(char nom[],char prenom[],char date[],char email[],char cin[],char adresse[],char poids[], char objectif[])
{    
    char nom1[50],prenom1[50],date1[50],email1[50],cin1[50],adresse1[50],poids1[50],objectif1[50];
   
   
    FILE *f , *tmp;
    f=fopen("src/profil.txt","r");
    tmp=fopen("src/profil1.txt","a+");
    while(fscanf(f,"%s %s %s %s %s %s %s %s\n",nom1,prenom1,date1,email1,cin1,adresse1,poids1,objectif1)!=EOF){
        if(!strcmp(nom,nom1) && !strcmp(prenom,prenom1) && !strcmp(date,date1) && !strcmp(cin,cin1) ){fprintf(tmp,"%s %s %s %s %s %s %s %s\n",nom,prenom,date,email,cin,adresse,poids,objectif);}
else fprintf(tmp,"%s %s %s %s %s %s %s %s\n",nom1,prenom1,date1,email1,cin1,adresse1,poids1,objectif1);
}
fclose(f);
fclose(tmp);
rename("src/profil1.txt","src/profil.txt");
} 
                 
 void a_supprimer(char nom[],char type[],char heure[],char jour[],char mois[],char annee[])
{    
   char nom1[50]; char type1[50];char heure1[50];char jour1[50];char mois1[50];char annee1[50];
    FILE *f , *tmp;
    f=fopen("src/seance.txt","r");
    tmp=fopen("src/tmp.txt","a+");
    while(fscanf(f,"%s %s %s %s %s %s ",nom1,type1,heure1,jour1,mois1,annee1)!=EOF){
        if(!strcmp(nom,nom1)) {continue;}
else fprintf(tmp,"%s %s %s %s %s %s \n",nom1,type1,heure1,jour1,mois1,annee1);
}
fclose(f);
fclose(tmp);
rename("src/tmp.txt","src/seance.txt");
}           

void a_supprimer1(char staff[],char type[],char heure[],char jour[],char mois[],char annee[])
{    
   char staff1[50];char type1[50];char heure1[50];char jour1[50];char mois1[50];char annee1[50];
    FILE *f , *tmp1;
    f=fopen("src/seance1.txt","r");
    tmp1=fopen("src/tmp1.txt","a+");
    while(fscanf(f,"%s %s %s %s %s %s ",staff1,type1,heure1,jour1,mois1,annee1)!=EOF){
        if(!strcmp(staff,staff1)) {continue;}
else fprintf(tmp1,"%s %s %s %s %s %s \n",staff1,type1,heure1,jour1,mois1,annee1);
}
fclose(f);
fclose(tmp1);
rename("src/tmp1.txt","src/seance1.txt");
}                  
 //////////////greeting.c coach ////////////////



void ajouterc(char login[],char password[],int role)
{
	FILE *f;
	f = fopen("src/users.txt","a+");
	if(f!=NULL){
		fprintf(f,"%s %s %d\n", login, password, role);	
	}
	fclose(f);

}

void afficherc()
{
	FILE *f;
	f=fopen("src/users.txt","r");
	char login[20],password[20];
	int role;
	while(fscanf(f,"%s %s %d", login, password, &role)!=EOF){
		printf("%s %s %d\n", login, password, role);
	}
	fclose(f);
}

int verifierc(char login[],char password[])
{
	FILE *f;
	f=fopen("src/users.txt","r");
	int role;
	char login1[20],password1[20];
	while(fscanf(f,"%s %s %d\n", login1, password1, &role)!=EOF){
		if (strcmp(login1,login)==0 && strcmp(password1,password)==0)
		{
			fclose(f);
			return role;
		}
	}
	fclose(f);
	return(-1);
}
void afficher3c(GtkWidget *plistview)
{ 
enum { COL_IDENTIFIANT,
       COL_NOM,
       COL_PRENOM,
       COL_AGE,
       COL_POIDS,
       COL_ETAT_DE_LA_TENSION,
       COL_MALADIES,
       COL_OBSERVATIONS,
       NUM_COLS
      };
char identifiant[20],nom[20],prenom[30],etat_de_la_tension[20],maladies[20],observations[30];
int age,poids;
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("src/fichen.txt","r");
if(f!=NULL){
       while(fscanf(f,"%s %s %s %d %d %s %s %s",identifiant,nom,prenom,&age,&poids,etat_de_la_tension,maladies,observations)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          COL_IDENTIFIANT, identifiant,
      			  COL_NOM, nom,
       			  COL_PRENOM, prenom,
       			  COL_AGE, age,
       			  COL_POIDS, poids,
       			  COL_ETAT_DE_LA_TENSION, etat_de_la_tension,
      			  COL_MALADIES, maladies,
      			  COL_OBSERVATIONS, observations,
                       -1);}

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("identifiant",celrender,"text",COL_IDENTIFIANT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("nom",celrender,"text",COL_NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("prenom",celrender,"text",COL_PRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("age",celrender,"text",COL_AGE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
        
      
        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("poids",celrender,"text",COL_POIDS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("etat_de_la_tension",celrender,"text",COL_ETAT_DE_LA_TENSION,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("maladies",celrender,"text",COL_MALADIES,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
        
        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("observations",celrender,"text",COL_OBSERVATIONS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}

void afficher4c(GtkWidget *plistview)
{ 
enum { COL_COACH,
       COL_TYPE,
       COL_HEURE,
       COL_JOUR,
       COL_MOIS,
       COL_ANNEE,
       NUM_COLS
      };
char coach[20],type[20],heure[20],jour[20],mois[20],annee[20];

GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("src/seance.txt","r");
if(f!=NULL){
       while(fscanf(f,"%s %s %s %s %s %s",coach,type,heure,jour,mois,annee)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          
      			  COL_COACH, coach,
       			  COL_TYPE, type,
       			  COL_HEURE, heure,
       			  COL_JOUR, jour,
       			  COL_MOIS, mois,
      			  COL_ANNEE, annee,
      			 
                       -1);}

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("coach",celrender,"text",COL_COACH,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("type",celrender,"text",COL_TYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("heure",celrender,"text",COL_HEURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("jour",celrender,"text",COL_JOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
        
      
        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("mois",celrender,"text",COL_MOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("annee",celrender,"text",COL_ANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
        
        gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}


void afficher1c(GtkWidget *plistview)
{ 
enum { COL_DATE,
       COL_HEURE,
       NUM_COLS
      };
char date[20],heure[20];
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("src/dispoc.txt","r");
if(f!=NULL){
       while(fscanf(f,"%s %s ",date,heure)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          COL_DATE, date,
		          COL_HEURE, heure,
		         
                       -1);}
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("date",celrender,"text",COL_DATE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("heure",celrender,"text",COL_HEURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	

	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}
void afficher2c(GtkWidget *plistview)
{ 
enum { COL_DATE,
       COL_HEURE,
       COL_SALLE,
       COL_TYPE,
       NUM_COLS
      };
char date[20],heure[20],salle[30],type[20];
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("src/seancec.txt","r");
if(f!=NULL){
       while(fscanf(f,"%s %s %s %s ",date,heure,salle,type)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          COL_DATE, date,
		          COL_HEURE, heure,
                          COL_SALLE, salle,
                          COL_TYPE, type,
		         
                       -1);}
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("date",celrender,"text",COL_DATE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("heure",celrender,"text",COL_HEURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("salle",celrender,"text",COL_SALLE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
        
        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("type",celrender,"text",COL_TYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}
void ajouter_dispoc(dispoc c)
{
enum   
{       DATE,
        HEURE,
        COLUMNS
};

{

 FILE *f;
  f=fopen("src/dispoc.txt","a+");
  if(f!=NULL) 
  {
  fprintf(f,"%s %s \n",c.date,c.heure);
  fclose(f);

  }

}}
void modifierc(char date[], char heure[])
{
	char datec[20],heurec[20];
	FILE *F; 
	FILE *Ftempp;
        dispoc c;
        
        F=fopen("src/dispoc.txt","r");
	Ftempp=fopen ("src/tempc.txt","a+");
        
               while(fscanf(F,"%s %s ",datec,heurec)!=EOF){
		if( !strcmp(heure,heurec) ){
			fprintf(Ftempp,"%s %s \n",date,heure);	
		}else
		fprintf(Ftempp,"%s %s \n",datec,heurec);
	}
	fclose(F);
	fclose(Ftempp);
       
	rename ("src/tempc.txt","src/dispoc.txt");
}
void supprimerc(char date[40],char heure[40])
	{


        FILE *F; 
	FILE *Ftempp;
        char datek[40];char heurek[40];
	F=fopen("src/dispoc.txt","r");
	Ftempp=fopen ("src/tempc.txt","a+");
	if (F!=NULL){
	
		while (fscanf(F,"%s %s\n",datek,heurek
                                                    )!=EOF)
			{
			if(!strcmp(date,datek) && !strcmp(heure,heurek) ) 
				{ continue;}
else fprintf(Ftempp,"%s %s\n",datek,heurek);
			}
	
fclose(Ftempp);
fclose(F);
		    }


rename ("src/tempc.txt","src/dispoc.txt");
}
void ajouter_seance(seancec c)
{
enum   
{       DATE,
        HEURE,
        SALLE,
        TYPE,
        COLUMNS
};


{

 FILE *f;
  f=fopen("src/seancec.txt","a+");
  if(f!=NULL) 
  {
  fprintf(f,"%s %s %s %s \n",c.date,c.heure,c.salle,c.type);
  fclose(f);

  }

}}
void modifier1c(char date[],char heure[],char salle[],char type[]){
	char datec[20],heurec[20],sallec[30],typec[30];
	FILE *F1; 
	FILE *Ftemp;
        F1=fopen("src/seancec.txt","r");
	Ftemp=fopen ("src/temppc.txt","a+");
	while(fscanf(F1,"%s %s %s %s",datec,heurec,sallec,typec)!=EOF){
		if( !strcmp(heure,heurec) ){
			fprintf(Ftemp,"%s %s %s %s\n",date,heure,salle,type);	
		}else
		fprintf(Ftemp,"%s %s %s %s\n",datec,heurec,sallec,typec);
	}
	fclose(F1);
	fclose(Ftemp);
        
	rename ("/src/temppc.txt","src/seancec.txt");
}
void supprimer1c(char date[],char heure[],char salle[],char type[])
	{


        FILE *F; 
	FILE *Ftemp;
        char datec[40];char heurec[40]; char sallec[40]; char typec[40];
	F=fopen("src/seancec.txt","r");
	Ftemp=fopen ("src/temppc.txt","a+");
	if (F!=NULL){
	
		while (fscanf(F,"%s %s %s %s\n",datec,heurec,sallec,
                                                    typec)!=EOF)
			{
			if(!strcmp(date,datec) && !strcmp(heure,heurec) )
				{
				continue;
				}
else fprintf(Ftemp,"%s %s %s %s\n",datec,heurec,sallec,typec);
			}
	
fclose(Ftemp);
fclose(F);
		    }

rename ("src/temppc.txt","src/seancec.txt");
}


void modifier2c(char nom[],char prenom[],char date[],char email[],char cin[],char adresse[])
{     
    char nomc[50],prenomc[50],datec[50],emailc[50],cinc[50],adressec[50];
    
    
    FILE *f , *tmp;
    f=fopen("src/profilc.txt","r");
    tmp=fopen("src/profilc.tmp","a+");
    while(fscanf(f,"%s %s %s %s %s %s\n",nomc,prenomc,datec,emailc,cinc,adressec)!=EOF){
        if(!strcmp(nom,nomc) && !strcmp(prenom,prenomc) && !strcmp(date,datec) && !strcmp(cin,cinc) ){fprintf(tmp,"%s %s %s %s %s %s\n",nom,prenom,date,email,cin,adresse);}
else fprintf(tmp,"%s %s %s %s %s %s\n",nomc,prenomc,datec,emailc,cinc,adressec);
}
fclose(f);
fclose(tmp);
rename("src/profilc.tmp","src/profilc.txt");
}                  




