#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "greeting.h"
#include "fonction.h"
#include "fc.h"
#include "dispo.h"





void
on_button1a_clicked    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
int x;
GtkWidget *a,*b,*c,*d,*window1a,*window2a;
char login[20];char password[20];
FILE* f;
window1a=lookup_widget(objet_graphique,"window1a");
a=lookup_widget(objet_graphique,"entry1a");
b=lookup_widget(objet_graphique,"entry2a");
c=lookup_widget(objet_graphique,"label3a");
d=lookup_widget(objet_graphique,"label5a");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(a)));
strcpy(password,gtk_entry_get_text(GTK_ENTRY(b)));
x=a_verifier(login,password);
if (x==1)
{ window2a=create_window2a();
gtk_widget_show(window2a);
gtk_widget_hide(window1a);
}
if (x==2)
{ window2a=create_window2n();
gtk_widget_show(window2a);
gtk_widget_hide(window1a);
}
if (x==3)
{ window2a=create_window2();
gtk_widget_show(window2a);
gtk_widget_hide(window1a);
}

if (x==4)
{ window2a=create_window2c();
gtk_widget_show(window2a);
gtk_widget_hide(window1a);
}

else {gtk_label_set_text(GTK_LABEL(d),"authentification non validée");
}
}

void
on_button2a_clicked                     (GtkWidget       *objet_graphique,    gpointer      user_data)
{
GtkWidget *window2a,*window3a,*List_View;



window3a=create_window3a();
gtk_widget_show(window3a);

gtk_widget_hide(window2a);
List_View=lookup_widget(window3a,"treeview1a");
a_afficher_tableau_event(List_View);
}


void
on_button4a_clicked                     (GtkWidget       *objet_graphique,  gpointer   user_data)
{
GtkWidget *window1a,*window2a;
window1a=create_window1a();
gtk_widget_show(window1a);
window2a=lookup_widget(objet_graphique,"window2a");

gtk_widget_hide(window2a);
}


void
on_button5a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2a,*window3a;
window3a=lookup_widget(objet_graphique,"window3a");
gtk_widget_hide(window3a);
}


void
on_button6a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3a,*window4a;
window3a= lookup_widget(objet_graphique,"window3a");
window4a= lookup_widget(objet_graphique,"window4a");
window4a=create_window4a();
gtk_widget_show(window4a);
gtk_widget_hide(window3a);
}

void
on_button17a_clicked                    (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window8a,*window12a;
window8a= lookup_widget(objet_graphique,"window8a");
window12a= lookup_widget(objet_graphique,"window12a");
window12a=create_window12a();
gtk_widget_show(window12a);
gtk_widget_hide(window8a);
}
 
void
on_button7a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *a;
GtkWidget *b;
GtkWidget *c;
GtkWidget *d;
GtkWidget *e;
GtkWidget *f;
GtkWidget *g;
GtkWidget *h;
GtkWidget *window2a,*window5a;
window5a=create_window5a();
gtk_widget_show(window5a);
gtk_widget_hide(window2a);
FILE *fic;
a=lookup_widget(window5a, "entry3a");
b=lookup_widget(window5a, "entry4a");
c=lookup_widget(window5a, "entry10a");
d=lookup_widget(window5a, "entry5a");
e=lookup_widget(window5a, "entry6a");
f=lookup_widget(window5a, "entry7a");
g=lookup_widget(window5a, "entry8a");
h=lookup_widget(window5a, "entry9a");
char nom1[50];
char prenom1[50];
char date1[50];
char email1[50];
char cin1[50];
char adresse1[50];
char poids1[50];
char objectif1[50];
char nom[50];
char prenom[50];
char date[50];
char email[50];
char cin[50];
char adresse[50];
char poids[50];
char objectif[50];
fic=fopen("src/profil.txt","r");

if (fic==NULL) printf("erreur\n");
else {
while (fscanf(fic,"%s %s %s %s %s %s %s %s",nom1,prenom1,date1,email1,cin1,adresse1,poids1,objectif1)!=EOF)
{ 
break;
}
fclose(fic);}
gtk_entry_set_text(GTK_ENTRY(a),nom1);
gtk_entry_set_text(GTK_ENTRY(b),prenom1);
gtk_entry_set_text(GTK_ENTRY(c),date1);
gtk_entry_set_text(GTK_ENTRY(d),email1);
gtk_entry_set_text(GTK_ENTRY(e),cin1);
gtk_entry_set_text(GTK_ENTRY(f),adresse1);
gtk_entry_set_text(GTK_ENTRY(g),poids1);
gtk_entry_set_text(GTK_ENTRY(h),objectif1);
}




void
on_button9a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2a,*window5a;
window5a=lookup_widget(objet_graphique,"window5a");
gtk_widget_hide(window5a);
}


void
on_button13a_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *heure;
GtkWidget *type;
GtkWidget *window4a;
GtkWidget *window3a;
GtkWidget *List_View;

seance s;


jour=lookup_widget(objet_graphique, "spinbutton4a");
mois=lookup_widget(objet_graphique, "spinbutton5a");
annee=lookup_widget(objet_graphique, "spinbutton6a");

heure=lookup_widget(objet_graphique, "combobox5a");
nom=lookup_widget(objet_graphique, "combobox2a");
type=lookup_widget(objet_graphique, "combobox12a");

s.dt_seance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
s.dt_seance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
s.dt_seance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));


strcpy(s.hr_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)));

strcpy(s.nom_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nom)));

strcpy(s.type_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));

a_ajout_seance( s);

window4a= lookup_widget(objet_graphique,"window4a");
window3a=create_window3a();
gtk_widget_hide(window4a);
List_View=lookup_widget(window3a,"treeview1a");
a_afficher_tableau_event(List_View);
gtk_widget_show(window3a);
}

void
on_button11a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3a,*window4a,*List_View;
window4a= lookup_widget(objet_graphique,"window4a");
window3a=create_window3a();
gtk_widget_hide(window4a);
List_View=lookup_widget(window3a,"treeview1a");
a_afficher_tableau_event(List_View);
gtk_widget_show(window3a);
}






void
on_button18a_clicked                    (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window8a,*window2a;
window8a=lookup_widget(objet_graphique,"window8a");
gtk_widget_hide(window8a);
}



void
on_button3a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
GtkWidget *window2a,*window8a,*List_View1;
window8a=create_window8a();
gtk_widget_show(window8a);
gtk_widget_hide(window2a);
List_View1=lookup_widget(window8a,"treeview2a");
a_afficher_tableau_event2(List_View1);

}


void
on_button21a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window8a,*window12a,*List_View;
window12a=lookup_widget(objet_graphique,"window12a");
window8a=create_window8a();
gtk_widget_hide(window12a);
List_View=lookup_widget(window8a,"treeview2a");
a_afficher_tableau_event2(List_View);
gtk_widget_show(window8a);
}


void
on_button20a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
GtkWidget *staff;
GtkWidget *type;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *heure;
GtkWidget *window8a;
GtkWidget *window12a;
GtkWidget *List_View;

seance1 s;


jour=lookup_widget(objet_graphique, "spinbutton9a");
mois=lookup_widget(objet_graphique, "spinbutton10a");
annee=lookup_widget(objet_graphique, "spinbutton11a");

heure=lookup_widget(objet_graphique, "combobox3a");
type=lookup_widget(objet_graphique, "combobox16a");
staff=lookup_widget(objet_graphique, "combobox4a");

s.dt_seance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
s.dt_seance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
s.dt_seance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));


strcpy(s.hr_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)));
strcpy(s.type_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));

strcpy(s.staff_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(staff)));

a_ajout_seance1( s);

window12a=lookup_widget(objet_graphique,"window12a");
window8a=create_window8a();
gtk_widget_hide(window12a);
List_View=lookup_widget(window8a,"treeview2a");
a_afficher_tableau_event2(List_View);
gtk_widget_show(window8a);
}
void
on_treeview1a_row_activated             (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,  
                                        gpointer         user_data)
{
GtkWidget *coach1,*type1,*heure1,*jour1,*mois1,*annee1,*window13a,*window3a,*treeview;
    gchar *coach,*heure,*type;
    gint *jour,*mois,*annee;
    window13a=create_window13a();
	treeview=lookup_widget(objet_graphique,"treeview1a");
window3a=lookup_widget(objet_graphique,"window3a");
    coach1=lookup_widget(window13a,"combobox7a");
    type1=lookup_widget(window13a,"combobox12a");
    heure1=lookup_widget(window13a,"combobox6a");
    jour1=lookup_widget(window13a,"spinbutton12a");
    mois1=lookup_widget(window13a,"spinbutton13a");
    annee1=lookup_widget(window13a,"spinbutton14a");
    GtkTreeIter iter;
    GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview));
    gtk_tree_model_get_iter(model,&iter,path);
    gtk_tree_model_get (model,&iter,0,&coach,1,&type,2,&heure,3,&jour,4,&mois,5,&annee,-1);
    printf("%s %s %s %s %s %s",coach,type,heure,jour,mois,annee);
    gtk_entry_set_text(GTK_ENTRY (coach1),_(coach));
	if (!strcmp(coach,"Ahmed"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(coach1),0);
	if (!strcmp(coach,"Amine"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(coach1),1);
	if (!strcmp(coach,"Mouhamed"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(coach1),2);
	if (!strcmp(coach,"Saif"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(coach1),3);
	if (!strcmp(coach,"Sami"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(coach1),4);


    gtk_entry_set_text(GTK_ENTRY (type1),_(type));
if (!strcmp(type,"zumba"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(type1),0);
if (!strcmp(type,"musculation"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(type1),1);
if (!strcmp(type,"salsa"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(type1),2);
if (!strcmp(type,"boxe"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(type1),3);
if (!strcmp(type,"aérobic"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(type1),4);
if (!strcmp(type,"aikido"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(type1),5);
if (!strcmp(type,"karaté"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(type1),6);
if (!strcmp(type,"yoga"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(type1),7);


    gtk_entry_set_text(GTK_ENTRY (heure1),_(heure));
if (!strcmp(heure,"9h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),0);
if (!strcmp(heure,"10h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),1);
if (!strcmp(heure,"11h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),2);
if (!strcmp(heure,"12h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),3);
if (!strcmp(heure,"13h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),4);
if (!strcmp(heure,"14h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),5);
if (!strcmp(heure,"15h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),6);



    gtk_entry_set_text(GTK_ENTRY (jour1),_(jour));
    gtk_entry_set_text(GTK_ENTRY (mois1),_(mois));
    gtk_entry_set_text(GTK_ENTRY (annee1),_(annee));
    gtk_widget_hide(window3a);
    gtk_widget_show(window13a);
}


void
on_treeview2a_row_activated             (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,  
                                        gpointer         user_data)
{
GtkWidget *staff1,*type1,*heure1,*jour1,*mois1,*annee1,*window14a,*window8a,*treeview;
    gchar *staff,*heure,*type;
    gint *jour,*mois,*annee;
    window14a=create_window14a();
	treeview=lookup_widget(objet_graphique,"treeview2a");
window8a=lookup_widget(objet_graphique,"window8a");
    staff1=lookup_widget(window14a,"combobox9a");
    type1=lookup_widget(window14a,"combobox15a");
    heure1=lookup_widget(window14a,"combobox8a");
    jour1=lookup_widget(window14a,"spinbutton15a");
    mois1=lookup_widget(window14a,"spinbutton17a");
    annee1=lookup_widget(window14a,"spinbutton18a");
    GtkTreeIter iter;
    GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview));
    gtk_tree_model_get_iter(model,&iter,path);
    gtk_tree_model_get (model,&iter,0,&staff,1,&type,2,&heure,3,&jour,4,&mois,5,&annee,-1);
    printf("%s %s %s %s %s %s",staff,type,heure,jour,mois,annee);
    gtk_entry_set_text(GTK_ENTRY (staff1),_(staff));
    if (!strcmp(staff,"dietitien"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(staff1),0);  
	if (!strcmp(staff,"nutritionniste"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(staff1),1);   
	if (!strcmp(staff,"kiné"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(staff1),2);   


    gtk_entry_set_text(GTK_ENTRY (type1),_(type));
    if (!strcmp(type,"massage_mainceur"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(type1),0); 
	if (!strcmp(type,"massage_lymphatique"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(type1),1); 
if (!strcmp(type,"régime_végétarien"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(type1),2); 
if (!strcmp(type,"régime_anti_cholestérol"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(type1),3); 
	if (!strcmp(type,"régime_végétalien"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(type1),4); 
  

    gtk_entry_set_text(GTK_ENTRY (heure1),_(heure));
    if (!strcmp(heure,"9h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),0);
    if (!strcmp(heure,"10h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),1);
     if (!strcmp(heure,"11h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),2);
     if (!strcmp(heure,"12h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),3);
	if (!strcmp(heure,"13h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),4);
	if (!strcmp(heure,"14h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),5);
	if (!strcmp(heure,"15h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heure1),6);

 


    gtk_entry_set_text(GTK_ENTRY (jour1),_(jour));
    gtk_entry_set_text(GTK_ENTRY (mois1),_(mois));
    gtk_entry_set_text(GTK_ENTRY (annee1),_(annee));
    gtk_widget_hide(window8a);
    gtk_widget_show(window14a);
}
void
on_button26a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom1,*type1,*heure1,*jour1,*mois1,*annee1,*window13a,*window3a,*List_View;
seance s;
char nom[20],heure[20],type[20];
int jour,mois,annee;
    nom1=lookup_widget(objet_graphique,"combobox7a");
    type1=lookup_widget(objet_graphique,"combobox14a");
    heure1=lookup_widget(objet_graphique,"combobox6a");
    jour1=lookup_widget(objet_graphique,"spinbutton12a");
    mois1=lookup_widget(objet_graphique,"spinbutton13a");
    annee1=lookup_widget(objet_graphique,"spinbutton14a");
    strcpy(s.hr_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure1)));
    strcpy(s.type_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type1)));
    strcpy(s.nom_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nom1)));
s.dt_seance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour1));
s.dt_seance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois1));
s.dt_seance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee1));

a_modifier(s.nom_seance,s.type_seance,s.hr_seance,s.dt_seance.jour,s.dt_seance.mois,s.dt_seance.annee);
window13a= lookup_widget(objet_graphique,"window13a");
window3a= lookup_widget(objet_graphique,"window3a");
window3a=create_window3a();
gtk_widget_hide(window13a);
List_View=lookup_widget(window3a,"treeview1a");
a_afficher_tableau_event(List_View);
gtk_widget_show(window3a);
}


void
on_button27a_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom1,*type1,*heure1,*jour1,*mois1,*annee1,*window13a,*List_View,*window3a;
seance s;
char nom[50],type[50],heure[50],jour[50],mois[50],annee[50];
    nom1=lookup_widget(objet_graphique,"combobox7a");
    type1=lookup_widget(objet_graphique,"combobox14a");
    heure1=lookup_widget(objet_graphique,"combobox6a");
    jour1=lookup_widget(objet_graphique,"spinbutton12a");
    mois1=lookup_widget(objet_graphique,"spinbutton13a");
    annee1=lookup_widget(objet_graphique,"spinbutton14a");
    strcpy(s.hr_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure1)));
    strcpy(s.nom_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(nom1)));
    strcpy(s.type_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type1)));
s.dt_seance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour1));
s.dt_seance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois1));
s.dt_seance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee1));

a_supprimer(s.nom_seance,s.type_seance,s.hr_seance,s.dt_seance.jour,s.dt_seance.mois,s.dt_seance.annee);
window13a= lookup_widget(objet_graphique,"window13a");
window3a= lookup_widget(objet_graphique,"window3a");
window3a=create_window3a();
gtk_widget_hide(window13a);
List_View=lookup_widget(window3a,"treeview1a");
a_afficher_tableau_event(List_View);
gtk_widget_show(window3a);    
}





void
on_button28a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *staff1,*type1,*heure1,*jour1,*mois1,*annee1,*window14a,*window8a,*List_View;
seance1 s;
char staff[20],type[20],heure[20];
int jour,mois,annee;
    staff1=lookup_widget(objet_graphique,"combobox9a");
    heure1=lookup_widget(objet_graphique,"combobox8a");
    type1=lookup_widget(objet_graphique,"combobox15a");
    jour1=lookup_widget(objet_graphique,"spinbutton15a");
    mois1=lookup_widget(objet_graphique,"spinbutton17a");
    annee1=lookup_widget(objet_graphique,"spinbutton18a");
    strcpy(s.hr_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure1)));
    strcpy(s.staff_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(staff1)));
    strcpy(s.type_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type1)));
s.dt_seance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour1));
s.dt_seance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois1));
s.dt_seance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee1));

a_modifier1(s.staff_seance,s.type_seance,s.hr_seance,s.dt_seance.jour,s.dt_seance.mois,s.dt_seance.annee);
    window14a= lookup_widget(objet_graphique,"window14a");
window8a=create_window8a();
gtk_widget_hide(window14a);
List_View=lookup_widget(window8a,"treeview2a");
a_afficher_tableau_event2(List_View);
gtk_widget_show(window8a);

}


void
on_button29a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *staff1,*type1,*heure1,*jour1,*mois1,*annee1,*window14a,*List_View,*window8a;
seance1 s;
char staff[50],type[50],heure[50],jour[50],mois[50],annee[50];
    staff1=lookup_widget(objet_graphique,"combobox9a");
    type1=lookup_widget(objet_graphique,"combobox15a");
    heure1=lookup_widget(objet_graphique,"combobox8a");
    jour1=lookup_widget(objet_graphique,"spinbutton15a");
    mois1=lookup_widget(objet_graphique,"spinbutton17a");
    annee1=lookup_widget(objet_graphique,"spinbutton18a");
    strcpy(s.hr_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure1)));
    strcpy(s.staff_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(staff1)));
    strcpy(s.type_seance,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type1)));
s.dt_seance.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour1));
s.dt_seance.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois1));
s.dt_seance.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee1));

a_supprimer1(s.staff_seance,s.type_seance,s.hr_seance,s.dt_seance.jour,s.dt_seance.mois,s.dt_seance.annee);
      window14a= lookup_widget(objet_graphique,"window14a");
window8a=create_window8a();
gtk_widget_hide(window14a);
List_View=lookup_widget(window8a,"treeview2a");
a_afficher_tableau_event2(List_View);
gtk_widget_show(window8a);

}


void
on_button30a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3a,*window13a,*List_View;
window13a= lookup_widget(objet_graphique,"window13a");
window3a=create_window3a();
gtk_widget_hide(window13a);
List_View=lookup_widget(window3a,"treeview1a");
a_afficher_tableau_event(List_View);
gtk_widget_show(window3a);
}


void
on_button31a_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window8a,*window14a,*List_View;
window14a= lookup_widget(objet_graphique,"window14a");
window8a=create_window8a();
gtk_widget_hide(window14a);
List_View=lookup_widget(window8a,"treeview2a");
a_afficher_tableau_event2(List_View);
gtk_widget_show(window8a);
}





void
on_button32a_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom,*prenom,*date,*email,*cin,*adresse,*poids,*objectif,*window5a,*window2a;
    char nom1[50],prenom1[50],date1[50],email1[50],cin1[50],adresse1[50],poids1[50],objectif1[50];
   
    nom=lookup_widget(objet_graphique,"entry3a");
    prenom=lookup_widget(objet_graphique,"entry4a");
    date=lookup_widget(objet_graphique,"entry10a");
    email=lookup_widget(objet_graphique,"entry5a");
    cin=lookup_widget(objet_graphique,"entry6a");
    adresse=lookup_widget(objet_graphique,"entry7a");
    poids=lookup_widget(objet_graphique,"entry8a");
    objectif=lookup_widget(objet_graphique,"entry9a");
   
    strcpy(nom1,gtk_entry_get_text(GTK_ENTRY(nom)));
    strcpy(prenom1,gtk_entry_get_text(GTK_ENTRY(prenom)));
    strcpy(date1,gtk_entry_get_text(GTK_ENTRY(date)));
    strcpy(email1,gtk_entry_get_text(GTK_ENTRY(email)));
    strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(cin)));
    strcpy(adresse1,gtk_entry_get_text(GTK_ENTRY(adresse)));
    strcpy(poids1,gtk_entry_get_text(GTK_ENTRY(poids)));
    strcpy(objectif1,gtk_entry_get_text(GTK_ENTRY(objectif)));
   
    a_modifier2(nom1,prenom1,date1,email1,cin1,adresse1,poids1,objectif1);
    //window2a=create_window2a();
    //gtk_widget_show (window2a);
    window5a=lookup_widget(objet_graphique,"window5a");
    gtk_widget_hide(window5a);
   
}

///////////////////////////////////////callbacks.c nutrtionniste////////////////////////////////

void
on_button2n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button3n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3n,*window2n,*List_View;
window3n=create_window3n();
gtk_widget_show (window3n);
window2n=lookup_widget(objet_graphique,"window2n");
gtk_widget_hide(window2n);
List_View=lookup_widget(window3n,"treeview1");
afficher1n(List_View);
 

}


void
on_button4n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *a,*b,*c,*d,*e,*f,*window4n,*window2n;
window4n=create_window4n();
gtk_widget_show (window4n);
window2n=lookup_widget(objet_graphique,"window2n");
gtk_widget_hide(window2n);
FILE *fic;
a=lookup_widget(window4n,"entry1000n");
b=lookup_widget(window4n,"entry2");
c=lookup_widget(window4n,"entry1002n");
d=lookup_widget(window4n,"entry1003n");
e=lookup_widget(window4n,"entry1004n");
f=lookup_widget(window4n,"entry1005n");
char nom1[20],prenom1[20],date1[20],email1[20],cin1[20],adresse1[20],nom[20],prenom[20],date[20],email[20],cin[20],adresse[20];
fic=fopen("src/profiln.txt","r");

if (fic==NULL) printf("erreur\n");
else {
while (fscanf(fic,"%s %s %s %s %s %s",nom1,prenom1,date1,email1,cin1,adresse1)!=EOF)
{break;}
fclose(fic);}

gtk_entry_set_text(GTK_ENTRY(a),nom1);
gtk_entry_set_text(GTK_ENTRY(b),prenom1);
gtk_entry_set_text(GTK_ENTRY(c),date1);
gtk_entry_set_text(GTK_ENTRY(d),email1);
gtk_entry_set_text(GTK_ENTRY(e),cin1);
gtk_entry_set_text(GTK_ENTRY(f),adresse1);
}





void
on_button5n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5n,*window2n,*List_View;
window5n=create_window5n();
gtk_widget_show (window5n);
window2n=lookup_widget(objet_graphique,"window2n");
gtk_widget_hide(window2n);
List_View=lookup_widget(window5n,"treeview100n");
afficher2n(List_View);

}


void
on_button6n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1n,*window2n;
window1n=create_window1a();
gtk_widget_show (window1n);
window2n=lookup_widget(objet_graphique,"window2n");
gtk_widget_hide(window2n);
}


void
on_button7n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3n,*window2n;
window2n=create_window2n();
gtk_widget_show (window2n);
window3n=lookup_widget(objet_graphique,"window3n");
gtk_widget_hide(window3n);
}


void
on_button8n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3n,*window6n;
window6n=create_window6n();
gtk_widget_show (window6n);
window3n=lookup_widget(objet_graphique,"window3n");
gtk_widget_hide(window3n);
}


void
on_button50n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *identifiant ,*nom,*prenom,*age,*poids,*tension,*maladies,*observations ,*window3n,*window6n,*List_View;
	adherant a;
	
	identifiant=lookup_widget(objet_graphique,"entry51n");
	nom=lookup_widget(objet_graphique,"entry52n");
	prenom=lookup_widget(objet_graphique,"entry53n");
	age=lookup_widget(objet_graphique,"spinbutton1n");
	poids=lookup_widget(objet_graphique,"spinbutton2n");
	tension=lookup_widget(objet_graphique,"comboboxentry1n");
	maladies=lookup_widget(objet_graphique,"comboboxentry2n");
	observations=lookup_widget(objet_graphique,"entry54n");

	strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

	a.age=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (age));
	a.poids=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (poids));

	strcpy(a.tension,gtk_combo_box_get_active_text (GTK_COMBO_BOX(tension)));
	strcpy(a.maladies,gtk_combo_box_get_active_text (GTK_COMBO_BOX(maladies)));

	strcpy(a.observations,gtk_entry_get_text(GTK_ENTRY(observations)));

        ajoutern(a);

	window3n=create_window3n();
	window6n=lookup_widget(objet_graphique,"window6n");
	gtk_widget_hide(window6n);
	List_View=lookup_widget(window3n,"treeview1");
	afficher1n(List_View);
	gtk_widget_show (window3n);
	
}


void
on_button67n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *identifiant,*nom,*prenom,*age,*poids,*tension,*maladies,*observations,*current,*window3n,*window7n,*List_View;
	char identifiantk[20],nomk[20],prenomk[20],tensionk[20],maladiesk[20],observationsk[20];
	int agek,poidsk;
	identifiant=lookup_widget(objet_graphique,"entry61n");
	nom=lookup_widget(objet_graphique,"entry62n");
	prenom=lookup_widget(objet_graphique,"entry63n");
	age=lookup_widget(objet_graphique,"spinbutton60n");
	poids=lookup_widget(objet_graphique,"spinbutton65n");
	tension=lookup_widget(objet_graphique,"comboboxentry66n");
	maladies=lookup_widget(objet_graphique,"comboboxentry67n");
	observations=lookup_widget(objet_graphique,"entry67n");
	strcpy(identifiantk,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	strcpy(nomk,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(prenomk,gtk_entry_get_text(GTK_ENTRY(prenom)));
	agek = gtk_spin_button_get_value_as_int(age);
	poidsk = gtk_spin_button_get_value_as_int(poids);
	strcpy(tensionk,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tension)));
	strcpy(maladiesk,gtk_combo_box_get_active_text(GTK_COMBO_BOX(maladies)));
	strcpy(observationsk,gtk_entry_get_text(GTK_ENTRY(observations)));
	modifiern(identifiantk,nomk,prenomk,agek,poidsk,tensionk,maladiesk,observationsk);
	window3n=create_window3n();
	gtk_widget_show (window3n);
	current=lookup_widget(objet_graphique,"window7n");
	gtk_widget_hide(current);
	List_View=lookup_widget(window3n,"treeview1");
	afficher1n(List_View);
}


void
on_button68n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *identifiant,*nom,*prenom,*age,*poids,*tension,*maladies,*observations,*current,*window3n,*window7n,*List_View;
	char identifiantk[20],nomk[20],prenomk[20],tensionk[20],maladiesk[20],observationsk[20];
	int agek,poidsk;
	identifiant=lookup_widget(objet_graphique,"entry61n");
	nom=lookup_widget(objet_graphique,"entry62n");
	prenom=lookup_widget(objet_graphique,"entry63n");
	age=lookup_widget(objet_graphique,"spinbutton60n");
	poids=lookup_widget(objet_graphique,"spinbutton65n");
	tension=lookup_widget(objet_graphique,"comboboxentry66n");
	maladies=lookup_widget(objet_graphique,"comboboxentry67n");
	observations=lookup_widget(objet_graphique,"entry67n");
	strcpy(identifiantk,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	strcpy(nomk,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(prenomk,gtk_entry_get_text(GTK_ENTRY(prenom)));
	agek = gtk_spin_button_get_value_as_int(age);
	poidsk = gtk_spin_button_get_value_as_int(poids);
	strcpy(tensionk,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tension)));
	strcpy(maladiesk,gtk_combo_box_get_active_text(GTK_COMBO_BOX(maladies)));
	strcpy(observationsk,gtk_entry_get_text(GTK_ENTRY(observations)));
	supprimern(identifiantk,nomk,prenomk,agek,poidsk,tensionk,maladiesk,observationsk);
	window3n=create_window3n();
	gtk_widget_show (window3n);
	current=lookup_widget(objet_graphique,"window7n");
	gtk_widget_hide(current);
	List_View=lookup_widget(window3n,"treeview1");
	afficher1n(List_View);
}


void
on_button69n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 GtkWidget *window3n,*window7n,*List_View;
window3n=create_window3n();
gtk_widget_show (window3n);
window7n=lookup_widget(objet_graphique,"window7n");
gtk_widget_hide(window7n);
List_View=lookup_widget(window3n,"treeview1");
afficher1n(List_View);
}


void
on_treeview1_row_activated             (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkWidget *identifiantn,*nomn,*prenomn,*agen,*poidsn,*tensionn,*maladiesn,*observationsn,*window3n,*window7n,*treeview;
gchar *identifiant,*nom,*prenom,*tension,*maladies,*observations;
int age,poids;
	window7n=create_window7n();
	treeview=lookup_widget(objet_graphique,"treeview1");
	window3n=lookup_widget(objet_graphique,"window3n");
	identifiantn=lookup_widget(window7n,"entry61n");
	nomn=lookup_widget(window7n,"entry62n");
	prenomn=lookup_widget(window7n,"entry63n");
	agen=lookup_widget(window7n,"spinbutton60n");
	poidsn=lookup_widget(window7n,"spinbutton65n");
	tensionn=lookup_widget(window7n,"comboboxentry66n");
	maladiesn=lookup_widget(window7n,"comboboxentry67n");
	observationsn=lookup_widget(window7n,"entry67n");
	GtkTreeIter iter;
	GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview));
	gtk_tree_model_get_iter(model,&iter,path);
	gtk_tree_model_get (model,&iter,0,&identifiant,1,&nom,2,&prenom,3,&age,4,&poids,5,&tension,6,&maladies,7,&observations,-1);
	g_print("%s %s %s %d %d %s %s %s",identifiant,nom,prenom,age,poids,tension,maladies,observations);
	gtk_entry_set_text(GTK_ENTRY (identifiantn),_(identifiant));
	gtk_entry_set_text(GTK_ENTRY (nomn),_(nom));
	gtk_entry_set_text(GTK_ENTRY (prenomn),_(prenom));
	gtk_spin_button_set_value(GTK_SPIN_BUTTON (agen),age);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON (poidsn),poids);
	gtk_entry_set_text(GTK_ENTRY (tensionn),_(tension));
	if (!strcmp(tension,"hypotension"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(tensionn),0);
	if (!strcmp(tension,"hypertension"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(tensionn),1);
	if (!strcmp(tension,"tension_normale"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(tensionn),2);
	if (!strcmp(tension,"autres_maladies"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(tensionn),3);


	gtk_entry_set_text(GTK_ENTRY (maladiesn),_(maladies));
	if (!strcmp(maladies,"diabète"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(maladiesn),0);
	if (!strcmp(maladies,"obésité"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(maladiesn),1);
	if (!strcmp(maladies,"autre"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(maladiesn),2);

	gtk_entry_set_text(GTK_ENTRY (observationsn),_(observations));
	gtk_widget_hide(window3n);
	gtk_widget_show(window7n);

		
}


void
on_button99n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3n,*window6n,*List_View;
window3n=create_window3n();
gtk_widget_show (window3n);
window6n=lookup_widget(objet_graphique,"window6n");
gtk_widget_hide(window6n);
List_View=lookup_widget(window3n,"treeview1");
afficher1n(List_View);
}


void
on_button98n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2n,*window4n;
window2n=create_window2n();
gtk_widget_show (window2n);
window4n=lookup_widget(objet_graphique,"window4n");
gtk_widget_hide(window4n);
}


void
on_button97n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2n,*window5n;
window2n=create_window2n();
gtk_widget_show (window2n);
window5n=lookup_widget(objet_graphique,"window5n");
gtk_widget_hide(window5n);
}


void
on_button101n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5n,*window8n;
window8n=create_window8n();
gtk_widget_show (window8n);
window5n=lookup_widget(objet_graphique,"window5n");
gtk_widget_hide(window5n);
}


void
on_button102n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
GtkWidget *jour1,*jour,*mois,*annee,*heure,*window5n,*window8n,*List_View;
	dispo d;
	
	
	jour1=lookup_widget(objet_graphique,"comboboxentry108n");
	jour=lookup_widget(objet_graphique,"spinbutton400n");
	mois=lookup_widget(objet_graphique,"spinbutton401n");
	annee=lookup_widget(objet_graphique,"spinbutton402n");
	heure=lookup_widget(objet_graphique,"comboboxentry110n");

	

	strcpy(d.jour1,gtk_combo_box_get_active_text (GTK_COMBO_BOX(jour1)));
	d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
	d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
	d.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
	strcpy(d.heure,gtk_combo_box_get_active_text (GTK_COMBO_BOX(heure)));
	

        ajouter1n(d);

	window5n=create_window5n();
	window8n=lookup_widget(objet_graphique,"window8n");
	gtk_widget_hide(window8n);
	List_View=lookup_widget(window5n,"treeview100n");
	afficher2n(List_View);
	gtk_widget_show (window5n);
	
}


void
on_button103n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window8n,*window5n,*List_View;
window5n=create_window5n();
gtk_widget_show (window5n);
window8n=lookup_widget(objet_graphique,"window8n");
gtk_widget_hide(window8n);
List_View=lookup_widget(window5n,"treeview100n");
afficher2n(List_View);


}


void
on_button201n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *jour1,*jour,*mois,*annee,*heure,*current,*window9n,*window5n,*List_View;
	char jour1k[20],heurek[20];
	int jourk,moisk,anneek;
	jour1=lookup_widget(objet_graphique,"comboboxentry201n");
	jour=lookup_widget(objet_graphique,"spinbutton600n");
	mois=lookup_widget(objet_graphique,"spinbutton601n");
	annee=lookup_widget(objet_graphique,"spinbutton602n");
	heure=lookup_widget(objet_graphique,"comboboxentry203n");
	
	strcpy(jour1k,gtk_combo_box_get_active_text(GTK_COMBO_BOX(jour1)));
	jourk = gtk_spin_button_get_value_as_int(jour);
	moisk = gtk_spin_button_get_value_as_int(mois);
	anneek = gtk_spin_button_get_value_as_int(annee);
	strcpy(heurek,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)));
	
	modifier1n(jour1k,jourk,moisk,anneek,heurek);
	window5n=create_window5n();
	gtk_widget_show (window5n);
	current=lookup_widget(objet_graphique,"window9n");
	gtk_widget_hide(current);
	List_View=lookup_widget(window5n,"treeview100n");
	afficher2n(List_View);
}


void
on_button202n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *jour1,*jour,*mois,*annee,*heure,*current,*window9n,*window5n,*List_View;
	char jour1k[20],heurek[20];
	int jourk,moisk,anneek;
	jour1=lookup_widget(objet_graphique,"comboboxentry201n");
	jour=lookup_widget(objet_graphique,"spinbutton600n");
	mois=lookup_widget(objet_graphique,"spinbutton601n");
	annee=lookup_widget(objet_graphique,"spinbutton602n");
	heure=lookup_widget(objet_graphique,"comboboxentry203n");
	
	strcpy(jour1k,gtk_combo_box_get_active_text(GTK_COMBO_BOX(jour1)));
	jourk = gtk_spin_button_get_value_as_int(jour);
	moisk = gtk_spin_button_get_value_as_int(mois);
	anneek = gtk_spin_button_get_value_as_int(annee);
	strcpy(heurek,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)));
	
	supprimer1n(jour1k,jourk,moisk,anneek,heurek);
	window5n=create_window5n();
	gtk_widget_show (window5n);
	current=lookup_widget(objet_graphique,"window9n");
	gtk_widget_hide(current);
	List_View=lookup_widget(window5n,"treeview100n");
	afficher2n(List_View);
}


void
on_button203n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window9n,*window5n,*List_View;
window5n=create_window5n();
gtk_widget_show (window5n);
window9n=lookup_widget(objet_graphique,"window9n");
gtk_widget_hide(window9n);
List_View=lookup_widget(window5n,"treeview100n");
afficher2n(List_View);

}


void
on_treeview100n_row_activated          (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *jour1n,*journ,*moisn,*anneen,*heuren,*window9n,*window5n,*treeview;
gchar *jour1,*heure;
int jour,mois,annee;
	window9n=create_window9n();
	treeview=lookup_widget(objet_graphique,"treeview100n");
	window5n=lookup_widget(objet_graphique,"window5n");
	jour1n=lookup_widget(window9n,"comboboxentry201n");
	journ=lookup_widget(window9n,"spinbutton600n");
	moisn=lookup_widget(window9n,"spinbutton601n");
	anneen=lookup_widget(window9n,"spinbutton602n");
	heuren=lookup_widget(window9n,"comboboxentry203n");
	GtkTreeIter iter;
	GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview));
	gtk_tree_model_get_iter(model,&iter,path);
	gtk_tree_model_get (model,&iter,0,&jour1,1,&jour,2,&mois,3,&annee,4,&heure,-1);
	g_print("%s %d %d %d %s",jour1,jour,mois,annee,heure);
	gtk_entry_set_text(GTK_ENTRY (jour1n),_(jour1));
	if (!strcmp(jour1,"Lundi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),0);
	if (!strcmp(jour1,"Mardi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),1);
	if (!strcmp(jour1,"Mercredi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),2);
	if (!strcmp(jour1,"Jeudi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),3);
	if (!strcmp(jour1,"Vendredi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),4);
	if (!strcmp(jour1,"Samedi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),5);
	if (!strcmp(jour1,"Dimanche"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),6);

	gtk_spin_button_set_value(GTK_SPIN_BUTTON (journ),jour);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON (moisn),mois);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON (anneen),annee);
	
	gtk_entry_set_text(GTK_ENTRY (heuren),_(heure));
	if (!strcmp(heure,"8h/9h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),0);
	if (!strcmp(heure,"9h/10h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),1);
	if (!strcmp(heure,"10h/11h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),2);
	if (!strcmp(heure,"11h/12h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),3);
	if (!strcmp(heure,"15h/16h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),4);
	if (!strcmp(heure,"16h/17h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),5);
	




	gtk_widget_hide(window5n);
	gtk_widget_show(window9n);
}






void
on_button5000n_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom,*prenom,*date,*email,*cin,*adresse,*current,*window2n,*window4n;
	char nomk[50],prenomk[50],datek[50],emailk[50],cink[50],adressek[50];
	
	nom=lookup_widget(objet_graphique,"entry1000n");
	prenom=lookup_widget(objet_graphique,"entry2");
	date=lookup_widget(objet_graphique,"entry1002n");
	email=lookup_widget(objet_graphique,"entry1003n");
	cin=lookup_widget(objet_graphique,"entry1004n");
	adresse=lookup_widget(objet_graphique,"entry1005n");
	
	strcpy(nomk,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(prenomk,gtk_entry_get_text(GTK_ENTRY(prenom)));
	strcpy(datek,gtk_entry_get_text(GTK_ENTRY(date)));
	strcpy(emailk,gtk_entry_get_text(GTK_ENTRY(email)));
	strcpy(cink,gtk_entry_get_text(GTK_ENTRY(cin)));
	strcpy(adressek,gtk_entry_get_text(GTK_ENTRY(adresse)));
	
	modifier2n(nomk,prenomk,datek,emailk,cink,adressek);
	//window2n=create_window2n();
	//gtk_widget_show (window2n);
	//current=lookup_widget(objet_graphique,"window4n");
	//gtk_widget_hide(current);
	
}


void
on_button6000n_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2n,*window10n,*List_View;
window10n=create_window10n();
gtk_widget_show (window10n);
window2n=lookup_widget(objet_graphique,"window2n");
gtk_widget_hide(window2n);
List_View=lookup_widget(window10n,"treeview6000n");
afficher3n(List_View);

}


void
on_button6001n_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window10n,*window2n;
window2n=create_window2n();
gtk_widget_show (window2n);
window10n=lookup_widget(objet_graphique,"window10n");
gtk_widget_hide(window10n);
}


/////////callbacks.c kine ///////////////////



void
on_button16k_clicked                    (GtkWidget      *objet_graphique16,
                                        gpointer         user_data)
{
GtkWidget *window2,*window4;
window2=lookup_widget(objet_graphique16,"window2");
window4=create_window4();
gtk_widget_show (window4);
gtk_widget_hide(window2);

}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button2k_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button5k_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window5,*window4,*List_View;
window5=create_window5();
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
List_View=lookup_widget(window5,"treeviewk11");
k_afficher_tableau_event(List_View);
gtk_widget_show (window5);

}





void
on_button14k_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button15k_clicked                    (GtkWidget      *objet_graphique15,
                                        gpointer         user_data)
{
GtkWidget *window2,*window4;
window4=lookup_widget(objet_graphique15,"window4");
window2=create_window2();
gtk_widget_show (window2);
gtk_widget_hide(window4);
}


void
on_button19k_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button18k_clicked                    (GtkWidget      *objet_graphique18,
                                        gpointer         user_data)
{
GtkWidget *window5,*window6;
window5=lookup_widget(objet_graphique18,"window5");
window6=create_window6();
gtk_widget_show (window6);
gtk_widget_hide(window5);
}


void
on_button20k_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom ,*prenom,*jour,*mois,*annee,*seancee ,*window5;
	
	 
        seancek s;
	nom=lookup_widget(objet_graphique,"entry7k");
	prenom=lookup_widget(objet_graphique,"entry8k");
	jour=lookup_widget(objet_graphique,"jourk");
        mois=lookup_widget(objet_graphique,"moisk");
        annee=lookup_widget(objet_graphique,"anneek");
	seancee=lookup_widget(objet_graphique,"combobox3k");
        strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(s.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
        s.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
        s.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
        s.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
        strcpy(s.seancee,gtk_combo_box_get_active_text (GTK_COMBO_BOX(seancee)));
        ajouterkk(s);
}


void
on_button22k_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5,*window6,*List_View;
window5=create_window5();
window6=lookup_widget(objet_graphique,"window6");
gtk_widget_hide(window6);
List_View=lookup_widget(window5,"treeviewk11");
k_afficher_tableau_event(List_View);
gtk_widget_show (window5);
}


void
on_button23k_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button24k_clicked                    (GtkWidget      *objet_graphique24,
                                        gpointer         user_data)
{
GtkWidget *window4,*window5;
window5=lookup_widget(objet_graphique24,"window5");
window4=create_window4();
gtk_widget_show (window4);
gtk_widget_hide(window5);
}


void
on_button25k_clicked                    (GtkWidget      *objet_graphique25,
                                        gpointer         user_data)
{
GtkWidget *window5,*window7;
window5=lookup_widget(objet_graphique25,"window5");
window7=create_window7();
gtk_widget_show (window7);
gtk_widget_hide(window5);
}


void
on_button26_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void 
on_button27k_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

    GtkWidget *nom,*prenom,*jour,*mois,*annee,*seancee,*List_View,*current,*window5;
    char nomk[20],prenomk[20],seanceek[100];
    int moisk,anneek,jourk;
    nom=lookup_widget(objet_graphique,"entry10k");
    prenom=lookup_widget(objet_graphique,"entry11k");
    jour=lookup_widget(objet_graphique,"jour1k");
    mois=lookup_widget(objet_graphique,"mois1k");
    annee=lookup_widget(objet_graphique,"annee1k");
    seancee=lookup_widget(objet_graphique,"combobox1k");
    strcpy(nomk,gtk_entry_get_text(GTK_ENTRY(nom)));
    strcpy(prenomk,gtk_entry_get_text(GTK_ENTRY(prenom)));
    jourk = gtk_spin_button_get_value_as_int(jour);
    moisk = gtk_spin_button_get_value_as_int(mois);
    anneek = gtk_spin_button_get_value_as_int(annee);
    strcpy(seanceek,gtk_combo_box_get_active_text(GTK_COMBO_BOX(seancee)));
    modifier(nomk,prenomk,anneek,moisk,jourk,seanceek);
	
    
    window5=create_window5();
    gtk_widget_show (window5);
    current=lookup_widget(objet_graphique,"window7");
    gtk_widget_hide(current);
    List_View=lookup_widget(window5,"treeviewk11");
    k_afficher_tableau_event(List_View);
    
   


}





void
on_button28k_clicked                    (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
 GtkWidget *nom,*prenom,*jour,*mois,*annee,*seancee,*List_View,*current, *window5;
    char nomk[20],prenomk[20],seanceek[100];
    int moisk,anneek,jourk;
    nom=lookup_widget(objet_graphique,"entry10k");
    prenom=lookup_widget(objet_graphique,"entry11k");
    jour=lookup_widget(objet_graphique,"jour1k");
    mois=lookup_widget(objet_graphique,"mois1k");
    annee=lookup_widget(objet_graphique,"annee1k");
    seancee=lookup_widget(objet_graphique,"combobox1k");
    strcpy(nomk,gtk_entry_get_text(GTK_ENTRY(nom)));
    strcpy(prenomk,gtk_entry_get_text(GTK_ENTRY(prenom)));
    jourk = gtk_spin_button_get_value_as_int(jour);
    moisk = gtk_spin_button_get_value_as_int(mois);
    anneek = gtk_spin_button_get_value_as_int(annee);
    strcpy(seanceek,gtk_combo_box_get_active_text(GTK_COMBO_BOX(seancee)));
    supprimer(nomk,prenomk,jourk,moisk,anneek,seanceek);
	
    
    window5=create_window5();
    gtk_widget_show (window5);
    current=lookup_widget(objet_graphique,"window7");
    gtk_widget_hide(current);
    List_View=lookup_widget(window5,"treeviewk11");
    k_afficher_tableau_event(List_View);
}


void
on_button29k_clicked                    (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{

}




void
on_button13k_clicked                   (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window4,*window9,*List_View;
window9=create_window9();
gtk_widget_show (window9);
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
List_View=lookup_widget(window9,"treeviewk2");
afficher2(List_View);
}





void
on_buttok18_enter                      (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_buttonkmod_clicked                  (GtkWidget    *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *jour1,*jour,*mois,*annee,*heure,*current,*window8,*window9,*List_View;
	char jour1k[20],heurek[20];
	int jourk,moisk,anneek;
	jour1=lookup_widget(objet_graphique,"comboboxk1");
	jour=lookup_widget(objet_graphique,"spinbuttonJ");
	mois=lookup_widget(objet_graphique,"spinbuttonM");
	annee=lookup_widget(objet_graphique,"spinbuttonA");
	heure=lookup_widget(objet_graphique,"comboboxk2");
	
	strcpy(jour1k,gtk_combo_box_get_active_text(GTK_COMBO_BOX(jour1)));
	jourk = gtk_spin_button_get_value_as_int(jour);
	moisk = gtk_spin_button_get_value_as_int(mois);
	anneek = gtk_spin_button_get_value_as_int(annee);
	strcpy(heurek,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)));
	
	modifier1(jour1k,jourk,moisk,anneek,heurek);
	window9=create_window9();
	gtk_widget_show (window9);
	current=lookup_widget(objet_graphique,"window8");
	gtk_widget_hide(current);
	List_View=lookup_widget(window9,"treeviewk2");
	afficher2(List_View);
}


void
on_buttonksupp_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *jour1,*jour,*mois,*annee,*heure,*current,*window8,*window9,*List_View;
	char jour1k[20],heurek[20];
	int jourk,moisk,anneek;
	jour1=lookup_widget(objet_graphique,"comboboxk1");
	jour=lookup_widget(objet_graphique,"spinbuttonJ");
	mois=lookup_widget(objet_graphique,"spinbuttonM");
	annee=lookup_widget(objet_graphique,"spinbuttonA");
	heure=lookup_widget(objet_graphique,"comboboxk2");
	
	strcpy(jour1k,gtk_combo_box_get_active_text(GTK_COMBO_BOX(jour1)));
	jourk = gtk_spin_button_get_value_as_int(jour);
	moisk = gtk_spin_button_get_value_as_int(mois);
	anneek = gtk_spin_button_get_value_as_int(annee);
	strcpy(heurek,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)));
	
	supprimer1(jour1k,jourk,moisk,anneek,heurek);
	window9=create_window9();
	gtk_widget_show (window9);
	current=lookup_widget(objet_graphique,"window8");
	gtk_widget_hide(current);
	List_View=lookup_widget(window9,"treeviewk2");
	afficher2(List_View);
}


void
on_buttonajk_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window9,*window10;
window9=lookup_widget(objet_graphique,"window9");
window10=create_window10();
gtk_widget_show (window10);
gtk_widget_hide(window9);
}


void
on_treeviewk2_row_activated            (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *jour1n,*journ,*moisn,*anneen,*heuren,*window8,*window9,*treeview;
gchar *jour1,*heure;
int jour,mois,annee;
	window8=create_window8();
	treeview=lookup_widget(objet_graphique,"treeviewk2");
	window9=lookup_widget(objet_graphique,"window9");
	jour1n=lookup_widget(window8,"comboboxk1");
	journ=lookup_widget(window8,"spinbuttonJ");
	moisn=lookup_widget(window8,"spinbuttonM");
	anneen=lookup_widget(window8,"spinbuttonA");
	heuren=lookup_widget(window8,"comboboxk2");
	GtkTreeIter iter;
	GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview));
	gtk_tree_model_get_iter(model,&iter,path);
	gtk_tree_model_get (model,&iter,0,&jour1,1,&jour,2,&mois,3,&annee,4,&heure,-1);
	printf("%s %d %d %d %s",jour1,jour,mois,annee,heure);
	gtk_entry_set_text(GTK_ENTRY (jour1n),_(jour1));
	if (!strcmp(jour1,"Lundi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),0);
if (!strcmp(jour1,"Mardi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),1);
if (!strcmp(jour1,"Mercredi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),2);
if (!strcmp(jour1,"Jeudi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),3);
if (!strcmp(jour1,"Vendredi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),4);
if (!strcmp(jour1,"Samedi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),5);
if (!strcmp(jour1,"Dimanche"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),6);

        gtk_spin_button_set_value(GTK_SPIN_BUTTON (journ),jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON (moisn),mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON (anneen),annee);
 	
	
	gtk_entry_set_text(GTK_ENTRY (heuren),_(heure));
if (!strcmp(heure,"8h/9h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),0);
if (!strcmp(heure,"9h/10h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),1);
if (!strcmp(heure,"10h/11h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),2);
if (!strcmp(heure,"11h/12h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),3);
if (!strcmp(heure,"14h/15h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),4);
if (!strcmp(heure,"15h/16h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),5);
if (!strcmp(heure,"16h/17h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),6);
if (!strcmp(heure,"17h/18h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),7);
if (!strcmp(heure,"18h/19h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),8);
if (!strcmp(heure,"19h/20h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),9);
if (!strcmp(heure,"20h/21h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),10);
	gtk_widget_hide(window9);
	gtk_widget_show(window8);
}


void
on_buttonkkaj_clicked                  (GtkWidget    *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *jour1,*jour,*mois,*annee,*heure,*window9,*window10,*List_View;
	dispok d;
	
	
	jour1=lookup_widget(objet_graphique,"comboboxk5");
	jour=lookup_widget(objet_graphique,"spinbuttonk5");
	mois=lookup_widget(objet_graphique,"spinbuttonk6");
	annee=lookup_widget(objet_graphique,"spinbuttonk7");
	heure=lookup_widget(objet_graphique,"comboboxkk");

	

	strcpy(d.jour1,gtk_combo_box_get_active_text (GTK_COMBO_BOX(jour1)));
	d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
	d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
	d.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
	strcpy(d.heure,gtk_combo_box_get_active_text (GTK_COMBO_BOX(heure)));
	

        ajouter1(d);

	window9=create_window9();
	window10=lookup_widget(objet_graphique,"window10");
	gtk_widget_hide(window10);
	List_View=lookup_widget(window9,"treeviewk2");
	afficher2(List_View);
	gtk_widget_show (window9);
}


void
on_buttonpro_clicked                   (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *a;
GtkWidget *b;
GtkWidget *c;
GtkWidget *d;
GtkWidget *e;
GtkWidget *f;
GtkWidget *g;
GtkWidget *h;
GtkWidget *window2,*window11;
window2=lookup_widget(objet_graphique,"window2");
window11=create_window11();
gtk_widget_show(window11);
gtk_widget_hide(window2);
FILE *fic;
a=lookup_widget(window11, "entry1kk");
b=lookup_widget(window11, "entry2kk");
c=lookup_widget(window11, "entry3kk");
d=lookup_widget(window11, "entry4kk");
e=lookup_widget(window11, "entry5kk");
f=lookup_widget(window11, "entry6kk");
g=lookup_widget(window11, "entry7kk");
h=lookup_widget(window11, "entry8kk");
char nom1[50];
char prenom1[50];
char date1[50];
char email1[50];
char cin1[50];
char adresse1[50];
char poids1[50];
char objectif1[50];
char nom[50];
char prenom[50];
char date[50];
char email[50];
char cin[50];
char adresse[50];
char poids[50];
char objectif[50];
fic=fopen("src/profilk.txt","r");

if (fic==NULL) printf("erreur\n");
else {
while (fscanf(fic,"%s %s %s %s %s %s %s %s",nom1,prenom1,date1,email1,cin1,adresse1,poids1,objectif1)!=EOF)
{
break;
}
fclose(fic);}
gtk_entry_set_text(GTK_ENTRY(a),nom1);
gtk_entry_set_text(GTK_ENTRY(b),prenom1);
gtk_entry_set_text(GTK_ENTRY(c),date1);
gtk_entry_set_text(GTK_ENTRY(d),email1);
gtk_entry_set_text(GTK_ENTRY(e),cin1);
gtk_entry_set_text(GTK_ENTRY(f),adresse1);
gtk_entry_set_text(GTK_ENTRY(g),poids1);
gtk_entry_set_text(GTK_ENTRY(h),objectif1);
}


void
on_buttonret_clicked                   (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5,*window7,*List_View;
window5=create_window5();
window7=lookup_widget(objet_graphique,"window7");
gtk_widget_hide(window7);
List_View=lookup_widget(window5,"treeviewk11");
k_afficher_tableau_event(List_View);
gtk_widget_show (window5);
}


void
on_buttonret1_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window9,*window8,*List_View;
window9=create_window9();
window8=lookup_widget(objet_graphique,"window8");
gtk_widget_hide(window8);
List_View=lookup_widget(window9,"treeviewk2");
afficher2(List_View);
gtk_widget_show (window9);
}


void
on_buttonret4_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window9,*window4;
window9=lookup_widget(objet_graphique,"window9");
window4=create_window4();
gtk_widget_show (window4);
gtk_widget_hide(window9);
}


void
on_buttonret5_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window10,*window9,*List_View;
window9=create_window9();
window10=lookup_widget(objet_graphique,"window10");
gtk_widget_hide(window10);
List_View=lookup_widget(window9,"treeviewk2");
afficher2(List_View);
gtk_widget_show (window9);
}


void
on_buttonprom_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom,*prenom,*date,*email,*cin,*adresse,*poids,*objectif,*window2,*window11;
    char nom1[50],prenom1[50],date1[50],email1[50],cin1[50],adresse1[50],poids1[50],objectif1[50];
  
    nom=lookup_widget(objet_graphique,"entry1kk");
    prenom=lookup_widget(objet_graphique,"entry2kk");
    date=lookup_widget(objet_graphique,"entry3kk");
    email=lookup_widget(objet_graphique,"entry4kk");
    cin=lookup_widget(objet_graphique,"entry5kk");
    adresse=lookup_widget(objet_graphique,"entry6kk");
    poids=lookup_widget(objet_graphique,"entry7kk");
    objectif=lookup_widget(objet_graphique,"entry8kk");
  
    strcpy(nom1,gtk_entry_get_text(GTK_ENTRY(nom)));
    strcpy(prenom1,gtk_entry_get_text(GTK_ENTRY(prenom)));
    strcpy(date1,gtk_entry_get_text(GTK_ENTRY(date)));
    strcpy(email1,gtk_entry_get_text(GTK_ENTRY(email)));
    strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(cin)));
    strcpy(adresse1,gtk_entry_get_text(GTK_ENTRY(adresse)));
    strcpy(poids1,gtk_entry_get_text(GTK_ENTRY(poids)));
    strcpy(objectif1,gtk_entry_get_text(GTK_ENTRY(objectif)));
  
    k_modifier2(nom1,prenom1,date1,email1,cin1,adresse1,poids1,objectif1);
    window2=create_window2();
    gtk_widget_show (window2);
    window11=lookup_widget(objet_graphique,"window11");
    gtk_widget_hide(window11);
}


void
on_buttonprore_clicked                 (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window11,*window2;
window11=lookup_widget(objet_graphique,"window11");
window2=create_window2();
gtk_widget_show (window2);
gtk_widget_hide(window11);
}


void
on_buttonretourkk_clicked              (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2,*window1;
window2=lookup_widget(objet_graphique,"window2");
window1=create_window1a();
gtk_widget_show (window1);
gtk_widget_hide(window2);

}


void
on_buttonaffrdv_clicked                (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window4,*window12,*List_View;
window12=create_window12();
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
List_View=lookup_widget(window12,"treeviewk3");
afficher3k(List_View);
gtk_widget_show (window12);
}


void
on_retourrdv_clicked                   (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window12,*window4;
window12=lookup_widget(objet_graphique,"window12");
window4=create_window4();
gtk_widget_show (window4);
gtk_widget_hide(window12);
}


void
on_buttoncclosek_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button6k_clicked                    (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_buttonRETK_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window13,*window4;
window13=lookup_widget(objet_graphique,"window13");
window4=create_window4();
gtk_widget_show (window4);
gtk_widget_hide(window13);
}


void
on_buttonFM_clicked                    (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window4,*window13,*List_View;
window13=create_window13();
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
List_View=lookup_widget(window13,"treeviewk4");
afficherk(List_View);
gtk_widget_show (window13);
}






void
on_treeviewk11_row_activated           (GtkWidget *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
  GtkWidget *nomk,*prenomk,*jourk,*anneek,*moisk,*seanceek,*window7,*window5,*treeview;
    gchar *nom,*prenom,*seancee;
    int annee,jour,mois;
    window7=create_window7();
    treeview=lookup_widget(objet_graphique,"treeviewk11");
    window5=lookup_widget(objet_graphique,"window5");
    nomk=lookup_widget(window7,"entry10k");
    prenomk=lookup_widget(window7,"entry11k");
    anneek=lookup_widget(window7,"annee1k");
    moisk=lookup_widget(window7,"mois1k");
    jourk=lookup_widget(window7,"jour1k");
    seanceek=lookup_widget(window7,"comboboxk4");
    GtkTreeIter iter;
    GtkTreeModel *model=gtk_tree_view_get_model (treeview);
    gtk_tree_model_get_iter(model,&iter,path);
    gtk_tree_model_get (model,&iter,0,&nom,1,&prenom,2,&jour,3,&mois,4,&annee,5,&seancee,-1);
    g_print("%s %s %d %d %d %s ",nom,prenom,jour,mois,annee,seancee);
    gtk_entry_set_text(GTK_ENTRY (nomk),_(nom));
    gtk_entry_set_text(GTK_ENTRY (prenomk),_(prenom));
    gtk_spin_button_set_value(GTK_SPIN_BUTTON (anneek),annee);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON (moisk),mois);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON (jourk),jour);
    gtk_entry_set_text(GTK_ENTRY (seanceek),_(seancee));
if (!strcmp(seancee,"massage_mainceur"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(seanceek),0);
if (!strcmp(seancee,"massage_lymphatique"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(seanceek),1);
    gtk_widget_hide(window5);
    gtk_widget_show(window7);
}


////callbacks.c coach ////////////

void
on_button5c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window3c,*List_View;
window3c=create_window3c();
window2c=lookup_widget(objet_graphique,"window2c");
gtk_widget_hide(window2c);
List_View=lookup_widget(window3c,"treeview1c");
afficher3c(List_View);
gtk_widget_show(window3c);
}




void
on_button6c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window3c;
window3c=lookup_widget(objet_graphique,"window3c");
gtk_widget_destroy(window3c);
window2c=create_window2c();
gtk_widget_show(window2c);

}




void
on_button3c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window4c,*List_View;
window4c=create_window4c();
window2c=lookup_widget(objet_graphique,"window2c");
gtk_widget_hide(window2c);
List_View=lookup_widget(window4c,"treeview2c");
afficher1c(List_View);
gtk_widget_show(window4c);
}


void
on_button7c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window4c,*List_View;
window4c=lookup_widget(objet_graphique,"window4c");
List_View=lookup_widget(window4c,"treeview2c");
afficher1c(List_View);
gtk_widget_destroy(window4c);
window2c=create_window2c();


gtk_widget_show(window2c);
}


void
on_button8c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window5c;
window5c=lookup_widget(objet_graphique,"window5c");
gtk_widget_destroy(window5c);
window2c=create_window2c();
gtk_widget_show(window2c);
}


void
on_button4c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window5c,*List_View;
window5c=create_window5c();
window2c=lookup_widget(objet_graphique,"window2c");
gtk_widget_hide(window2c);
List_View=lookup_widget(window5c,"treeview3c");
afficher2c(List_View);
gtk_widget_show(window5c);
}

void
on_button9c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window4c,*window6c;
window6c=create_window6c();
gtk_widget_show (window6c);
window4c=lookup_widget(objet_graphique,"window4c");
gtk_widget_hide(window4c);

}


void
on_button10c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window6c,*window4c,*List_View;
window6c=lookup_widget(objet_graphique,"window6c");
gtk_widget_destroy(window6c);

window4c=create_window4c();
gtk_widget_show(window4c);
List_View=lookup_widget(window4c,"treeview2c");
afficher1c(List_View);

}


void
on_button11c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{

dispoc c;

GtkWidget *ee, *gg;
GtkWidget *window6c;

window6c=lookup_widget(objet_graphique,"window6c");

ee=lookup_widget(objet_graphique,"entry3c");
gg=lookup_widget(objet_graphique,"entry4c");
strcpy(c.date,gtk_entry_get_text(GTK_ENTRY(ee)));
strcpy(c.heure,gtk_entry_get_text(GTK_ENTRY(gg)));




ajouter_dispoc(c);


}



void
on_treeview3c_row_activated            (
                                        GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{ 
GtkWidget *dateco, *heureco, *salleco, *typeco, *window5c, *window9c, *List_View;
    
    char *date,*heure,*salle,*type;
    List_View=lookup_widget(objet_graphique,"treeview3c");
    window5c=lookup_widget(objet_graphique,"window5c");
    window9c=create_window9c();
    
    
    
    dateco=lookup_widget(window9c,"entry11c");
    heureco=lookup_widget(window9c,"entry12c");
    salleco=lookup_widget(window9c,"entry13c");
    typeco=lookup_widget(window9c,"entry14c");
    GtkTreeIter iter;
    GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(List_View));
    gtk_tree_model_get_iter(model,&iter,path);
    gtk_tree_model_get (model,&iter,0,&date,1,&heure,2,&salle,3,&type,-1);
    printf("%s %s %s %s ",date,heure,salle,type);
    gtk_entry_set_text(GTK_ENTRY (dateco),_(date));
    gtk_entry_set_text(GTK_ENTRY (heureco),_(heure));
    gtk_entry_set_text(GTK_ENTRY (salleco),_(salle));
    gtk_entry_set_text(GTK_ENTRY (typeco),_(type));
    
    gtk_widget_show(window9c);
    gtk_widget_destroy(window5c);
    
    


}

void
on_treeview2c_row_activated            (
                                        GtkWidget       *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{   
    GtkWidget *datec, *heurec, *window4c, *window7c, *List_View;
    
    char *date,*heure;
    List_View=lookup_widget(objet_graphique,"treeview2c");
    window4c=lookup_widget(objet_graphique,"window4c");
    window7c=create_window7c();
    
    
    
    datec=lookup_widget(window7c,"entry5c");
    heurec=lookup_widget(window7c,"entry6c");
    GtkTreeIter iter;
    GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(List_View));
    gtk_tree_model_get_iter(model,&iter,path);
    gtk_tree_model_get (model,&iter,0,&date,1,&heure,-1);
    printf("%s %s  ",date,heure);
    gtk_entry_set_text(GTK_ENTRY (datec),_(date));
    gtk_entry_set_text(GTK_ENTRY (heurec),_(heure));
    
    gtk_widget_show(window7c);
    gtk_widget_destroy(window4c);
    
    


}


void
on_button12c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget  *datec, *heurec, *window4c, *window7c, *List_View , *current;
char date[20],heure[20];
    datec=lookup_widget(objet_graphique,"entry5c");
    heurec=lookup_widget(objet_graphique,"entry6c");
    strcpy(date,gtk_entry_get_text(GTK_ENTRY(datec)));
    strcpy(heure,gtk_entry_get_text(GTK_ENTRY(heurec)));
    modifierc(date,heure);
    current=lookup_widget(objet_graphique,"window7c");
    gtk_widget_hide(current);
window4c=create_window4c();
List_View=lookup_widget(window4c,"treeview2c");

window7c=lookup_widget(objet_graphique,"window7c");
gtk_widget_hide(window7c);
gtk_widget_show (window4c);
afficher1c(List_View);

    

}


void
on_button13c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window7c,*window4c,*List_View;
window7c=lookup_widget(objet_graphique,"window7c");
gtk_widget_destroy(window7c);

window4c=create_window4c();
gtk_widget_show(window4c);
List_View=lookup_widget(window4c,"treeview2c");
afficher1c(List_View);

}


void
on_button14c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget  *datec, *heurec, *window4c, *window7c, *List_View , *current;
char date[20],heure[20];
    datec=lookup_widget(objet_graphique,"entry5c");
    heurec=lookup_widget(objet_graphique,"entry6c");
    strcpy(date,gtk_entry_get_text(GTK_ENTRY(datec)));
    strcpy(heure,gtk_entry_get_text(GTK_ENTRY(heurec)));
    supprimerc(date,heure);
    current=lookup_widget(objet_graphique,"window7c");
    gtk_widget_hide(current);
window4c=create_window4c();
List_View=lookup_widget(window4c,"treeview2c");

window7c=lookup_widget(objet_graphique,"window7c");
gtk_widget_hide(window7c);
gtk_widget_show (window4c);
afficher1c(List_View);

}


void
on_button15c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window5c,*window8c;
window8c=create_window8c();
gtk_widget_show (window8c);
window5c=lookup_widget(objet_graphique,"window5c");
gtk_widget_hide(window5c);
}


void
on_button16c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{

seancec c;

GtkWidget *e, *f, *g, *h;
GtkWidget *window6;

window6=lookup_widget(objet_graphique,"window6");

e=lookup_widget(objet_graphique,"entry7c");
f=lookup_widget(objet_graphique,"entry8c");
g=lookup_widget(objet_graphique,"entry9c");
h=lookup_widget(objet_graphique,"entry10c");
strcpy(c.date,gtk_entry_get_text(GTK_ENTRY(e)));
strcpy(c.heure,gtk_entry_get_text(GTK_ENTRY(f)));
strcpy(c.salle,gtk_entry_get_text(GTK_ENTRY(g)));
strcpy(c.type,gtk_entry_get_text(GTK_ENTRY(h)));
ajouter_seance(c);


}

void
on_button17c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window8c,*window5c,*List_View;
window8c=lookup_widget(objet_graphique,"window8c");
gtk_widget_destroy(window8c);

window5c=create_window5c();
gtk_widget_show(window5c);
List_View=lookup_widget(window5c,"treeview3c");
afficher2c(List_View);

}



void
on_button18c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window9c,*window5c,*List_View;
window9c=lookup_widget(objet_graphique,"window9c");
gtk_widget_destroy(window9c);

window5c=create_window5c();
gtk_widget_show(window5c);
List_View=lookup_widget(window5c,"treeview3c");
afficher2c(List_View);

}


void
on_button19c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget  *dateco, *heureco, *salleco, *typeco, *window5c, *window9c, *List_View , *current;
char date[20],heure[20],salle[20],type[20];
    
    dateco=lookup_widget(objet_graphique,"entry11c");
    heureco=lookup_widget(objet_graphique,"entry12c");
    salleco=lookup_widget(objet_graphique,"entry13c");
    typeco=lookup_widget(objet_graphique,"entry14c");
   
    strcpy(date,gtk_entry_get_text(GTK_ENTRY(dateco)));
    strcpy(heure,gtk_entry_get_text(GTK_ENTRY(heureco)));
    strcpy(salle,gtk_entry_get_text(GTK_ENTRY(salleco)));
    strcpy(type,gtk_entry_get_text(GTK_ENTRY(typeco)));

    modifier1c(date,heure,salle,type);
    current=lookup_widget(objet_graphique,"window9c");
    gtk_widget_hide(current);
window5c=create_window5c();
List_View=lookup_widget(window5c,"treeview3c");

window9c=lookup_widget(objet_graphique,"window9c");
gtk_widget_hide(window9c);
gtk_widget_show (window5c);
afficher2c(List_View);

    

}


void
on_button20c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget  *datec, *heurec, *sallec, *typec, *window5c, *window9c, *List_View , *current;
char date[20],heure[20],salle[20],type[20];
    
    datec=lookup_widget(objet_graphique,"entry11c");
    heurec=lookup_widget(objet_graphique,"entry12c");
    sallec=lookup_widget(objet_graphique,"entry13c");
    typec=lookup_widget(objet_graphique,"entry14c");
   
    strcpy(date,gtk_entry_get_text(GTK_ENTRY(datec)));
    strcpy(heure,gtk_entry_get_text(GTK_ENTRY(heurec)));
    strcpy(salle,gtk_entry_get_text(GTK_ENTRY(sallec)));
    strcpy(type,gtk_entry_get_text(GTK_ENTRY(typec)));

    supprimer1c(date,heure,salle,type);
    current=lookup_widget(objet_graphique,"window9c");
    gtk_widget_hide(current);
window5c=create_window5c();
List_View=lookup_widget(window5c,"treeview3c");

window9c=lookup_widget(objet_graphique,"window9c");
gtk_widget_hide(window9c);
gtk_widget_show (window5c);
afficher2c(List_View);
}


void
on_button2c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
     
GtkWidget *co1,*co2,*co3,*co4,*co5,*co6,*window2c,*window10c;
window10c=create_window10c();
gtk_widget_show (window10c);
window2c=lookup_widget(objet_graphique,"window2c");
gtk_widget_hide(window2c);
FILE *fic;
co1=lookup_widget(window10c,"entry15c");
co2=lookup_widget(window10c,"entry16c");
co3=lookup_widget(window10c,"entry17c");
co4=lookup_widget(window10c,"entry18c");
co5=lookup_widget(window10c,"entry19c");
co6=lookup_widget(window10c,"entry20c");
char nom1c[20],prenom1c[20],date1c[20],email1c[20],cin1c[20],adresse1c[20],nom[20],prenom[20],date[20],email[20],cin[20],adresse[20];
fic=fopen("src/profilc.txt","r");

if (fic==NULL) printf("erreur\n");
else {
while (fscanf(fic,"%s %s %s %s %s %s",nom1c,prenom1c,date1c,email1c,cin1c,adresse1c)!=EOF)
{break;}
fclose(fic);}

gtk_entry_set_text(GTK_ENTRY(co1),nom1c);
gtk_entry_set_text(GTK_ENTRY(co2),prenom1c);
gtk_entry_set_text(GTK_ENTRY(co3),date1c);
gtk_entry_set_text(GTK_ENTRY(co4),email1c);
gtk_entry_set_text(GTK_ENTRY(co5),cin1c);
gtk_entry_set_text(GTK_ENTRY(co6),adresse1c);
}



void
on_button22c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *nom,*prenom,*date,*email,*cin,*adresse,*current,*window2c,*window10c;
    char nomc[50],prenomc[50],datec[50],emailc[50],cinc[50],adressec[50];
   
    nom=lookup_widget(objet_graphique,"entry15c");
    prenom=lookup_widget(objet_graphique,"entry16c");
    date=lookup_widget(objet_graphique,"entry17c");
    email=lookup_widget(objet_graphique,"entry18c");
    cin=lookup_widget(objet_graphique,"entry19c");
    adresse=lookup_widget(objet_graphique,"entry20c");
   
    strcpy(nomc,gtk_entry_get_text(GTK_ENTRY(nom)));
    strcpy(prenomc,gtk_entry_get_text(GTK_ENTRY(prenom)));
    strcpy(datec,gtk_entry_get_text(GTK_ENTRY(date)));
    strcpy(emailc,gtk_entry_get_text(GTK_ENTRY(email)));
    strcpy(cinc,gtk_entry_get_text(GTK_ENTRY(cin)));
    strcpy(adressec,gtk_entry_get_text(GTK_ENTRY(adresse)));
   
    modifier2c(nomc,prenomc,datec,emailc,cinc,adressec);
}


void
on_button23c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window10c;
window10c=lookup_widget(objet_graphique,"window10c");
gtk_widget_destroy(window10c);
window2c=create_window2c();
gtk_widget_show(window2c);
}


void
on_button24c_clicked                   

(GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window11c,*List_View;
window11c=create_window11c();
window2c=lookup_widget(objet_graphique,"window2c");
gtk_widget_hide(window2c);
List_View=lookup_widget(window11c,"treeview4c");
afficher4c(List_View);
gtk_widget_show(window11c);
}


void
on_button25c_clicked                    (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window11c;
window11c=lookup_widget(objet_graphique,"window11c");
gtk_widget_destroy(window11c);
window2c=create_window2c();
gtk_widget_show(window2c);
}


void
on_button30c_clicked                   (GtkWidget       *objet_graphique,   gpointer  user_data)
{
GtkWidget *window2c,*window1c;
window2c=lookup_widget(objet_graphique,"window2c");
gtk_widget_destroy(window2c);
window1c=create_window1a();
gtk_widget_show(window1c);
}

