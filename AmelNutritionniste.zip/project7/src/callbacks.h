#include <gtk/gtk.h>


void
on_button1n_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button2n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button3n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button4n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button5n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button8n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button50n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button67n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button68n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button69n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button99n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button98n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button97n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button101n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button102n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button103n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button201n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button202n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button203n_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_treeview100n_row_activated          (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button5000n_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6000n_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button6001n_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
/* ************************************************
**************************************************
**************************************************
fin nutri */

