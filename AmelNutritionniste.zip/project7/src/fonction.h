#include <gtk/gtk.h>
typedef struct
{
char identifiant[20];
char nom[20];
char prenom[20];
int age;
int poids;
char tension[20];
char maladies[20];
char observations[150];
}adherant;
typedef struct
{
char jour1[20];
int jour;
int mois;
int annee;
char heure[20];
}dispo;
void afficher();
int verifier(char login[],char password[]);
void ajoutern(adherant a);
void afficher1n(GtkWidget *plistview);
void modifiern(char identifiant[],char nom[],char prenom[],int age,int poids,char tension[],char maladies[],char observations[]);
void supprimern(char identifiant[],char nom[],char prenom[],int age,int poids,char tension[],char maladies[],char observations[]);
void ajouter1n(dispo d);
void afficher2n(GtkWidget *plistview);
void modifier1n(char jour1[],int jour,int mois,int annee,char heure[]);
void supprimer1n(char jour1[],int jour,int mois,int annee,char heure[]);
void modifier2n(char nom[],char prenom[],char date[],char email[],char cin[],char adresse[]);
void afficher3n(GtkWidget *plistview);



