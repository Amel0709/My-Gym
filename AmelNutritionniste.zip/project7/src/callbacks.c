#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"


void
on_button1n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int x;	
	GtkWidget *a ,*b,*c ,*window1n,*window2n;
	char login[20],password[20];
	
	window1n= lookup_widget(objet_graphique,"window1n");	
	a=lookup_widget(objet_graphique,"entry1n");
	b=lookup_widget(objet_graphique,"entry2n");
	c=lookup_widget(objet_graphique,"label3n");
	strcpy(login,gtk_entry_get_text(GTK_ENTRY(a)));
	strcpy(password,gtk_entry_get_text(GTK_ENTRY(b)));
	x =verifier(login,password);
	
	if(x==1){ 
window2n=create_window2n();
gtk_widget_show (window2n);
gtk_widget_hide(window1n);
}
	else 
	{ gtk_label_set_text(GTK_LABEL(c),"authentification non validée");}
}


void
on_button2n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button3n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3n,*window2n,*List_View;
window3n=create_window3n();
gtk_widget_show (window3n);
window2n=lookup_widget(objet_graphique,"window2n");
gtk_widget_hide(window2n);
List_View=lookup_widget(window3n,"treeview1");
afficher1n(List_View);
 

}


void
on_button4n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *a,*b,*c,*d,*e,*f,*window4n,*window2n;
window4n=create_window4n();
gtk_widget_show (window4n);
window2n=lookup_widget(objet_graphique,"window2n");
gtk_widget_hide(window2n);
FILE *fic;
a=lookup_widget(window4n,"entry1000n");
b=lookup_widget(window4n,"entry2");
c=lookup_widget(window4n,"entry1002n");
d=lookup_widget(window4n,"entry1003n");
e=lookup_widget(window4n,"entry1004n");
f=lookup_widget(window4n,"entry1005n");
char nom1[20],prenom1[20],date1[20],email1[20],cin1[20],adresse1[20],nom[20],prenom[20],date[20],email[20],cin[20],adresse[20];
fic=fopen("src/profiln.txt","r");

if (fic==NULL) printf("erreur\n");
else {
while (fscanf(fic,"%s %s %s %s %s %s",nom1,prenom1,date1,email1,cin1,adresse1)!=EOF)
{break;}
fclose(fic);}

gtk_entry_set_text(GTK_ENTRY(a),nom1);
gtk_entry_set_text(GTK_ENTRY(b),prenom1);
gtk_entry_set_text(GTK_ENTRY(c),date1);
gtk_entry_set_text(GTK_ENTRY(d),email1);
gtk_entry_set_text(GTK_ENTRY(e),cin1);
gtk_entry_set_text(GTK_ENTRY(f),adresse1);
}





void
on_button5n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5n,*window2n,*List_View;
window5n=create_window5n();
gtk_widget_show (window5n);
window2n=lookup_widget(objet_graphique,"window2n");
gtk_widget_hide(window2n);
List_View=lookup_widget(window5n,"treeview100n");
afficher2n(List_View);

}


void
on_button6n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window1n,*window2n;
window1n=create_window1n();
gtk_widget_show (window1n);
window2n=lookup_widget(objet_graphique,"window2n");
gtk_widget_hide(window2n);
}


void
on_button7n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3n,*window2n;
window2n=create_window2n();
gtk_widget_show (window2n);
window3n=lookup_widget(objet_graphique,"window3n");
gtk_widget_hide(window3n);
}


void
on_button8n_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3n,*window6n;
window6n=create_window6n();
gtk_widget_show (window6n);
window3n=lookup_widget(objet_graphique,"window3n");
gtk_widget_hide(window3n);
}


void
on_button50n_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *identifiant ,*nom,*prenom,*age,*poids,*tension,*maladies,*observations ,*window3n,*window6n,*List_View;
	adherant a;
	
	identifiant=lookup_widget(objet_graphique,"entry51n");
	nom=lookup_widget(objet_graphique,"entry52n");
	prenom=lookup_widget(objet_graphique,"entry53n");
	age=lookup_widget(objet_graphique,"spinbutton1n");
	poids=lookup_widget(objet_graphique,"spinbutton2n");
	tension=lookup_widget(objet_graphique,"comboboxentry1n");
	maladies=lookup_widget(objet_graphique,"comboboxentry2n");
	observations=lookup_widget(objet_graphique,"entry54n");

	strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

	a.age=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (age));
	a.poids=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (poids));

	strcpy(a.tension,gtk_combo_box_get_active_text (GTK_COMBO_BOX(tension)));
	strcpy(a.maladies,gtk_combo_box_get_active_text (GTK_COMBO_BOX(maladies)));

	strcpy(a.observations,gtk_entry_get_text(GTK_ENTRY(observations)));

        ajoutern(a);

	window3n=create_window3n();
	window6n=lookup_widget(objet_graphique,"window6n");
	gtk_widget_hide(window6n);
	List_View=lookup_widget(window3n,"treeview1");
	afficher1n(List_View);
	gtk_widget_show (window3n);
	
}


void
on_button67n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *identifiant,*nom,*prenom,*age,*poids,*tension,*maladies,*observations,*current,*window3n,*window7n,*List_View;
	char identifiantk[20],nomk[20],prenomk[20],tensionk[20],maladiesk[20],observationsk[20];
	int agek,poidsk;
	identifiant=lookup_widget(objet_graphique,"entry61n");
	nom=lookup_widget(objet_graphique,"entry62n");
	prenom=lookup_widget(objet_graphique,"entry63n");
	age=lookup_widget(objet_graphique,"spinbutton60n");
	poids=lookup_widget(objet_graphique,"spinbutton65n");
	tension=lookup_widget(objet_graphique,"comboboxentry66n");
	maladies=lookup_widget(objet_graphique,"comboboxentry67n");
	observations=lookup_widget(objet_graphique,"entry67n");
	strcpy(identifiantk,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	strcpy(nomk,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(prenomk,gtk_entry_get_text(GTK_ENTRY(prenom)));
	agek = gtk_spin_button_get_value_as_int(age);
	poidsk = gtk_spin_button_get_value_as_int(poids);
	strcpy(tensionk,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tension)));
	strcpy(maladiesk,gtk_combo_box_get_active_text(GTK_COMBO_BOX(maladies)));
	strcpy(observationsk,gtk_entry_get_text(GTK_ENTRY(observations)));
	modifiern(identifiantk,nomk,prenomk,agek,poidsk,tensionk,maladiesk,observationsk);
	window3n=create_window3n();
	gtk_widget_show (window3n);
	current=lookup_widget(objet_graphique,"window7n");
	gtk_widget_hide(current);
	List_View=lookup_widget(window3n,"treeview1");
	afficher1n(List_View);
}


void
on_button68n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *identifiant,*nom,*prenom,*age,*poids,*tension,*maladies,*observations,*current,*window3n,*window7n,*List_View;
	char identifiantk[20],nomk[20],prenomk[20],tensionk[20],maladiesk[20],observationsk[20];
	int agek,poidsk;
	identifiant=lookup_widget(objet_graphique,"entry61n");
	nom=lookup_widget(objet_graphique,"entry62n");
	prenom=lookup_widget(objet_graphique,"entry63n");
	age=lookup_widget(objet_graphique,"spinbutton60n");
	poids=lookup_widget(objet_graphique,"spinbutton65n");
	tension=lookup_widget(objet_graphique,"comboboxentry66n");
	maladies=lookup_widget(objet_graphique,"comboboxentry67n");
	observations=lookup_widget(objet_graphique,"entry67n");
	strcpy(identifiantk,gtk_entry_get_text(GTK_ENTRY(identifiant)));
	strcpy(nomk,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(prenomk,gtk_entry_get_text(GTK_ENTRY(prenom)));
	agek = gtk_spin_button_get_value_as_int(age);
	poidsk = gtk_spin_button_get_value_as_int(poids);
	strcpy(tensionk,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tension)));
	strcpy(maladiesk,gtk_combo_box_get_active_text(GTK_COMBO_BOX(maladies)));
	strcpy(observationsk,gtk_entry_get_text(GTK_ENTRY(observations)));
	supprimern(identifiantk,nomk,prenomk,agek,poidsk,tensionk,maladiesk,observationsk);
	window3n=create_window3n();
	gtk_widget_show (window3n);
	current=lookup_widget(objet_graphique,"window7n");
	gtk_widget_hide(current);
	List_View=lookup_widget(window3n,"treeview1");
	afficher1n(List_View);
}


void
on_button69n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
 GtkWidget *window3n,*window7n,*List_View;
window3n=create_window3n();
gtk_widget_show (window3n);
window7n=lookup_widget(objet_graphique,"window7n");
gtk_widget_hide(window7n);
List_View=lookup_widget(window3n,"treeview1");
afficher1n(List_View);
}


void
on_treeview1_row_activated             (GtkWidget     *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkWidget *identifiantn,*nomn,*prenomn,*agen,*poidsn,*tensionn,*maladiesn,*observationsn,*window3n,*window7n,*treeview;
gchar *identifiant,*nom,*prenom,*tension,*maladies,*observations;
int age,poids;
	window7n=create_window7n();
	treeview=lookup_widget(objet_graphique,"treeview1");
	window3n=lookup_widget(objet_graphique,"window3n");
	identifiantn=lookup_widget(window7n,"entry61n");
	nomn=lookup_widget(window7n,"entry62n");
	prenomn=lookup_widget(window7n,"entry63n");
	agen=lookup_widget(window7n,"spinbutton60n");
	poidsn=lookup_widget(window7n,"spinbutton65n");
	tensionn=lookup_widget(window7n,"comboboxentry66n");
	maladiesn=lookup_widget(window7n,"comboboxentry67n");
	observationsn=lookup_widget(window7n,"entry67n");
	GtkTreeIter iter;
	GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview));
	gtk_tree_model_get_iter(model,&iter,path);
	gtk_tree_model_get (model,&iter,0,&identifiant,1,&nom,2,&prenom,3,&age,4,&poids,5,&tension,6,&maladies,7,&observations,-1);
	g_print("%s %s %s %d %d %s %s %s",identifiant,nom,prenom,age,poids,tension,maladies,observations);
	gtk_entry_set_text(GTK_ENTRY (identifiantn),_(identifiant));
	gtk_entry_set_text(GTK_ENTRY (nomn),_(nom));
	gtk_entry_set_text(GTK_ENTRY (prenomn),_(prenom));
	gtk_spin_button_set_value(GTK_SPIN_BUTTON (agen),age);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON (poidsn),poids);
	
	gtk_entry_set_text(GTK_ENTRY (tensionn),_(tension));
	if (!strcmp(tension,"hypotension"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(tensionn),0);
	if (!strcmp(tension,"hypertension"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(tensionn),1);
	if (!strcmp(tension,"tension_normale"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(tensionn),2);
	if (!strcmp(tension,"autres_maladies"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(tensionn),3);

	
	gtk_entry_set_text(GTK_ENTRY (maladiesn),_(maladies));
	if (!strcmp(maladies,"diabète"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(maladiesn),0);
	if (!strcmp(maladies,"obésité"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(maladiesn),1);
	if (!strcmp(maladiesn,"autre"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(maladiesn),2);

	gtk_entry_set_text(GTK_ENTRY (observationsn),_(observations));
	gtk_widget_hide(window3n);
	gtk_widget_show(window7n);

		
}


void
on_button99n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window3n,*window6n,*List_View;
window3n=create_window3n();
gtk_widget_show (window3n);
window6n=lookup_widget(objet_graphique,"window6n");
gtk_widget_hide(window6n);
List_View=lookup_widget(window3n,"treeview1");
afficher1n(List_View);
}


void
on_button98n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2n,*window4n;
window2n=create_window2n();
gtk_widget_show (window2n);
window4n=lookup_widget(objet_graphique,"window4n");
gtk_widget_hide(window4n);
}


void
on_button97n_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2n,*window5n;
window2n=create_window2n();
gtk_widget_show (window2n);
window5n=lookup_widget(objet_graphique,"window5n");
gtk_widget_hide(window5n);
}


void
on_button101n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5n,*window8n;
window8n=create_window8n();
gtk_widget_show (window8n);
window5n=lookup_widget(objet_graphique,"window5n");
gtk_widget_hide(window5n);
}


void
on_button102n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)

{
GtkWidget *jour1,*jour,*mois,*annee,*heure,*window5n,*window8n,*List_View;
	dispo d;
	
	
	jour1=lookup_widget(objet_graphique,"comboboxentry108n");
	jour=lookup_widget(objet_graphique,"spinbutton400n");
	mois=lookup_widget(objet_graphique,"spinbutton401n");
	annee=lookup_widget(objet_graphique,"spinbutton402n");
	heure=lookup_widget(objet_graphique,"comboboxentry110n");

	

	strcpy(d.jour1,gtk_combo_box_get_active_text (GTK_COMBO_BOX(jour1)));
	d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
	d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
	d.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
	strcpy(d.heure,gtk_combo_box_get_active_text (GTK_COMBO_BOX(heure)));
	

        ajouter1n(d);

	window5n=create_window5n();
	window8n=lookup_widget(objet_graphique,"window8n");
	gtk_widget_hide(window8n);
	List_View=lookup_widget(window5n,"treeview100n");
	afficher2n(List_View);
	gtk_widget_show (window5n);
	
}


void
on_button103n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window8n,*window5n,*List_View;
window5n=create_window5n();
gtk_widget_show (window5n);
window8n=lookup_widget(objet_graphique,"window8n");
gtk_widget_hide(window8n);
List_View=lookup_widget(window5n,"treeview100n");
afficher2n(List_View);


}


void
on_button201n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *jour1,*jour,*mois,*annee,*heure,*current,*window9n,*window5n,*List_View;
	char jour1k[20],heurek[20];
	int jourk,moisk,anneek;
	jour1=lookup_widget(objet_graphique,"comboboxentry201n");
	jour=lookup_widget(objet_graphique,"spinbutton600n");
	mois=lookup_widget(objet_graphique,"spinbutton601n");
	annee=lookup_widget(objet_graphique,"spinbutton602n");
	heure=lookup_widget(objet_graphique,"comboboxentry203n");
	
	strcpy(jour1k,gtk_combo_box_get_active_text(GTK_COMBO_BOX(jour1)));
	jourk = gtk_spin_button_get_value_as_int(jour);
	moisk = gtk_spin_button_get_value_as_int(mois);
	anneek = gtk_spin_button_get_value_as_int(annee);
	strcpy(heurek,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)));
	
	modifier1n(jour1k,jourk,moisk,anneek,heurek);
	window5n=create_window5n();
	gtk_widget_show (window5n);
	current=lookup_widget(objet_graphique,"window9n");
	gtk_widget_hide(current);
	List_View=lookup_widget(window5n,"treeview100n");
	afficher2n(List_View);
}


void
on_button202n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *jour1,*jour,*mois,*annee,*heure,*current,*window9n,*window5n,*List_View;
	char jour1k[20],heurek[20];
	int jourk,moisk,anneek;
	jour1=lookup_widget(objet_graphique,"comboboxentry201n");
	jour=lookup_widget(objet_graphique,"spinbutton600n");
	mois=lookup_widget(objet_graphique,"spinbutton601n");
	annee=lookup_widget(objet_graphique,"spinbutton602n");
	heure=lookup_widget(objet_graphique,"comboboxentry203n");
	
	strcpy(jour1k,gtk_combo_box_get_active_text(GTK_COMBO_BOX(jour1)));
	jourk = gtk_spin_button_get_value_as_int(jour);
	moisk = gtk_spin_button_get_value_as_int(mois);
	anneek = gtk_spin_button_get_value_as_int(annee);
	strcpy(heurek,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)));
	
	supprimer1n(jour1k,jourk,moisk,anneek,heurek);
	window5n=create_window5n();
	gtk_widget_show (window5n);
	current=lookup_widget(objet_graphique,"window9n");
	gtk_widget_hide(current);
	List_View=lookup_widget(window5n,"treeview100n");
	afficher2n(List_View);
}


void
on_button203n_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window9n,*window5n,*List_View;
window5n=create_window5n();
gtk_widget_show (window5n);
window9n=lookup_widget(objet_graphique,"window9n");
gtk_widget_hide(window9n);
List_View=lookup_widget(window5n,"treeview100n");
afficher2n(List_View);

}


void
on_treeview100n_row_activated          (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *jour1n,*journ,*moisn,*anneen,*heuren,*window9n,*window5n,*treeview;
gchar *jour1,*heure;
int jour,mois,annee;
	window9n=create_window9n();
	treeview=lookup_widget(objet_graphique,"treeview100n");
	window5n=lookup_widget(objet_graphique,"window5n");
	jour1n=lookup_widget(window9n,"comboboxentry201n");
	journ=lookup_widget(window9n,"spinbutton600n");
	moisn=lookup_widget(window9n,"spinbutton601n");
	anneen=lookup_widget(window9n,"spinbutton602n");
	heuren=lookup_widget(window9n,"comboboxentry203n");
	GtkTreeIter iter;
	GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview));
	gtk_tree_model_get_iter(model,&iter,path);
	gtk_tree_model_get (model,&iter,0,&jour1,1,&jour,2,&mois,3,&annee,4,&heure,-1);
	g_print("%s %d %d %d %s",jour1,jour,mois,annee,heure);
	gtk_entry_set_text(GTK_ENTRY (jour1n),_(jour1));
	if (!strcmp(jour1,"Lundi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),0);
	if (!strcmp(jour1,"Mardi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),1);
	if (!strcmp(jour1,"Mercredi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),2);
	if (!strcmp(jour1,"Jeudi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),3);
	if (!strcmp(jour1,"Vendredi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),4);
	if (!strcmp(jour1,"Samedi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),5);
	if (!strcmp(jour1,"Dimanche"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),6);



	gtk_spin_button_set_value(GTK_SPIN_BUTTON (journ),jour);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON (moisn),mois);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON (anneen),annee);
	
	gtk_entry_set_text(GTK_ENTRY (heuren),_(heure));
	if (!strcmp(heure,"8h/9h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),0);
	if (!strcmp(heure,"9h/10h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),1);
	if (!strcmp(heure,"10h/11h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),2);	
	if (!strcmp(heure,"11h/12h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),3);	
	if (!strcmp(heure,"15h/16h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),4);	
	if (!strcmp(heure,"16h/17h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),5);	
		
	
	


	gtk_widget_hide(window5n);
	gtk_widget_show(window9n);
}






void
on_button5000n_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom,*prenom,*date,*email,*cin,*adresse,*current,*window2n,*window4n;
	char nomk[50],prenomk[50],datek[50],emailk[50],cink[50],adressek[50];
	
	nom=lookup_widget(objet_graphique,"entry1000n");
	prenom=lookup_widget(objet_graphique,"entry2");
	date=lookup_widget(objet_graphique,"entry1002n");
	email=lookup_widget(objet_graphique,"entry1003n");
	cin=lookup_widget(objet_graphique,"entry1004n");
	adresse=lookup_widget(objet_graphique,"entry1005n");
	
	strcpy(nomk,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(prenomk,gtk_entry_get_text(GTK_ENTRY(prenom)));
	strcpy(datek,gtk_entry_get_text(GTK_ENTRY(date)));
	strcpy(emailk,gtk_entry_get_text(GTK_ENTRY(email)));
	strcpy(cink,gtk_entry_get_text(GTK_ENTRY(cin)));
	strcpy(adressek,gtk_entry_get_text(GTK_ENTRY(adresse)));
	
	modifier2n(nomk,prenomk,datek,emailk,cink,adressek);
	//window2n=create_window2n();
	//gtk_widget_show (window2n);
	//current=lookup_widget(objet_graphique,"window4n");
	//gtk_widget_hide(current);
	
}


void
on_button6000n_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2n,*window10n,*List_View;
window10n=create_window10n();
gtk_widget_show (window10n);
window2n=lookup_widget(objet_graphique,"window2n");
gtk_widget_hide(window2n);
List_View=lookup_widget(window10n,"treeview6000n");
afficher3n(List_View);

}


void
on_button6001n_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window10n,*window2n;
window2n=create_window2n();
gtk_widget_show (window2n);
window10n=lookup_widget(objet_graphique,"window10n");
gtk_widget_hide(window10n);
}






/* ************************************************
**************************************************
**************************************************
fin nutri */


