#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonction.h"
#include <gtk/gtk.h>

void afficher()
{
	FILE *f;
	char login[20],password[20];

	f=fopen("src/users.txt","r");
	
	int role;
	while(fscanf(f,"%s %s %d", login, password, &role)!=EOF){
		printf("%s %s %d\n", login, password, role);
	}
	fclose(f);
}

int verifier(char login[],char password[])
{
	FILE *f;
	f=fopen("src/users.txt","r");
	
	char login1[20],password1[20];
	while(fscanf(f,"%s %s", login1, password1)!=EOF){
		if (strcmp(login1,login)==0 && strcmp(password1,password)==0)
		{
			fclose(f);			return 1;
		}
	}
	fclose(f);
	return(0);
}




void ajoutern(adherant a)
{
	FILE *f;
	f = fopen("src/fichen.txt","a+");
	if(f!=NULL){
		fprintf(f,"%s %s %s %d %d %s %s %s\n",a.identifiant,a.nom,a.prenom,a.age,a.poids,a.tension,a.maladies,a.observations);
	}
	fclose(f);

}





void afficher1n(GtkWidget *plistview)
{ 
enum { COL_IDENTIFIANT,
	COL_NOM,
       COL_PRENOM,
       COL_AGE,
	COL_POIDS,
	COL_TENSION,
	COL_MALADIES,
	COL_OBSERVATIONS,
       NUM_COLS
      };
char identifiant[20],nom[20],prenom[20],tension[20],maladies[20],observations[150];
int age,poids;
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("src/fichen.txt","r");

if(f!=NULL){
       while(fscanf(f,"%s %s %s %d %d %s %s %s\n",identifiant,nom,prenom,&age,&poids,tension,maladies,observations)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
			COL_IDENTIFIANT, identifiant,
			COL_NOM, nom,
       			COL_PRENOM,prenom,
       			COL_AGE,age,
			COL_POIDS,poids,
			COL_TENSION,tension,
			COL_MALADIES,maladies,
			COL_OBSERVATIONS,observations,
                       -1);}
		
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Identifiant",celrender,"text",COL_IDENTIFIANT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Nom",celrender,"text",COL_NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Prenom",celrender,"text",COL_PRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Age",celrender,"text",COL_AGE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Poids",celrender,"text",COL_POIDS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Tension",celrender,"text",COL_TENSION,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Maladies",celrender,"text",COL_MALADIES,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
	
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Observations",celrender,"text",COL_OBSERVATIONS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}
  


void modifiern(char identifiant[],char nom[],char prenom[],int age,int poids,char tension[],char maladies[],char observations[])
{ 	
	char identifiantn[20],nomn[20],prenomn[20],tensionn[20],maladiesn[20],observationsn[150];
int agen,poidsn;
	FILE *f , *tmp;
	f=fopen("src/fichen.txt","r");
	tmp=fopen("src/fichen.tmp","a+");
	while(fscanf(f,"%s %s %s %d %d %s %s %s\n",identifiantn,nomn,prenomn,&agen,&poidsn,tensionn,maladiesn,observationsn)!=EOF){
		if(!strcmp(identifiant,identifiantn) ){fprintf(tmp,"%s %s %s %d %d %s %s %s\n",identifiant,nom,prenom,age,poids,tension,maladies,observations);}
else fprintf(tmp,"%s %s %s %d %d %s %s %s\n",identifiantn,nomn,prenomn,agen,poidsn,tensionn,maladiesn,observationsn);
}
fclose(f);
fclose(tmp);
rename("src/fichen.tmp","src/fichen.txt");
}                  


void supprimern(char identifiant[],char nom[],char prenom[],int age,int poids,char tension[],char maladies[],char observations[])
{ 	
	char identifiantn[20],nomn[20],prenomn[20],tensionn[20],maladiesn[20],observationsn[150];
int agen,poidsn;
	FILE *f , *tmp;
	f=fopen("src/fichen.txt","r");
	tmp=fopen("src/fichen.tmp","a+");
	while(fscanf(f,"%s %s %s %d %d %s %s %s\n",identifiantn,nomn,prenomn,&agen,&poidsn,tensionn,maladiesn,observationsn)!=EOF){
		if(!strcmp(identifiant,identifiantn) ){continue;}
else fprintf(tmp,"%s %s %s %d %d %s %s %s\n",identifiantn,nomn,prenomn,agen,poidsn,tensionn,maladiesn,observationsn);
}
fclose(f);
fclose(tmp);
rename("src/fichen.tmp","src/fichen.txt");
}                  








void ajouter1n(dispo d)
{
	FILE *f;
	f = fopen("src/dispon.txt","a+");
	if(f!=NULL){
		fprintf(f,"%s %d %d %d %s\n",d.jour1,d.jour,d.mois,d.annee,d.heure);
	}
	fclose(f);

}


void afficher2n(GtkWidget *plistview)
{ 
enum { COL_JOUR1,
	COL_JOUR,
       COL_MOIS,
       COL_ANNEE,
	COL_HEURE,
       NUM_COLS
      };
char jour1[20],heure[20];
int jour,mois,annee;
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
FILE *f;
f=fopen("src/dispon.txt","r");

if(f!=NULL){
       while(fscanf(f,"%s %d %d %d %s\n",jour1,&jour,&mois,&annee,heure)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
			COL_JOUR1, jour1,
			COL_JOUR, jour,
			COL_MOIS, mois,
			COL_ANNEE, annee,
       			COL_HEURE,heure,
                       -1);}
		
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Jour",celrender,"text",COL_JOUR1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Jour",celrender,"text",COL_JOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);


	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Mois",celrender,"text",COL_MOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Annee",celrender,"text",COL_ANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Heure",celrender,"text",COL_HEURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);


	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}
  



void modifier1n(char jour1[],int jour,int mois,int annee,char heure[])
{ 	
	char jour1n[20],heuren[20];
	int journ,moisn,anneen;
	
	FILE *f , *tmp;
	f=fopen("src/dispon.txt","r");
	tmp=fopen("src/dispon.tmp","a+");
	while(fscanf(f,"%s %d %d %d %s\n",jour1n,&journ,&moisn,&anneen,heuren)!=EOF){
		if(!strcmp(jour1,jour1n) ){fprintf(tmp,"%s %d %d %d %s\n",jour1,jour,mois,annee,heure);}
else fprintf(tmp,"%s %d %d %d %s\n",jour1n,journ,moisn,anneen,heuren);
}
fclose(f);
fclose(tmp);
rename("src/dispon.tmp","src/dispon.txt");
}                  
                  


void supprimer1n(char jour1[],int jour,int mois,int annee,char heure[])
{ 	
	char jour1n[20],heuren[20];
	int journ,moisn,anneen;
	
	FILE *f , *tmp;
	f=fopen("src/dispon.txt","r");
	tmp=fopen("src/dispon.tmp","a+");
	while(fscanf(f,"%s %d %d %d %s\n",jour1n,&journ,&moisn,&anneen,heuren)!=EOF){
		if(!strcmp(jour1,jour1n) ){continue;}
else fprintf(tmp,"%s %d %d %d %s\n",jour1n,journ,moisn,anneen,heuren);
}
fclose(f);
fclose(tmp);
rename("src/dispon.tmp","src/dispon.txt");
}                  
                  





void modifier2n(char nom[],char prenom[],char date[],char email[],char cin[],char adresse[])
{ 	
	char nomn[20],prenomn[20],daten[20],emailn[20],cinn[8],adressen[20];
	
	
	FILE *f , *tmp;
	f=fopen("src/profiln.txt","r");
	tmp=fopen("src/profiln.tmp","a+");
	while(fscanf(f,"%s %s %s %s %s %s\n",nomn,prenomn,daten,emailn,cinn,adressen)!=EOF){
		if(!strcmp(nom,nomn) && !strcmp(prenom,prenomn) && !strcmp(date,daten) && !strcmp(cin,cinn) ){fprintf(tmp,"%s %s %s %s %s %s\n",nom,prenom,date,email,cin,adresse);}
else fprintf(tmp,"%s %s %s %s %s %s\n",nomn,prenomn,daten,emailn,cinn,adressen);
}
fclose(f);
fclose(tmp);
rename("src/profiln.tmp","src/profiln.txt");
}                  








/*void afficher3n(GtkWidget *plistview)
{ 
enum { COL_JOUR,
       COL_MOIS,
       COL_ANNEE,
	COL_HEURE,
	COL_MED,
	COL_BUT,
       NUM_COLS
      };
char med[20],heure[20],but[20];
int jour,mois,annee;
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("src/rdvmed.txt","r");

if(f!=NULL){
       while(fscanf(f,"%d %d %d %s %s %s\n",&jour,&mois,&annee,heure,med,but)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
			COL_JOUR, jour,
			COL_MOIS, mois,
			COL_ANNEE, annee,
       			COL_HEURE,heure,
			COL_MED,med,
			COL_BUT,but,
                       -1);}
		
	
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Jour",celrender,"text",COL_JOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);


	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Mois",celrender,"text",COL_MOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Annee",celrender,"text",COL_ANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Heure",celrender,"text",COL_HEURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Medecin",celrender,"text",COL_MED,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);


	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("But",celrender,"text",COL_BUT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);


	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
} */







void afficher3n(GtkWidget *plistview)
{ 
enum { COL_STAFF,
       COL_TYPE,
       COL_HEURE,
	COL_JOUR,
	COL_MOIS,
	COL_ANNEE,
       NUM_COLS
      };
char staff[20],type[20],heure[20],jour[20],mois[20],annee[20];
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("src/rdvmed.txt","r");

if(f!=NULL){
       while(fscanf(f,"%s %s %s %s %s %s\n",staff,type,heure,jour,mois,annee)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
			COL_STAFF,staff,
       			COL_TYPE,type,
       			COL_HEURE,heure,
			COL_JOUR,jour,
			COL_MOIS,mois,
			COL_ANNEE,annee,
                       -1);}


	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Staff",celrender,"text",COL_STAFF,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);




	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Type",celrender,"text",COL_TYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);





	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Heure",celrender,"text",COL_HEURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

		
	
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Jour",celrender,"text",COL_JOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);


	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Mois",celrender,"text",COL_MOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Annee",celrender,"text",COL_ANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	
	


	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
} 



