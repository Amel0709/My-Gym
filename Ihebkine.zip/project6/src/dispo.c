#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dispo.h"
#include <gtk/gtk.h>
void afficher2(GtkWidget *plistview)
{ 
enum { COL_JOUR1,
	COL_JOUR,
       COL_MOIS,
       COL_ANNEE,
	COL_HEURE,
       NUM_COLS
      };
char jour1[20],heure[20];
int jour,mois,annee;
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
FILE *f;
f=fopen("src/dispok.txt","r");

if(f!=NULL){
       while(fscanf(f,"%s %d %d %d %s\n",jour1,&jour,&mois,&annee,heure)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
			COL_JOUR1, jour1,
			COL_JOUR, jour,
			COL_MOIS, mois,
			COL_ANNEE, annee,
       			COL_HEURE,heure,
                       -1);}
		
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Jour",celrender,"text",COL_JOUR1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Jour",celrender,"text",COL_JOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);


	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Mois",celrender,"text",COL_MOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Annee",celrender,"text",COL_ANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Heure",celrender,"text",COL_HEURE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);


	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}  


void modifier1(char jour1[],int jour,int mois,int annee,char heure[])
{ 	
	char jour1m[20],heurem[20];
	int jourm,moism,anneem;
	
	FILE *f , *tmp;
	f=fopen("src/dispok.txt","r");
	tmp=fopen("src/dispok.tmp","a+");
	while(fscanf(f,"%s %d %d %d %s\n",jour1m,&jourm,&moism,&anneem,heurem)!=EOF){
		if(strcmp(jour1m,jour1)==0 ){fprintf(tmp,"%s %d %d %d %s\n",jour1,jour,mois,annee,heure);}
else fprintf(tmp,"%s %d %d %d %s\n",jour1m,jourm,moism,anneem,heurem);
}
fclose(f);
fclose(tmp);

rename("src/dispok.tmp","src/dispok.txt");
} 








void ajouter1(dispok d)
{
	FILE *f;
	f = fopen("src/dispok.txt","a+");
	if(f!=NULL){
		fprintf(f,"%s %d %d %d %s\n",d.jour1,d.jour,d.mois,d.annee,d.heure);
	}
	fclose(f);
}








void supprimer1(char jour1[],int jour,int mois,int annee,char heure[])
{ 	
	char jour1m[20],heurem[20];
	int jourm,moism,anneem;
	
	FILE *f , *tmp;
	f=fopen("src/dispok.txt","r");
	tmp=fopen("src/dispok.tmp","a+");
	while(fscanf(f,"%s %d %d %d %s\n",jour1m,&jourm,&moism,&anneem,heurem)!=EOF){
		if(!strcmp(jour1,jour1m) &&!strcmp(heure,heurem) ){continue;}
else fprintf(tmp,"%s %d %d %d %s\n",jour1m,jourm,moism,anneem,heurem);
}
fclose(f);
fclose(tmp);
rename("src/dispok.tmp","src/dispok.txt");
}  

