#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fc.h"
#include <gtk/gtk.h>


void ajouterkk(seancek s)
{
	FILE *f;
	f = fopen("src/rdvk.txt","a+");
	if(f!=NULL){
		fprintf(f,"%s %s %d %d %d %s\n",s.nom,s.prenom,s.jour,s.mois,s.annee,s.seancee);
}
	
	fclose(f);
}




void afficherkk()
{
	FILE *f;
	char login[20],password[20];

	f=fopen("src/users.txt","r");
	
	int role;
	while(fscanf(f,"%s %s %d", login, password, &role)!=EOF){
		printf("%s %s %d\n", login, password, role);
	}
	fclose(f);
}

int verifierkk(char login[],char password[])
{
        int ret=0;
	FILE *f;
	f=fopen("src/users.txt","r");
	
	char login1[20],password1[20];
	while(fscanf(f,"%s %s", login1, password1)!=EOF){
		if (strcmp(login1,login)==0 && strcmp(password1,password)==0)
		{
			ret=1;
		}
	}
	fclose(f);
	return ret;}
void afficher_rdv(GtkWidget *liste)
{
        GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;
enum   
{       
      
        NOM,
	PRENOM,
	RDV,
        COLUMNS
};
	char nom [30];
	char prenom [30];
	char rdv [30];
        store=NULL;

       FILE *f;
	
	store=gtk_tree_view_get_model(liste);	
	if (store==NULL)
	{

                renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",NOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",PRENOM, NULL);	
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);	
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes("  Rdv", renderer, "text",RDV, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	

               
	
	}

	
	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING, G_TYPE_STRING);

	f = fopen("src/rdvk.txt", "r");
	
	if(f==NULL)
	{

		return;
	}		
	else 

	{ f = fopen("src/rdvk.txt", "a+");
              while(fscanf(f,"%s %s %s \n",nom,prenom,rdv)!=EOF)
		{
	gtk_list_store_append (store, &iter);
	gtk_list_store_set (store, &iter, NOM, nom, PRENOM, prenom, RDV, rdv, -1); 
		}
		fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
    g_object_unref (store);
	}
}

void k_afficher_tableau_event(GtkWidget *plistview)
{ 
enum { COL_NOM,
       COL_PRENOM,
       COL_JOUR,
       COL_MOIS,
       COL_ANNEE,
       COL_SEANCE,
       NUM_COLS,
      };
char nom[20],prenom[20],seancee[100];
int jour;
int mois;
int annee;
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
FILE *f;
f=fopen("src/rdvk.txt","r");
if(f!=NULL){
       while(fscanf(f,"%s %s %d %d %d %s",nom,prenom,&jour,&mois,&annee,seancee)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
                          COL_NOM, nom,
                          COL_PRENOM, prenom,			  
		          COL_JOUR, jour,
		          COL_MOIS, mois,
		          COL_ANNEE, annee,
                          COL_SEANCE, seancee,
		          		         
                       -1);}
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("nom",celrender,"text",COL_NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("prenom",celrender,"text",COL_PRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("jour",celrender,"text",COL_JOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("mois",celrender,"text",COL_MOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("annee",celrender,"text",COL_ANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
  

        celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("seancee",celrender,"text",COL_SEANCE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);



	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}


void modifier(char nom[],char prenom[],int annee,int mois,int jour,char seancee[])
{    
    char nomk[20],prenomk[20],seanceek[100];
    int anneek,jourk,moisk;
    FILE *f , *tmp;
    f=fopen("src/rdvk.txt","r");
    tmp=fopen("src/rdvk.tmp","a+");
    while(fscanf(f,"%s %s %d %d %d %s\n",nomk,prenomk,&jourk,&moisk,&anneek,seanceek)!=EOF){
        if(!strcmp(nom,nomk) && !strcmp(prenom,prenomk)){fprintf(tmp,"%s %s %d %d %d %s\n",nom,prenom,jour,mois, annee,seancee);}
else fprintf(tmp,"%s %s %d %d %d %s\n",nomk,prenomk,jourk,moisk,anneek,seanceek);
}
fclose(f);
fclose(tmp);
rename("src/rdvk.tmp","src/rdvk.txt");
}      


void supprimer(char nom[],char prenom[],int annee,int mois,int jour,char seancee[])
{    
    char nomk[20],prenomk[20],seanceek[100];
    int anneek,jourk,moisk;
    FILE *f , *tmp;
    f=fopen("src/rdvk.txt","r");
    tmp=fopen("src/rdvk.tmp","a+");
    while(fscanf(f,"%s %s %d %d %d %s\n",nomk,prenomk,&jourk,&moisk,&anneek,seanceek)!=EOF){
        if(!strcmp(nom,nomk) && !strcmp(prenom,prenomk) && !strcmp(seancee,seanceek)){continue;}
else fprintf(tmp,"%s %s %d %d %d %s\n",nomk,prenomk,jourk,moisk,anneek,seanceek);
}
fclose(f);
fclose(tmp);
rename("src/rdvk.tmp","src/rdvk.txt");
}      











int supprimer_tout(char nom[],char prenom[],char rdv[] )
{
 char nomk[20],prenomk[20],rdvk[20];
    FILE *f , *tmp;
    f=fopen("src/rdvk.txt","r");
    tmp=fopen("src/rdvk.tmp","a+");
    while(fscanf(f,"%s %s %s",nom,prenom,rdv)!=EOF){
        if(strcmp(nom,nomk)==0 && strcmp(prenom,prenomk)==0 && strcmp(rdv,rdvk)==0)
              
{fprintf(tmp,"%s %s %s\n",nom="", prenom="",rdv="");
}
}
fclose(f);
fclose(tmp);
rename("src/rdvk.tmp","src/rdvk.txt");
}


void k_modifier2(char nom[],char prenom[],char date[],char email[],char cin[],char adresse[],char poids[], char objectif[])
{   
    char nom1[50],prenom1[50],date1[50],email1[50],cin1[50],adresse1[50],poids1[50],objectif1[50];
  
  
    FILE *f , *tmp;
    f=fopen("src/profilk.txt","r");
    tmp=fopen("src/profil1k.txt","a+");
    while(fscanf(f,"%s %s %s %s %s %s %s %s\n",nom1,prenom1,date1,email1,cin1,adresse1,poids1,objectif1)!=EOF){
        if(!strcmp(nom,nom1) && !strcmp(prenom,prenom1) && !strcmp(date,date1) && !strcmp(cin,cin1) ){fprintf(tmp,"%s %s %s %s %s %s %s %s\n",nom,prenom,date,email,cin,adresse,poids,objectif);}
else fprintf(tmp,"%s %s %s %s %s %s %s %s\n",nom1,prenom1,date1,email1,cin1,adresse1,poids1,objectif1);
}
fclose(f);
fclose(tmp);
rename("src/profil1k.txt","src/profilk.txt");
}























void afficher3k(GtkWidget *plistview)
{
enum { COL_STAFF,
       COL_TYPE,
       COL_HEURE,
    COL_JOUR,
    COL_MOIS,
    COL_ANNEE,
       NUM_COLS
      };
char staff[20],type[20],heure[20],jour[20],mois[20],annee[20];
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("src/seance1.txt","r");

if(f!=NULL){
       while(fscanf(f,"%s %s %s %s %s %s\n",staff,type,heure,jour,mois,annee)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
            COL_STAFF,staff,
                   COL_TYPE,type,
                   COL_HEURE,heure,
            COL_JOUR,jour,
            COL_MOIS,mois,
            COL_ANNEE,annee,
                       -1);}


    celrender = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Staff",celrender,"text",COL_STAFF,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);




    celrender = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Type",celrender,"text",COL_TYPE,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);





    celrender = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Heure",celrender,"text",COL_HEURE,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

       
   
    celrender = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Jour",celrender,"text",COL_JOUR,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);


    celrender = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Mois",celrender,"text",COL_MOIS,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

    celrender = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes("Annee",celrender,"text",COL_ANNEE,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

   
   


    gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
} 










void afficherk(GtkWidget *plistview)
{ 
enum { COL_IDENTIFIANT,
	COL_NOM,
       COL_PRENOM,
       COL_AGE,
	COL_POIDS,
	COL_TENSION,
	COL_MALADIES,
	COL_OBSERVATIONS,
       NUM_COLS
      };
char identifiant[20],nom[20],prenom[20],tension[20],maladies[20],observations[150];
int age,poids;
GtkListStore *liststore;
GtkCellRenderer *celrender;
GtkTreeViewColumn *col;
liststore = gtk_list_store_new(NUM_COLS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
FILE *f;
f=fopen("src/fichen.txt","r");

if(f!=NULL){
       while(fscanf(f,"%s %s %s %d %d %s %s %s\n",identifiant,nom,prenom,&age,&poids,tension,maladies,observations)!=EOF){
           GtkTreeIter iter;
            gtk_list_store_append(liststore, &iter);
            gtk_list_store_set(liststore, &iter,
			COL_IDENTIFIANT, identifiant,
			COL_NOM, nom,
       			COL_PRENOM,prenom,
       			COL_AGE,age,
			COL_POIDS,poids,
			COL_TENSION,tension,
			COL_MALADIES,maladies,
			COL_OBSERVATIONS,observations,
                       -1);}
		
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Identifiant",celrender,"text",COL_IDENTIFIANT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Nom",celrender,"text",COL_NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Prenom",celrender,"text",COL_PRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Age",celrender,"text",COL_AGE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Poids",celrender,"text",COL_POIDS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Tension",celrender,"text",COL_TENSION,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Maladies",celrender,"text",COL_MALADIES,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);
	
	celrender = gtk_cell_renderer_text_new();
	col = gtk_tree_view_column_new_with_attributes("Observations",celrender,"text",COL_OBSERVATIONS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(plistview),col);

	gtk_tree_view_set_model (GTK_TREE_VIEW(plistview), GTK_TREE_MODEL (liststore));

}
fclose(f);
}



