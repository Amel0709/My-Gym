#include <gtk/gtk.h>


void
on_button1k_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);





void
on_button16k_clicked                    (GtkWidget       *objet_graphique16,
                                        gpointer         user_data);

void
on_button3k_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4k_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8k_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2k_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5k_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data);



void
on_button14k_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15k_clicked                    (GtkWidget       *objet_graphique15,
                                        gpointer         user_data);

void
on_button19k_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button18k_clicked                    (GtkWidget      *objet_graphique18,
                                        gpointer         user_data);

void
on_button20k_clicked                    (GtkWidget      *objet_graphique20,
                                        gpointer         user_data);

void
on_button22k_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button23k_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24k_clicked                    (GtkWidget      *objet_graphique24,
                                        gpointer         user_data);

void
on_button25k_clicked                    (GtkWidget      *objet_graphique25,
                                        gpointer         user_data);

void
on_button26k_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button27k_clicked                    (GtkWidget      *objet_graphique27,
                                        gpointer         user_data);



void
on_button28k_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_button29k_clicked                    (GtkWidget   *objet_graphique,
                                        gpointer         user_data);







void
on_button13k_clicked                   (GtkWidget *objet_graphique,
                                        gpointer         user_data);


void
on_buttok18_enter                      (GtkButton       *button,
                                        gpointer         user_data);



void
on_buttonkmod_clicked                  (GtkWidget    *objet_graphique,
                                        gpointer         user_data);

void
on_buttonksupp_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_buttonajk_clicked                   (GtkWidget         *objet_graphique,
                                        gpointer         user_data);

void
on_treeviewk2_row_activated            (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonkkaj_clicked                  (GtkWidget    *objet_graphique,
                                        gpointer         user_data);

void
on_buttonpro_clicked                   (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonret_clicked                   (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonret1_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonret4_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonret5_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonprom_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonprore_clicked                 (      GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonretourkk_clicked              (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonaffrdv_clicked                (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_retourrdv_clicked                   (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttoncclosek_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6k_clicked                    (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonRETK_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data);

void
on_buttonFM_clicked                    (GtkWidget   *objet_graphique,
                                        gpointer         user_data);



void
on_treeviewk11_row_activated           (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
