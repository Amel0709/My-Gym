#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fc.h"
#include "dispo.h"

void
on_button1k_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
	int x=0;	
	GtkWidget *a ,*b,*c ,*window1,*window2;
	char login[20],password[20];
	
	window1= lookup_widget(objet_graphique,"window1");	
	a=lookup_widget(objet_graphique,"entry1k");
	b=lookup_widget(objet_graphique,"entry2k");
	c=lookup_widget(objet_graphique,"label5");
	strcpy(login,gtk_entry_get_text(GTK_ENTRY(a)));
	strcpy(password,gtk_entry_get_text(GTK_ENTRY(b)));
	x =verifierkk(login,password);
	
	if(x==1){
window2=create_window2();
gtk_widget_show (window2);
gtk_widget_hide(window1);
}
	else 
	{ gtk_label_set_text(GTK_LABEL(c),"authentification non validée");}
}





void
on_button16k_clicked                    (GtkWidget      *objet_graphique16,
                                        gpointer         user_data)
{
GtkWidget *window2,*window4;
window2=lookup_widget(objet_graphique16,"window2");
window4=create_window4();
gtk_widget_show (window4);
gtk_widget_hide(window2);

}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button2k_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button5k_clicked                     (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{

GtkWidget *window5,*window4,*List_View;
window5=create_window5();
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
List_View=lookup_widget(window5,"treeviewk11");
k_afficher_tableau_event(List_View);
gtk_widget_show (window5);

}





void
on_button14k_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button15k_clicked                    (GtkWidget      *objet_graphique15,
                                        gpointer         user_data)
{
GtkWidget *window2,*window4;
window4=lookup_widget(objet_graphique15,"window4");
window2=create_window2();
gtk_widget_show (window2);
gtk_widget_hide(window4);
}


void
on_button19k_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button18k_clicked                    (GtkWidget      *objet_graphique18,
                                        gpointer         user_data)
{
GtkWidget *window5,*window6;
window5=lookup_widget(objet_graphique18,"window5");
window6=create_window6();
gtk_widget_show (window6);
gtk_widget_hide(window5);
}


void
on_button20k_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom ,*prenom,*jour,*mois,*annee,*seancee ,*window5;
	
	 
        seancek s;
	nom=lookup_widget(objet_graphique,"entry7k");
	prenom=lookup_widget(objet_graphique,"entry8k");
	jour=lookup_widget(objet_graphique,"jourk");
        mois=lookup_widget(objet_graphique,"moisk");
        annee=lookup_widget(objet_graphique,"anneek");
	seancee=lookup_widget(objet_graphique,"combobox3k");
        strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(s.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
        s.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
        s.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
        s.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
        strcpy(s.seancee,gtk_combo_box_get_active_text (GTK_COMBO_BOX(seancee)));
        ajouterkk(s);
}


void
on_button22k_clicked                    (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5,*window6,*List_View;
window5=create_window5();
window6=lookup_widget(objet_graphique,"window6");
gtk_widget_hide(window6);
List_View=lookup_widget(window5,"treeviewk11");
k_afficher_tableau_event(List_View);
gtk_widget_show (window5);
}


void
on_button23k_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button24k_clicked                    (GtkWidget      *objet_graphique24,
                                        gpointer         user_data)
{
GtkWidget *window4,*window5;
window5=lookup_widget(objet_graphique24,"window5");
window4=create_window4();
gtk_widget_show (window4);
gtk_widget_hide(window5);
}


void
on_button25k_clicked                    (GtkWidget      *objet_graphique25,
                                        gpointer         user_data)
{
GtkWidget *window5,*window7;
window5=lookup_widget(objet_graphique25,"window5");
window7=create_window7();
gtk_widget_show (window7);
gtk_widget_hide(window5);
}


void
on_button26_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void 
on_button27k_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

    GtkWidget *nom,*prenom,*jour,*mois,*annee,*seancee,*List_View,*current,*window5;
    char nomk[20],prenomk[20],seanceek[100];
    int moisk,anneek,jourk;
    nom=lookup_widget(objet_graphique,"entry10k");
    prenom=lookup_widget(objet_graphique,"entry11k");
    jour=lookup_widget(objet_graphique,"jour1k");
    mois=lookup_widget(objet_graphique,"mois1k");
    annee=lookup_widget(objet_graphique,"annee1k");
    seancee=lookup_widget(objet_graphique,"combobox1k");
    strcpy(nomk,gtk_entry_get_text(GTK_ENTRY(nom)));
    strcpy(prenomk,gtk_entry_get_text(GTK_ENTRY(prenom)));
    jourk = gtk_spin_button_get_value_as_int(jour);
    moisk = gtk_spin_button_get_value_as_int(mois);
    anneek = gtk_spin_button_get_value_as_int(annee);
    strcpy(seanceek,gtk_combo_box_get_active_text(GTK_COMBO_BOX(seancee)));
    modifier(nomk,prenomk,anneek,moisk,jourk,seanceek);
	
    
    window5=create_window5();
    gtk_widget_show (window5);
    current=lookup_widget(objet_graphique,"window7");
    gtk_widget_hide(current);
    List_View=lookup_widget(window5,"treeviewk11");
    k_afficher_tableau_event(List_View);
    
   


}





void
on_button28k_clicked                    (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
 GtkWidget *nom,*prenom,*jour,*mois,*annee,*seancee,*List_View,*current, *window5;
    char nomk[20],prenomk[20],seanceek[100];
    int moisk,anneek,jourk;
    nom=lookup_widget(objet_graphique,"entry10k");
    prenom=lookup_widget(objet_graphique,"entry11k");
    jour=lookup_widget(objet_graphique,"jour1k");
    mois=lookup_widget(objet_graphique,"mois1k");
    annee=lookup_widget(objet_graphique,"annee1k");
    seancee=lookup_widget(objet_graphique,"combobox1k");
    strcpy(nomk,gtk_entry_get_text(GTK_ENTRY(nom)));
    strcpy(prenomk,gtk_entry_get_text(GTK_ENTRY(prenom)));
    jourk = gtk_spin_button_get_value_as_int(jour);
    moisk = gtk_spin_button_get_value_as_int(mois);
    anneek = gtk_spin_button_get_value_as_int(annee);
    strcpy(seanceek,gtk_combo_box_get_active_text(GTK_COMBO_BOX(seancee)));
    supprimer(nomk,prenomk,jourk,moisk,anneek,seanceek);
	
    
    window5=create_window5();
    gtk_widget_show (window5);
    current=lookup_widget(objet_graphique,"window7");
    gtk_widget_hide(current);
    List_View=lookup_widget(window5,"treeviewk11");
    k_afficher_tableau_event(List_View);
}


void
on_button29k_clicked                    (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{

}




void
on_button13k_clicked                   (GtkWidget *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window4,*window9,*List_View;
window9=create_window9();
gtk_widget_show (window9);
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
List_View=lookup_widget(window9,"treeviewk2");
afficher2(List_View);
}





void
on_buttok18_enter                      (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_buttonkmod_clicked                  (GtkWidget    *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *jour1,*jour,*mois,*annee,*heure,*current,*window8,*window9,*List_View;
	char jour1k[20],heurek[20];
	int jourk,moisk,anneek;
	jour1=lookup_widget(objet_graphique,"comboboxk1");
	jour=lookup_widget(objet_graphique,"spinbuttonJ");
	mois=lookup_widget(objet_graphique,"spinbuttonM");
	annee=lookup_widget(objet_graphique,"spinbuttonA");
	heure=lookup_widget(objet_graphique,"comboboxk2");
	
	strcpy(jour1k,gtk_combo_box_get_active_text(GTK_COMBO_BOX(jour1)));
	jourk = gtk_spin_button_get_value_as_int(jour);
	moisk = gtk_spin_button_get_value_as_int(mois);
	anneek = gtk_spin_button_get_value_as_int(annee);
	strcpy(heurek,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)));
	
	modifier1(jour1k,jourk,moisk,anneek,heurek);
	window9=create_window9();
	gtk_widget_show (window9);
	current=lookup_widget(objet_graphique,"window8");
	gtk_widget_hide(current);
	List_View=lookup_widget(window9,"treeviewk2");
	afficher2(List_View);
}


void
on_buttonksupp_clicked                 (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *jour1,*jour,*mois,*annee,*heure,*current,*window8,*window9,*List_View;
	char jour1k[20],heurek[20];
	int jourk,moisk,anneek;
	jour1=lookup_widget(objet_graphique,"comboboxk1");
	jour=lookup_widget(objet_graphique,"spinbuttonJ");
	mois=lookup_widget(objet_graphique,"spinbuttonM");
	annee=lookup_widget(objet_graphique,"spinbuttonA");
	heure=lookup_widget(objet_graphique,"comboboxk2");
	
	strcpy(jour1k,gtk_combo_box_get_active_text(GTK_COMBO_BOX(jour1)));
	jourk = gtk_spin_button_get_value_as_int(jour);
	moisk = gtk_spin_button_get_value_as_int(mois);
	anneek = gtk_spin_button_get_value_as_int(annee);
	strcpy(heurek,gtk_combo_box_get_active_text(GTK_COMBO_BOX(heure)));
	
	supprimer1(jour1k,jourk,moisk,anneek,heurek);
	window9=create_window9();
	gtk_widget_show (window9);
	current=lookup_widget(objet_graphique,"window8");
	gtk_widget_hide(current);
	List_View=lookup_widget(window9,"treeviewk2");
	afficher2(List_View);
}


void
on_buttonajk_clicked                   (GtkWidget      *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window9,*window10;
window9=lookup_widget(objet_graphique,"window9");
window10=create_window10();
gtk_widget_show (window10);
gtk_widget_hide(window9);
}


void
on_treeviewk2_row_activated            (GtkWidget    *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *jour1n,*journ,*moisn,*anneen,*heuren,*window8,*window9,*treeview;
gchar *jour1,*heure;
int jour,mois,annee;
	window8=create_window8();
	treeview=lookup_widget(objet_graphique,"treeviewk2");
	window9=lookup_widget(objet_graphique,"window9");
	jour1n=lookup_widget(window8,"comboboxk1");
	journ=lookup_widget(window8,"spinbuttonJ");
	moisn=lookup_widget(window8,"spinbuttonM");
	anneen=lookup_widget(window8,"spinbuttonA");
	heuren=lookup_widget(window8,"comboboxk2");
	GtkTreeIter iter;
	GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview));
	gtk_tree_model_get_iter(model,&iter,path);
	gtk_tree_model_get (model,&iter,0,&jour1,1,&jour,2,&mois,3,&annee,4,&heure,-1);
	printf("%s %d %d %d %s",jour1,jour,mois,annee,heure);
	gtk_entry_set_text(GTK_ENTRY (jour1n),_(jour1));
        if (!strcmp(jour1,"Lundi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),0);
if (!strcmp(jour1,"Mardi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),1);
if (!strcmp(jour1,"Mercredi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),2);
if (!strcmp(jour1,"Jeudi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),3);
if (!strcmp(jour1,"Vendredi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),4);
if (!strcmp(jour1,"Samedi"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),5);
if (!strcmp(jour1,"Dimanche"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(jour1n),6);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON (journ),jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON (moisn),mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON (anneen),annee);
       
 	
	
	gtk_entry_set_text(GTK_ENTRY (heuren),_(heure));
        gtk_entry_set_text(GTK_ENTRY (heuren),_(heure));
if (!strcmp(heure,"8h/9h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),0);
if (!strcmp(heure,"9h/10h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),1);
if (!strcmp(heure,"10h/11h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),2);
if (!strcmp(heure,"11h/12h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),3);
if (!strcmp(heure,"14h/15h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),4);
if (!strcmp(heure,"15h/16h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),5);
if (!strcmp(heure,"16h/17h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),6);
if (!strcmp(heure,"17h/18h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),7);
if (!strcmp(heure,"18h/19h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),8);
if (!strcmp(heure,"19h/20h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),9);
if (!strcmp(heure,"20h/21h"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(heuren),10);
	gtk_widget_hide(window9);
	gtk_widget_show(window8);
}


void
on_buttonkkaj_clicked                  (GtkWidget    *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *jour1,*jour,*mois,*annee,*heure,*window9,*window10,*List_View;
	dispok d;
	
	
	jour1=lookup_widget(objet_graphique,"comboboxk5");
	jour=lookup_widget(objet_graphique,"spinbuttonk5");
	mois=lookup_widget(objet_graphique,"spinbuttonk6");
	annee=lookup_widget(objet_graphique,"spinbuttonk7");
	heure=lookup_widget(objet_graphique,"comboboxkk");

	

	strcpy(d.jour1,gtk_combo_box_get_active_text (GTK_COMBO_BOX(jour1)));
	d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
	d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));
	d.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee));
	strcpy(d.heure,gtk_combo_box_get_active_text (GTK_COMBO_BOX(heure)));
	

        ajouter1(d);

	window9=create_window9();
	window10=lookup_widget(objet_graphique,"window10");
	gtk_widget_hide(window10);
	List_View=lookup_widget(window9,"treeviewk2");
	afficher2(List_View);
	gtk_widget_show (window9);
}


void
on_buttonpro_clicked                   (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *a;
GtkWidget *b;
GtkWidget *c;
GtkWidget *d;
GtkWidget *e;
GtkWidget *f;
GtkWidget *g;
GtkWidget *h;
GtkWidget *window2,*window11;
window2=lookup_widget(objet_graphique,"window2");
window11=create_window11();
gtk_widget_show(window11);
gtk_widget_hide(window2);
FILE *fic;
a=lookup_widget(window11, "entry1kk");
b=lookup_widget(window11, "entry2kk");
c=lookup_widget(window11, "entry3kk");
d=lookup_widget(window11, "entry4kk");
e=lookup_widget(window11, "entry5kk");
f=lookup_widget(window11, "entry6kk");
g=lookup_widget(window11, "entry7kk");
h=lookup_widget(window11, "entry8kk");
char nom1[50];
char prenom1[50];
char date1[50];
char email1[50];
char cin1[50];
char adresse1[50];
char poids1[50];
char objectif1[50];
char nom[50];
char prenom[50];
char date[50];
char email[50];
char cin[50];
char adresse[50];
char poids[50];
char objectif[50];
fic=fopen("src/profilk.txt","r");

if (fic==NULL) printf("erreur\n");
else {
while (fscanf(fic,"%s %s %s %s %s %s %s %s",nom1,prenom1,date1,email1,cin1,adresse1,poids1,objectif1)!=EOF)
{
break;
}
fclose(fic);}
gtk_entry_set_text(GTK_ENTRY(a),nom1);
gtk_entry_set_text(GTK_ENTRY(b),prenom1);
gtk_entry_set_text(GTK_ENTRY(c),date1);
gtk_entry_set_text(GTK_ENTRY(d),email1);
gtk_entry_set_text(GTK_ENTRY(e),cin1);
gtk_entry_set_text(GTK_ENTRY(f),adresse1);
gtk_entry_set_text(GTK_ENTRY(g),poids1);
gtk_entry_set_text(GTK_ENTRY(h),objectif1);
}


void
on_buttonret_clicked                   (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window5,*window7,*List_View;
window5=create_window5();
window7=lookup_widget(objet_graphique,"window7");
gtk_widget_hide(window7);
List_View=lookup_widget(window5,"treeviewk11");
k_afficher_tableau_event(List_View);
gtk_widget_show (window5);
}


void
on_buttonret1_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window9,*window8,*List_View;
window9=create_window9();
window8=lookup_widget(objet_graphique,"window8");
gtk_widget_hide(window8);
List_View=lookup_widget(window9,"treeviewk2");
afficher2(List_View);
gtk_widget_show (window9);
}


void
on_buttonret4_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window9,*window4;
window9=lookup_widget(objet_graphique,"window9");
window4=create_window4();
gtk_widget_show (window4);
gtk_widget_hide(window9);
}


void
on_buttonret5_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window10,*window9,*List_View;
window9=create_window9();
window10=lookup_widget(objet_graphique,"window10");
gtk_widget_hide(window10);
List_View=lookup_widget(window9,"treeviewk2");
afficher2(List_View);
gtk_widget_show (window9);
}


void
on_buttonprom_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *nom,*prenom,*date,*email,*cin,*adresse,*poids,*objectif,*window2,*window11;
    char nom1[50],prenom1[50],date1[50],email1[50],cin1[50],adresse1[50],poids1[50],objectif1[50];
  
    nom=lookup_widget(objet_graphique,"entry1kk");
    prenom=lookup_widget(objet_graphique,"entry2kk");
    date=lookup_widget(objet_graphique,"entry3kk");
    email=lookup_widget(objet_graphique,"entry4kk");
    cin=lookup_widget(objet_graphique,"entry5kk");
    adresse=lookup_widget(objet_graphique,"entry6kk");
    poids=lookup_widget(objet_graphique,"entry7kk");
    objectif=lookup_widget(objet_graphique,"entry8kk");
  
    strcpy(nom1,gtk_entry_get_text(GTK_ENTRY(nom)));
    strcpy(prenom1,gtk_entry_get_text(GTK_ENTRY(prenom)));
    strcpy(date1,gtk_entry_get_text(GTK_ENTRY(date)));
    strcpy(email1,gtk_entry_get_text(GTK_ENTRY(email)));
    strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(cin)));
    strcpy(adresse1,gtk_entry_get_text(GTK_ENTRY(adresse)));
    strcpy(poids1,gtk_entry_get_text(GTK_ENTRY(poids)));
    strcpy(objectif1,gtk_entry_get_text(GTK_ENTRY(objectif)));
  
    k_modifier2(nom1,prenom1,date1,email1,cin1,adresse1,poids1,objectif1);
    window2=create_window2();
    gtk_widget_show (window2);
    window11=lookup_widget(objet_graphique,"window11");
    gtk_widget_hide(window11);
}


void
on_buttonprore_clicked                 (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window11,*window2;
window11=lookup_widget(objet_graphique,"window11");
window2=create_window2();
gtk_widget_show (window2);
gtk_widget_hide(window11);
}


void
on_buttonretourkk_clicked              (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window2,*window1;
window2=lookup_widget(objet_graphique,"window2");
window1=create_window1();
gtk_widget_show (window1);
gtk_widget_hide(window2);

}


void
on_buttonaffrdv_clicked                (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window4,*window12,*List_View;
window12=create_window12();
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
List_View=lookup_widget(window12,"treeviewk3");
afficher3k(List_View);
gtk_widget_show (window12);
}


void
on_retourrdv_clicked                   (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window12,*window4;
window12=lookup_widget(objet_graphique,"window12");
window4=create_window4();
gtk_widget_show (window4);
gtk_widget_hide(window12);
}


void
on_buttoncclosek_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button6k_clicked                    (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{

}


void
on_buttonRETK_clicked                  (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window13,*window4;
window13=lookup_widget(objet_graphique,"window13");
window4=create_window4();
gtk_widget_show (window4);
gtk_widget_hide(window13);
}


void
on_buttonFM_clicked                    (GtkWidget   *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window4,*window13,*List_View;
window13=create_window13();
window4=lookup_widget(objet_graphique,"window4");
gtk_widget_hide(window4);
List_View=lookup_widget(window13,"treeviewk4");
afficherk(List_View);
gtk_widget_show (window13);
}






void
on_treeviewk11_row_activated           (GtkWidget *objet_graphique,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
  GtkWidget *nomk,*prenomk,*jourk,*anneek,*moisk,*seanceek,*window7,*window5,*treeview;
    gchar *nom,*prenom,*seancee;
    int annee,jour,mois;
    window7=create_window7();
    treeview=lookup_widget(objet_graphique,"treeviewk11");
    window5=lookup_widget(objet_graphique,"window5");
    nomk=lookup_widget(window7,"entry10k");
    prenomk=lookup_widget(window7,"entry11k");
    anneek=lookup_widget(window7,"annee1k");
    moisk=lookup_widget(window7,"mois1k");
    jourk=lookup_widget(window7,"jour1k");
    seanceek=lookup_widget(window7,"comboboxk4");
    GtkTreeIter iter;
    GtkTreeModel *model=gtk_tree_view_get_model (treeview);
    gtk_tree_model_get_iter(model,&iter,path);
    gtk_tree_model_get (model,&iter,0,&nom,1,&prenom,2,&jour,3,&mois,4,&annee,5,&seancee,-1);
    g_print("%s %s %d %d %d %s ",nom,prenom,jour,mois,annee,seancee);
    gtk_entry_set_text(GTK_ENTRY (nomk),_(nom));
    gtk_entry_set_text(GTK_ENTRY (prenomk),_(prenom));
    gtk_spin_button_set_value(GTK_SPIN_BUTTON (anneek),annee);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON (moisk),mois);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON (jourk),jour);
    gtk_entry_set_text(GTK_ENTRY (seanceek),(seancee));
    if (!strcmp(seancee,"massage_mainceur"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(seanceek),0);
    if (!strcmp(seancee,"massage_lymphatique"))
		gtk_combo_box_set_active(GTK_COMBO_BOX(seanceek),1);
    gtk_widget_hide(window5);
    gtk_widget_show(window7);
}

