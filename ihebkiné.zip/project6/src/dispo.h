#include <gtk/gtk.h>
void afficher2(GtkWidget *plistview);
void modifier1(char jour1[],int jour,int mois,int annee,char heure[]);
typedef struct
{
char jour1[20];
int jour;
int annee;
int mois;
char heure[20];
} dispok;
void ajouter1(dispok d);
void supprimer1(char jour1[],int jour,int mois,int annee,char heure[]);

