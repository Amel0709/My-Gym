#include <gtk/gtk.h>
typedef struct
{
char nom[20];
char prenom[20];
int jour;
int annee;
int mois;
char seancee[20];
}seancek;
void afficherkk();
int verifierkk(char login[],char password[]);
void k_afficher_tableau_event(GtkWidget *plistview);
void modifier(char nom[],char prenom[],int annee,int mois,int jour,char seancee[]);
void afficher_rdv(GtkWidget *liste);
void supprimer(char nom[],char prenom[],int annee,int mois,int jour,char seancee[]);
void k_modifier2(char nom[],char prenom[],char date[],char email[],char cin[],char adresse[],char poids[], char objectif[]);
void afficher3k(GtkWidget *plistview);
void afficherk(GtkWidget *plistview);

